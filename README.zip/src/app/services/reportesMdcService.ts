import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { Observable, throwError, from, of } from 'rxjs';
import swal from 'sweetalert2';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';



@Injectable()
export class ReportesmdcService {
  private urlReporteSession: string = environment.apiUrl+ 'mesacontrolguatemala/getbitacorasesion_beta';
  private urlReporteSessionExcel: string = environment.apiUrl+ 'mesacontrolguatemala/repoSesionUserExcel_beta';
  
  private urlReporteTiempo: string = environment.apiUrl+ 'mesacontrolguatemala/repotemp_beta';
  private urlReporteTiempoExcel: string = environment.apiUrl+ 'mesacontrolguatemala/repoTempExcel_beta';
  
  private urlReporteHorario: string =environment.apiUrl+  'mesacontrolguatemala/reposuchrs_beta';
  private urlReporteHorarioExcel: string =environment.apiUrl+  'mesacontrolguatemala/reposuchrsExcel_beta';
  

  private urlReporteGeo: string = environment.apiUrl+ 'mesacontrolguatemala/reposucgeo_beta';
  private urlReporteGeoExcel: string = environment.apiUrl+ 'mesacontrolguatemala/reposucgeoExcel_beta';
  

  private urlListaGeografia: string = environment.apiUrl+ 'mesacontrolguatemala/getinfosuc';
  private urlReporteReenvios: string = environment.apiUrl+ 'mesacontrolguatemala/reporeenvios_beta';
  private urlReporteReenviosExcel: string = environment.apiUrl+ 'mesacontrolguatemala/reporeenviosExcel_beta';
  
  private urlReporteObservados: string = environment.apiUrl+ 'mesacontrolguatemala/repotipobserv_beta';
  private urlReporteObservadosExcel: string = environment.apiUrl+ 'mesacontrolguatemala/repotipobservExcel_beta';

  
  
  private urlReporteResumen: string = environment.apiUrl+ 'mesacontrolguatemala/reposol_beta';
  private urlReporteResumenExcel: string = environment.apiUrl+ 'mesacontrolguatemala/repoResumenSolicitudExcel_beta';
  
  private urlRepoSolicitudesExcel: string = environment.apiUrl+ 'mesacontrolguatemala/repoSolicitudesExcel_beta';
  private urlRepoTempResumenExcel: string = environment.apiUrl+ 'mesacontrolguatemala/repoTempResumenExcel_beta';
  
  
  private httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private http: HttpClient, private router: Router) { }

  getReporteSesion(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteSession, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteSesionExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteSessionExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReportetiempoDe(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteTiempo, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReportetiempoDeExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteTiempoExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  

  getRepoTempResumenExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlRepoTempResumenExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getRepoSolicitudesExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlRepoSolicitudesExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getHorarios(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteHorario, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getHorariosExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteHorarioExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteGeografia(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteGeo, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteGeografiaExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteGeoExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getListaGeografia(): Observable<any> {
    return this.http.post(this.urlListaGeografia, null).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteReenvios(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteReenvios, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteReenviosExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteReenviosExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteObservados(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteObservados, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteObservadosExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteObservadosExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteResumen(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteResumen, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteResumenExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteResumenExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
       
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
}
