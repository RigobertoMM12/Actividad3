import { Injectable } from '@angular/core';
import { UsuariosModel } from '../mantenimiento-usr/UsuariosModel';

@Injectable({
  providedIn: 'root'
})
export class DataUsrService {
usuariosModel:UsuariosModel
 crear:boolean;
 isDetails:boolean;
  constructor() { }
}
