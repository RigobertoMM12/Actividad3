import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { PaginationInstance } from 'ngx-pagination';
import { ReportesmdvService } from './../reporte-asigna/reportesmdv.service';

import { formatDate } from '@angular/common';
import * as XLSX from 'xlsx';  
import { ColRepoAten } from './ColRepoAten';
import { saveAs } from 'file-saver';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-reporte-atencion',
  templateUrl: './reporte-atencion.component.html',
  styleUrls: ['./reporte-atencion.component.css']
})
export class ReporteAtencionComponent implements OnInit {
  @ViewChild('table', { static: false }) TABLE: ElementRef;
  title = 'Excel';  
  loading : boolean = false;
  constructor( private reportesService : ReportesmdvService) { }
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 6,
    currentPage: 1
  };
  activaBor: boolean = false;
  dtoFiltro:any= 0;
  ffechaInicio: { day: number, year: number, month: number };
  ffechaFin: { day: number, year: number, month: number };
  fInicio:string="";
  fFinal:string ="";
  fechaActual :Date;
  fechaActualR :Date = new Date();
  config: any;
  today = new Date()
  minDate = { year: 2010, month: 5, day: 25 };
  maxDate= { year: 2022, month: 5, day: 25 };
  startDate = {year:new Date().getFullYear(),month: ((new Date().getMonth() + 1) < 10 ? '0' : '') + (new Date().getMonth() + 1), day: (new Date().getDate() < 10 ? '0' : '') + new Date().getDate()};

  collection = { count: 60, data: [] };
  foliosReport : ColRepoAten[];

  ngOnInit(): void {
    this.today.setDate(this.today.getDate() - 180);
    this.minDate = { year: this.today.getFullYear(), month: (this.today.getMonth() + 1), day: this.today.getDate()  };
    this.today.setDate(this.today.getDate() + 180);
    this.maxDate = { year: this.today.getFullYear(), month: (this.today.getMonth() + 1), day: this.today.getDate()  };
    //this.loadData()
  }
  ExportTOExcel() {  
    console.log("-------------------***");
    this.foliosReport =[];
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null) {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
    }
    var peticion = {
      "fInicio":this.fInicio,"fFinal":this.fFinal,"idFlujo":this.dtoFiltro.substring(4,5)
    }
    console.log(" loadData() ===> ",peticion)
    this.reportesService.getReporteAtencionExel(JSON.stringify(peticion)).subscribe(
      resp => {
        
        if(resp.codigo == 2){
          if(resp.dato != null){
          this.downloadFile(resp.dato ,"application/vnd.openxmlformats-officedocument.spreadsheetml")

          }
            
        }
        this.loading = false
       
      },err =>{
        this.loading = false;
        console.log("loadData()=> ",err)
      })

    /*const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);  
    const wb: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb, ws, 'Reporte');  
    XLSX.writeFile(wb, 'ReporteAtencion_.xlsx');  */

  }  
  loadData(): void{
    if(this.dtoFiltro <1){
      Swal.fire("Aviso", "El flujo es necesario", 'warning');
      this.loading = false;
      this.activaBor = true;
    }else{
      this.activaBor = false;

    console.log("-------------------***");
    this.foliosReport =[];
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null) {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
    }
    var peticion = {
      "fInicio":this.fInicio,"fFinal":this.fFinal,"idFlujo":this.dtoFiltro.substring(4,5)
    }
    console.log(" loadData() ===> ",peticion)
    this.collection = { count: 60, data: [] };
    this.reportesService.getReporteAtencion(JSON.stringify(peticion)).subscribe(
      resp => {
        
        if(resp.codigo == 1){
          if(resp.dato != null){
            resp.dato.forEach(element => {
              this.collection.data.push(element)
            });
          }
            
        }
      
        this.config = {
          itemsPerPage: 4,
          currentPage: 1,
          totalItems:  this.collection.data.length
        };
        this.loading = false
       

       
        
      },err =>{
        this.loading = false;
        console.log("loadData()=> ",err)
      })
    }
  }
  converirW(fecha) : string{
    var nvalo= fecha.split("/");
    return nvalo[1]+"/"+nvalo[0]+"/"+nvalo[2];
  }
  converir(fecha) : string{
    var nvalo= fecha.split("/");
    return nvalo[2]+"-"+nvalo[1]+"-"+nvalo[0];
  }

  downloadFile(blobContent,tyCont):void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});
    
    saveAs(blob,'ReporteAtencion_.xlsx');
}
base64toBlob(base64Data, contentType):Blob{
  contentType = contentType || '';
  let sliceSize = 1024;
  let byteCharacters = atob(base64Data);
  let bytesLength = byteCharacters.length;
  let slicesCount = Math.ceil(bytesLength / sliceSize);
  let byteArrays = new Array(slicesCount);
  for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
          bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
  }
  return new Blob(byteArrays, { type: contentType });
}

}
