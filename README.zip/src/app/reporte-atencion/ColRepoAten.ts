export class ColRepoAten {


folio: string;
sucursal: string;
fechaGenera: string;
asesorGenera: string;
fechaAsigna: string;
operadorAsignado: string;
tipoFolio: string;
pNombreCliente: string;
sNombreCliente: string;
aPaterno: string;
aMaterno: string;
aCasada: string;
nacionalidad: string;
fechaNacimiento: string;
cu: string;
fechaAtencion: string;
estatus:string;
motivoRechazo: string;
}