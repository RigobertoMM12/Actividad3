export class ProductoModel {
    descripcion:string;
    fechaCreacion:string;
    id:number;
    idUsuario: number ;
    precio: number ;
    sku: string ;
    status: boolean ;
}
  