import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { Observable, throwError, from, of } from 'rxjs';
import swal from 'sweetalert2';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';



@Injectable()
export class RroductoService {
  private urlgetProductos: string = environment.apiUrlC+ 'producto/';
  private urlReporteAsignacion: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/repoAsignacion_beta';
  private urlReporteAsignacionExcel: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/repoAsignacionExcel_beta';
  
  private urlReporteAtencion: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/repoAtencion_beta';
  private urlReporteAtencionExcel: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/repoAtencionExcel_beta';
  private urlReporteAtencionTotal: string =environment.apiUrl+  'mesacontrolguatemala/mesavalidacion/repoAtencionTotales_beta';
  private urlReporteAtencionTotalExcel: string =environment.apiUrl+  'mesacontrolguatemala/mesavalidacion/repoAtencionTotalesExcel_beta';
  
  private urlReporteValidacionExp: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/repoValidacionExpedientes_beta';
  private urlReporteValidacionExpExcel: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/repoValidacionExpedientesExcel_beta';
  
  private httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private http: HttpClient, private router: Router) { }

  getProducts(): Observable<any> {
    return this.http.get(this.urlgetProductos, { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore: any = response;
        //let datosEmpleado = notSore.dato as UsuarioModel;
        return notSore;
      }
      ), catchError(e => {
        console.log("catchError()-->", e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }


        return throwError(e);
      })
    );
  }


  getReporteAsigna(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteAsignacion, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }

  
  getReporteAsignaExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteAsignacionExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteAtencionTotales(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteAtencionTotal, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteAtencionTotalesExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteAtencionTotalExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }

  getReporteAtencion(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteAtencion, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteAtencionExel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteAtencionExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteValidacionExp(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteValidacionExp, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getReporteValidacionExpExcel(peticion:string): Observable<any> {
    return this.http.post(this.urlReporteValidacionExpExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
}
