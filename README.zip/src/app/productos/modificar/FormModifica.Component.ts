import { Component, OnInit, Input } from '@angular/core';
import { ProductoModel } from '../model/ProductoModel'; 
import { RroductoService } from '../producto.service';
import { DatePipe, formatDate } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
import { from } from 'rxjs';
import * as _ from 'lodash';
import { DataProductService } from 'src/app/services/dataProduct.service'; 
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-form',
  templateUrl: './formModifica.component.html',
  styleUrls: ['./../productos.component.css']

})
export class FormModificaComponent implements OnInit {
  @Input() valor: number = 600;
  loading = false;
   productoModel: ProductoModel = new ProductoModel();

  imageError: string;
  isImageSaved: boolean;
  cardImageBase64: string;
  titulo: string = "Crear Producto";
  archivoTemporal : string;
  archivoTemporalOne : string;
  errores: string[];
  nvalo: string[];
  isDetails : boolean;
  today = new Date()
  minDate = { year: 2010, month: 5, day: 25 };
  constructor(private productoService: RroductoService,
    private router: Router,
    private activatedRoute: ActivatedRoute,private datService:DataProductService) { }
    public habilitabtn:boolean =true;
     ffechaInicio: { day: number, year: number, month: number };
  ffechaFin: { day: number, year: number, month: number };
  ngOnInit() {
    this.today.setDate(this.today.getDate() - 0);
    this.minDate = { year: this.today.getFullYear(), month: (this.today.getMonth() + 1), day: this.today.getDate()  };
    this.cargarCliente();
  }

  cargarCliente(): void {
    this.habilitabtn = this.datService.crear;
    if(!this.habilitabtn){
      this.titulo="Editar Producto"
    }
    
    this.isDetails = this.datService.isDetails;
    this.isDetails =(this.isDetails == undefined) ? false:this.isDetails;
    if(this.isDetails){
      this.titulo="Detalles Producto"
    }
    console.log("cargarCliente()======>",this.isDetails)
 try{
  this.productoModel  = this.datService.productoM;

 

  
  if( this.productoModel == null){
    this.productoModel = new ProductoModel();
    
  }else{
 
    
  }

 }catch(w){
  this.router.navigate(['notificaciones']);
  console.log("catch ==> ",w);
  
 }
  }
 
 

  converir(fecha) : string{
    this.nvalo= fecha.split("/");
    return this.nvalo[2]+"-"+this.nvalo[1]+"-"+this.nvalo[0];
  }
  create(): void {
    this.loading = true;
    console.log("notifiacion: ",this.productoModel)
  
    this.productoService.getProducts()
      .subscribe(
        cliente => {
          this.loading = false;
          this.router.navigate(['notificaciones']);
          swal.fire('Nuevo notificación', `La notificacion ha sido creado con éxito`, 'success');
        },
        err => {
          swal.fire('Nuevo notificación', `Ocurrio un error al crear la notificación`, 'error');
          this.loading = false;
          this.errores = err.error.errors as string[];
          console.error('Código del error desde el backend: ' + err.status+ err.error);
          console.error(err.error.errors);
        }
      );
  }

  update(): void {
    console.log("-.-.-.-.-.-.- "+this.productoModel)
    this.loading = true;
 
    this.productoService.getProducts()
      .subscribe(
        json => {
          this.router.navigate(['notificaciones']);
          swal.fire('Notificación Actualizada', `${json.descripcion}`, 'success');
        },
        err => {
          this.errores = err.error.errors as string[];
          console.error('Código del error desde el backend: ' + err.status);
          console.error(err.error.errors);
        }
      )
  }

  
regresar():void{
  this.router.navigate(['productos']);
 }

}
