import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ReportesmdcService } from '../services/reportesMdcService';
import { PaginationInstance } from 'ngx-pagination';
import { formatDate } from '@angular/common';
import { ColFolio } from '../reporte-asigna/ColFolio';
import * as XLSX from 'xlsx';
import { MantenimientoUsrService } from '../mantenimiento-usr/mantenimiento-usr.ervice';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-reporte-sesion-mdc',
  templateUrl: './reporte-sesion-mdc.component.html',
  styleUrls: ['../css/mesaDeControl.css']
})
export class ReporteSesionMdcComponent implements OnInit {

  @ViewChild('table', { static: false }) TABLE: ElementRef;
  isReporte: boolean = false;
  title = 'Excel';
  loading: boolean = false;
  ffechaInicio: { day: number, year: number, month: number };
  ffechaFin: { day: number, year: number, month: number };
  constructor(private reportesService: ReportesmdcService, private mantenimiento: MantenimientoUsrService, private userService: UserService) { }
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 6,
    currentPage: 1
  };
  empleadoSelect: number;
  usrActivo: UsuarioModel;
  fInicio: string = "";
  fFinal: string = "";
  fechaActual: Date;
  fechaActualR: Date = new Date();
  config: any;

  collection = { count: 60, data: [] };
  collectionReport = { count: 60, data: [] };
  foliosReport: ColFolio[];
  captcha: string;
  respCaptch: string;
  isbad: boolean = false;
  tittleBotton: string = "";
  ngOnInit(): void {
    this.usrActivo = this.userService.getUserLoggedIn();
    this.loadDataEmploye()
    //this.loadData()
  }

  showReport(noEmpleye): void {
    this.empleadoSelect = noEmpleye;
    console.log("showReport==> noEmpleye==> ", noEmpleye)
    this.isReporte = true;
    this.collectionReport.data = [];
    this.config = {
      itemsPerPage: 6,
      currentPage: 1,
      totalItems: this.collectionReport.data.length
    };
    this.loadDataBitacora();

  }
  ExportTOExcel() {
    if (this.captcha == this.respCaptch) {
      this.isbad = false;
      $("#closeModal").click();

      //      -----------------
      this.loading = true;
      this.fechaActual = new Date();
      if (this.ffechaFin == null) {
        this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
      } else {
        this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
      }

      if (this.ffechaInicio == null) {
        this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
      } else {
        this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
      }



      var peticion = {
        "fInicio": this.fInicio, "fFinal": this.fFinal, "noEmpleado": this.empleadoSelect
      }
      console.log(" loadData() ===> ", peticion)
      this.fFinal = this.converir(this.fFinal);
      this.fInicio = this.converir(this.fInicio);

      this.reportesService.getReporteSesionExcel(JSON.stringify(peticion)).subscribe(
        resp => {

          if (resp.codigo == 2) {
            if (resp.dato != null) {
              this.downloadFile(resp.dato, "application/vnd.openxmlformats-officedocument.spreadsheetml")

            }

          }
          this.loading = false

        }, err => {
          this.loading = false;
          console.log("loadData()=> ", err)
        })

/*
      const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Reporte');
      XLSX.writeFile(wb, 'ReporteSesion_.xlsx');*/
    } else {
      this.isbad = true;
      if (this.respCaptch.length == 0) {
        this.tittleBotton = "Captcha es requerido"
      } else if (this.respCaptch.length < 8) {
        this.tittleBotton = "Captcha tiene que ser de 8 posiciones"
      } else {
        this.tittleBotton = "Captcha diferente "
      }


    }
  }
  loadDataEmploye(): void {
    this.loading = true;
    var perticion = { ban: (this.usrActivo.idPerfil < 2020) ? 0 : 1,navegador:this.navegatior(),noEmpleado:this.usrActivo.idEmpleado }
    this.mantenimiento.getUsuarios(perticion).subscribe(
      data => {
        this.loading = false
        this.collection.data = [];
        data.dato.forEach(element => {
          if(element.idPerfil != 2002 && element.idPerfil != 2008){
            this.collection.data.push(element)
          }
        });
        //this.collection.data = data.dato;
        this.config = {
          itemsPerPage: 6,
          currentPage: 1,
          totalItems: this.collection.data.length
        };
      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      });
  }
  regresar() {
    this.isReporte = false; this.config = {
      itemsPerPage: 6,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
  }
  loadDataBitacora(): void {
    console.log("-------------------***");
    this.foliosReport = [];
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null) {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
    }



    var peticion = {
      "fInicio": this.fInicio, "fFinal": this.fFinal, "noEmpleado": this.empleadoSelect
    }
    console.log(" loadData() ===> ", peticion)
    this.fFinal = this.converir(this.fFinal);
    this.fInicio = this.converir(this.fInicio);
    this.reportesService.getReporteSesion(JSON.stringify(peticion)).subscribe(
      resp => {

        if (resp.codigo == 2) {
          if (resp.dato != null) {
            resp.dato.forEach(element => {
              this.collectionReport.data.push(element)
            });
          }

        }

        this.config = {
          itemsPerPage: 6,
          currentPage: 1,
          totalItems: this.collectionReport.data.length
        };
        this.loading = false




      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      })

  }
  converirW(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[1] + "/" + nvalo[0] + "/" + nvalo[2];
  }
  converir(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[2] + "-" + nvalo[1] + "-" + nvalo[0];
  }
  creaCodigo() {
    this.tittleBotton = ""
    this.isbad = false
    this.captcha = this.randomString(8,
      '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ');
    this.respCaptch = "";
  }
  randomString(length, chars): string {
    var result = '';
    for (var i = length; i > 0; --i)
      result += chars[Math.round(Math
        .random()
        * (chars.length - 1))];
    return result;
  }

  downloadFile(blobContent, tyCont): void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});

    saveAs(blob, 'ReporteSesion_.xlsx');
  }
  base64toBlob(base64Data, contentType): Blob {
    contentType = contentType || '';
    let sliceSize = 1024;
    let byteCharacters = atob(base64Data);
    let bytesLength = byteCharacters.length;
    let slicesCount = Math.ceil(bytesLength / sliceSize);
    let byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }
  navegatior():string
    {
      var navegador = navigator.userAgent;
      var msie = navegador.indexOf("MSIE "); 
      if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) 
      {
        return "INTERNET EXPLORER";
      } else if (navigator.userAgent.indexOf('Firefox') !=-1) 
      {
        return "MOZILA FIREFOX";
      } else if (navigator.userAgent.indexOf('Chrome') !=-1) 
      {
        return "GOOGLE CHROME";
      } else if (navigator.userAgent.indexOf('Opera') !=-1) 
      {
        return "OPERA";
      } else 
      {
        return "OTRO";
      }
    }

}
