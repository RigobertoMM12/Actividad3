import { Injectable } from '@angular/core';
//import { DatePipe, formatDate } from '@angular/common';
//import { Cliente } from './cliente';
import { Notificacion }from '../notificacionmdv/notificacion'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { Observable, throwError, from, of } from 'rxjs';
import swal from 'sweetalert2';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { UsuarioModel } from '../header/model/usuarioModel';



@Injectable()
export class MantenimientoUsrService {
  private urlgetUsuarios: string = environment.apiUrl+ 'mesacontrolguatemala/getbitacorasesionusuarios_beta';
  private urlGetCatalogos: string = environment.apiUrl+ 'mesacontrolguatemala/getinfocatuser';
  private ulrSaveUsr : string = environment.apiUrl+  'mesacontrolguatemala/altausuario_beta';
  private ulrEditUsr : string = environment.apiUrl+  'mesacontrolguatemala/updateusuario_beta';
  private ulrDeleteUsr : string = environment.apiUrl+  'mesacontrolguatemala/bajausuario_beta';
  private ulrReactivarUsrn : string = environment.apiUrl+  'mesacontrolguatemala/reactivarUsuario_beta';
  
  private ulrRepoCambios : string = environment.apiUrl+  'mesacontrolguatemala/repoCambios_beta';
  private ulrparametros : string = environment.apiUrl+  'mesacontrolguatemala/finduser_beta';
  private ulrDeleteparametros : string = environment.apiUrl+  'mesacontrolguatemala/deldatacat_beta';
  private ulrAlterUparametros : string = environment.apiUrl+  'mesacontrolguatemala/altaDinamica_beta';
  private ulrRepoCambiosExcel : string = environment.apiUrl+  'mesacontrolguatemala/repoCambiosExcel_beta';

  
  private httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private http: HttpClient, private router: Router) { }

  getUsuarios(peticion): Observable<any> {
      console.log("peticion ==> ",peticion)
    return this.http.post(this.urlgetUsuarios,peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getCatalogos(): Observable<any> {
  return this.http.post(this.urlGetCatalogos,null, { headers: this.httpHeaders }).pipe(
    map(response => {
      return response;
    }
    ),catchError(e => {
      console.log("catchError()-->",e)
      if (e.status == 400) {
        return throwError(e);
      }
      if (e.status == 0) {
        swal.fire("Servicio no disponible", e.error.error, 'error');
        return throwError(e);
      }

      
      return throwError(e);
    })
  );
}

  createUsr(usuarioModel :  string): Observable<any> {
    console.log(usuarioModel)
    return this.http.post(this.ulrSaveUsr, usuarioModel, { headers: this.httpHeaders }).pipe(
      map((response: any) => response),
      catchError(e => {

        if (e.status == 400) {
          return throwError(e);
        }

        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }



  updateUsr(peticion: string): Observable<any> {
    return this.http.post(this.ulrEditUsr, peticion, { headers: this.httpHeaders }).pipe(
      catchError(e => {

        if (e.status == 400) {
          return throwError(e);
        }

        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }

  deleteUsrn(peticion : string): Observable<any> {
    console.log("ulrDeleteUsr ==> ",this.ulrDeleteUsr, " ==> peticion ==>",peticion)
    return this.http.post(this.ulrDeleteUsr, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }),
      catchError(e => {
        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }
  getBitacora(peticion : string): Observable<any> {
    return this.http.post(this.ulrRepoCambios, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }),
      catchError(e => {
        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }
  getBitacoraExcel(peticion : string): Observable<any> {
    return this.http.post(this.ulrRepoCambiosExcel, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }),
      catchError(e => {
        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }
  reactivarUsrn(peticion : string): Observable<any> {
    console.log("reactivarUsrn ==> ",this.ulrReactivarUsrn, " ==> peticion ==>",peticion)
    return this.http.post(this.ulrReactivarUsrn, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }),
      catchError(e => {
        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }
  getParametros(peticion : string): Observable<any> {
    return this.http.post(this.ulrparametros, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }),
      catchError(e => {
        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }

  deleteParametros(peticion : string): Observable<any> {
    return this.http.post(this.ulrDeleteparametros, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }),
      catchError(e => {
        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }
  alterUParametros(peticion : string): Observable<any> {
    console.log("reactivarUsrn ==> ",this.ulrAlterUparametros, " ==> peticion ==>",peticion)
    return this.http.post(this.ulrAlterUparametros, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }),
      catchError(e => {
        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }

}
