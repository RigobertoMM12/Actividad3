import { Component, OnInit, Output, Input, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import Swal from 'sweetalert2';
import { PaginationInstance } from 'ngx-pagination';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService';
import { MantenimientoUsrService } from './mantenimiento-usr.ervice';
import { DataUsrService } from '../services/dataUsr.service';
import { UsuariosModel } from './UsuariosModel';
import { formatDate } from '@angular/common';
import * as XLSX from 'xlsx';
import { Router } from '@angular/router';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-mantenimiento-usr',
  templateUrl: './mantenimiento-usr.component.html',
  styleUrls: ['./mantenimiento-usr.component.css']
})
export class MantenimientoUsrComponent implements OnInit {

  @Output() public valor = new EventEmitter<any>();

  @ViewChild('table', { static: false }) TABLE: ElementRef;
  usrActivo: UsuarioModel;
  loading = false;
  isReporte: boolean = false;
  foliosReport: any[];
  empleadoSelect: number;
  fechaActual: Date;
  fInicio: string = "";
  fFinal: string = "";
  ffechaInicio: { day: number, year: number, month: number };
  ffechaFin: { day: number, year: number, month: number };
  fechaActualR: Date = new Date();
  totalColumna: number = 0;
  opacity: number = 0.1;
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 6,
    currentPage: 1
  };

  applyDates() {
    console.log("------")
    this.valor.emit(2);
  }


  constructor(private mantenimientoUsrService: MantenimientoUsrService, private datSe: DataUsrService, private userService: UserService, private router: Router) { }
  config: any;
  collection = { count: 60, data: [] };
  collectionReport = { count: 60, data: [] };
  ngOnInit() {
    this.usrActivo = this.userService.getUserLoggedIn();
    this.loadData();

  }
  loadData(): void {
    console.log("-------------------***")
    this.loading = true;
    var perticion = { ban: (this.usrActivo.idPerfil < 2020) ? 0 : 1, navegador: this.navegatior(), noEmpleado: this.usrActivo.idEmpleado }
    this.mantenimientoUsrService.getUsuarios(perticion).subscribe(
      data => {
        console.log('ClientesComponent: tap 3');
        this.loading = false
        this.collection.data = [];
        this.collection.data = data.dato;
        if(this.usrActivo.idPerfil < 2020){
          console.log("Es Mesa de Control")
        }else{
          console.log("Es Mesa de Validacion"+ this.usrActivo.tabla,);
          try{
            var desarrolladores=  this.usrActivo.tabla[10].descValor.split(",");
            var operdores = data.dato;
            var nOperadores=[];
           var an=0;
              for(var j=0;j<operdores.length;j++){
                an=0
                for(var i =0;i<desarrolladores.length; i++){
                  console.log("("+desarrolladores[i] +"!= "+operdores[j].noEmpleado+")",desarrolladores[i] != operdores[j].noEmpleado);
                  if(desarrolladores[i] == operdores[j].noEmpleado){
                    an++;
                    
                    break;;
                      
                    //break;
                  }
              }
              if(an == 0){
                nOperadores.push(operdores[j]);
               // console.log("Se agrega a la lista "+j, operdores[j]);
              }
            }
            this.collection.data = [];
        this.collection.data = nOperadores;
            //console.log("=====>",desarrolladores,"=====>",operdores,"NOperadores  = ",nOperadores);
          }catch(e){
            this.collection.data = [];
            this.collection.data = data.dato;
          }
         
        }
        this.config = {
          itemsPerPage: 5,
          currentPage: 1,
          totalItems: this.collection.data.length
        };
        this.totalColumna = this.collection.data.length
      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      });
  }
  navegatior(): string {
    var navegador = navigator.userAgent;
    var msie = navegador.indexOf("MSIE ");
    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
      return "INTERNET EXPLORER";
    } else if (navigator.userAgent.indexOf('Firefox') != -1) {
      return "MOZILA FIREFOX";
    } else if (navigator.userAgent.indexOf('Chrome') != -1) {
      return "GOOGLE CHROME";
    } else if (navigator.userAgent.indexOf('Opera') != -1) {
      return "OPERA";
    } else {
      return "OTRO";
    }
  }
  cleanNotification(): void {
    this.datSe.usuariosModel = new UsuariosModel()
    this.datSe.crear = true;
    this.datSe.isDetails = undefined;
    this.router.navigate(['mantenimientoUsr/form']);
  }

  madifica(usuariosMp: UsuariosModel, isDetails): void {
    console.log("usuariosMp ==> ", usuariosMp)
    this.datSe.usuariosModel = usuariosMp;
    this.datSe.crear = false;
    this.datSe.isDetails = isDetails;
    this.router.navigate(['mantenimientoUsr/form']);
  }

  showReport(noEmpleye): void {
    this.empleadoSelect = noEmpleye;
    console.log("showReport==> noEmpleye==> ", noEmpleye)
    this.isReporte = true;
    this.collectionReport.data = [];
    this.config = {
      itemsPerPage: 8,
      currentPage: 1,
      totalItems: this.collectionReport.data.length
    }
    this.loadDataBitacora();

  }
  pageChanged(event) {
    this.config.currentPage = event;
  }

  delete(usuarioModel: UsuariosModel): void {
    if (usuarioModel.estado == "BAJA" || usuarioModel.estado == "ACTIVO") {

    } else {
      console.log("Delete()==>", usuarioModel)
      Swal.fire({
        title: 'Está seguro?',
        text: `¿Seguro que desea eliminar el usuario ${usuarioModel.noEmpleado} - ${usuarioModel.nombre} ${usuarioModel.aPaterno} ${usuarioModel.aMaterno}?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, eliminar!',
        cancelButtonText: 'No, cancelar!'
      }).then((result) => {
        if (result.value) {
          this.loading = true;
          var peticion = { noEmpleado: usuarioModel.noEmpleado }
          console.log("peticion ==> ", peticion)
          this.mantenimientoUsrService.deleteUsrn(JSON.stringify(peticion)).subscribe(
            data => {
              console.log("data ==> ", data)
              this.loading = false;

              this.loadData();
              Swal.fire(
                'Usuario Elimnado!',
                `Usuario  ${usuarioModel.noEmpleado} - ${usuarioModel.nombre} ${usuarioModel.aPaterno} ${usuarioModel.aMaterno} eliminado con éxito.`,
                'success'
              )
            }
          )

        } else if (result.dismiss === Swal.DismissReason.cancel) {
          Swal.fire(
            'Cancelado',
            '',
            'error'
          )
        }
      })
    }
  }
  loadDataBitacora(): void {
    console.log("-------------------***");
    this.foliosReport = [];
    this.collectionReport = { count: 60, data: [] };
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null) {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
    }



    var peticion = {
      "fInicio": this.fInicio, "fFinal": this.fFinal, "noEmpleado": this.empleadoSelect, ban: 2
    }
    console.log(" loadData() ===> ", peticion)

    this.mantenimientoUsrService.getBitacora(JSON.stringify(peticion)).subscribe(
      resp => {

        if (resp.codigo == 2) {
          if (resp.dato != null) {
            resp.dato.forEach(element => {
              this.collectionReport.data.push(element)
            });
          }

        }

        this.config = {
          itemsPerPage: 8,
          currentPage: 1,
          totalItems: this.collectionReport.data.length
        };
        this.totalColumna = this.collectionReport.data.length
        this.loading = false




      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      })

  }

  regresar() {
    this.isReporte = false;
    this.config = {
      itemsPerPage: 5,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
    this.totalColumna = this.collection.data.length
  }

  ExportTOExcel() {
/*
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Reporte');
    XLSX.writeFile(wb, 'ReporteBitacoraCambios_.xlsx');
    */
   this.loading = true;
   this.fechaActual = new Date();
   if (this.ffechaFin == null ) 
   {
     this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
   } else 
   {
     this.fFinal = this.ffechaFin.day+"/"+this.ffechaFin.month+"/"+this.ffechaFin.year;
   }

   if (this.ffechaInicio == null) 
   {
     this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
   } else 
   {
     this.fInicio= this.ffechaInicio.day+"/"+this.ffechaInicio.month+"/"+this.ffechaInicio.year;
   }

     var peticion = {
      "fInicio": this.fInicio, "fFinal": this.fFinal, "noEmpleado": this.empleadoSelect, ban: 2
     }
       console.log(peticion)
       this.mantenimientoUsrService.getBitacoraExcel(JSON.stringify(peticion)).subscribe(
         resp => {
 
          try {
           if (resp.codigo == 2) {
             if (resp.dato != null) {
               this.downloadFile(resp.dato, "application/vnd.openxmlformats-officedocument.spreadsheetml")
               
 
             }
 
           }
           this.loading = false
          } catch (error) {
           this.loading = false
          }
          
 
         }, err => {
           this.loading = false;
           console.log("loadData()=> ", err)
         })
  }

  reactivar(usuarioModel: UsuariosModel): void {
    if(usuarioModel.estado == 'BAJA' || usuarioModel.estado == 'BLOQUEADO POR INACTIVIDAD'){
      console.log("reactivar()==>", usuarioModel)
      Swal.fire({
        title: 'Está seguro?',
        text: `¿Seguro que desea reactivar el usuario ${usuarioModel.noEmpleado} - ${usuarioModel.nombre} ${usuarioModel.aPaterno} ${usuarioModel.aMaterno}?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, reactivar!',
        cancelButtonText: 'No, cancelar!'
      }).then((result) => {
        if (result.value) {
          
          Swal.fire({
            title: "Ingresa motivo!",
            text: `Motivo para reactivar al usuario ${usuarioModel.noEmpleado} - ${usuarioModel.nombre} ${usuarioModel.aPaterno} ${usuarioModel.aMaterno}: `,
            input: 'text',
            showCancelButton: false        
        }).then((result) => {
            if (result.value) {
              if(result.value==""){
                Swal.fire(
                  'Cancelado',
                  'se cancelo la operación',
                  'error'
                )
              }else{
                this.loading = true;
                var peticion = { noEmpleado: usuarioModel.noEmpleado ,noAdmin: this.usrActivo.idEmpleado,  observacion:result.value, ip:"10.51.213.249"}
                console.log("peticion ==> ", peticion)
                this.mantenimientoUsrService.reactivarUsrn(JSON.stringify(peticion)).subscribe(
                  data => {
                    console.log("data ==> ", data)
                    this.loading = false;
      
                    this.loadData();
                    Swal.fire(
                      'Usuario reactivado!',
                      `Usuario  ${usuarioModel.noEmpleado} - ${usuarioModel.nombre} ${usuarioModel.aPaterno} ${usuarioModel.aMaterno} reactivado con éxito.`,
                      'success'
                    )
                  }
                )
              }
                console.log("Result: " + result.value);
            }else{
              Swal.fire(
                'Cancelado',
                'se cancelo la operación',
                'error'
              )
            }
        });
          /*
         
          */

        } else if (result.dismiss === Swal.DismissReason.cancel) {
          Swal.fire(
            'Cancelado',
            'se cancelo la operación',
            'error'
          )
        }
      })
    }
    
  }
  downloadFile(blobContent, tyCont): void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});

    saveAs(blob, 'ReporteBitacoraCambios_.xlsx');
  }
  base64toBlob(base64Data, contentType): Blob {
    contentType = contentType || '';
    let sliceSize = 1024;
    let byteCharacters = atob(base64Data);
    let bytesLength = byteCharacters.length;
    let slicesCount = Math.ceil(bytesLength / sliceSize);
    let byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }
}
