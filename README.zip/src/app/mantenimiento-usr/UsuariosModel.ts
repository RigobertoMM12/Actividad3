export class UsuariosModel {
    noEmpleado: number
    nombre:string
    aPaterno:string
    aMaterno:string
    idPerfil: number
    perfil:string
    idHorario: number
    horarioEntra:string
    horarioSalid:string
    estado:string
    actividad:string
    horaEntrada:string
    horaSalida: number
    noSolPendien: number
    funcionSAP:string
    idHoraComida: number
    salidaComida:string
    entradaComid:string
    idDiaDescanso:number
    idActividad:string
    idRol: number
     ro:string
    status: number
    ipConexion:string
    navegador:string
  }
  