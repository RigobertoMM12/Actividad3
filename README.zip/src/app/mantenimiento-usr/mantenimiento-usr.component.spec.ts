import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantenimientoUsrComponent } from './mantenimiento-usr.component';

describe('MantenimientoUsrComponent', () => {
  let component: MantenimientoUsrComponent;
  let fixture: ComponentFixture<MantenimientoUsrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MantenimientoUsrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantenimientoUsrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
