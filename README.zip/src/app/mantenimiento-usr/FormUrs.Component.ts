import { Component, OnInit, Input } from '@angular/core';
import { UsuariosModel } from './UsuariosModel'
import { MantenimientoUsrService } from './mantenimiento-usr.ervice';
import { DatePipe, formatDate } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
import { from } from 'rxjs';
import * as _ from 'lodash';
import { DataService } from '../services/data.service';
import { saveAs } from 'file-saver';
import { DataUsrService } from '../services/dataUsr.service';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService';
@Component({
  selector: 'app-form',
  templateUrl: './formusr.component.html',
  styleUrls: ['./mantenimiento-usr.component.css']

})
export class FormUsrComponent implements OnInit {
  @Input() valor: number = 600;
  loading = false;
  usuarioModel: UsuariosModel = new UsuariosModel();
  usuarioModelAntes: UsuariosModel = new UsuariosModel();
usuarioAntes:string;
	dataPerfil=[];
	dataHorario=[];
	dataDia=[];
  dataSalida=[];
  usrActivo : UsuarioModel;
  imageError: string;
  isImageSaved: boolean;
  cardImageBase64: string;
  titulo: string = "Crear Usuario";
  archivoTemporal : string;
  archivoTemporalOne : string;
  errores: string[];
  nvalo: string[];
  isDetails : boolean;
  constructor(private mantenimientoUsrServcie: MantenimientoUsrService,
    private router: Router,
    private userService:UserService,
    private activatedRoute: ActivatedRoute,private datUsrService:DataUsrService,public dataService:DataService,private manteService: MantenimientoUsrService) { }
    public habilitabtn:boolean =true;
  ngOnInit() {
   
    this.usrActivo = this.userService.getUserLoggedIn();
    this.loadCatalog();
    this.cargarCliente();
 
  }
  loadCatalog():void{
    this.dataPerfil=[{id_tipo: 2000, desc_tipo:"Listado de Perfiles"}];
    this.dataHorario=[{id_tipo: 4000, desc_tipo:"Listado de Horarios"}];
    this.dataDia=[{id_tipo: 3000, desc_tipo:"Listado de días"}];
    this.dataSalida=[{id_tipo: 499, desc_tipo:"Listado de Horarios de comida"}];
    var pt = null;
    this.loading = true;
    this.mantenimientoUsrServcie.getCatalogos()
    .subscribe(
      data => {
       
       console.log("loatCatalog ==> ",data)
      
       var resp= data;
        if(resp.codigo == 2){
          for(var x=0 ; x < resp.dato.length; x++){
            pt= {id_tipo: resp.dato[x].id,
            desc_tipo:resp.dato[x].descripcion}
            switch (resp.dato[x].ban) {
            case 1:
              if(this.permitido(pt))
              this.dataPerfil.push(pt)
              break;

            case 2:
              this.dataHorario.push(pt)
              break;
            case 3:
              this.dataDia.push(pt)
              break;
            case 4:
             this.dataSalida.push(pt)
              break;
            }
          
          }
          this.loading = false;
        }else{
          this.loading = false;
        }
        
        
      
      },
      err => {
        swal.fire('Nuevo notificación', `Ocurrio un error al crear la notificación`, 'error');
        this.loading = false;
        this.errores = err.error.errors as string[];
        console.error('Código del error desde el backend: ' + err.status+ err.error);
        console.error(err.error.errors);
      }
    );
  }
  permitido(pt):boolean{
    var parmeter1 = 1
    var perfil =  this.usrActivo.idPerfil;
    if(parmeter1 == 1){
      if(perfil ==2023 || perfil ==2008 ){
         return true;
       }else{
         if((pt.id_tipo == 2002 || pt.id_tipo == 2005 || pt.id_tipo == 2006 || pt.id_tipo == 2007 || pt.id_tipo == 2008)){
           return false;
         }
       } 
    }else{

      if(perfil ==2008 ){
        if((pt.id_tipo == 2002 || pt.id_tipo == 2005 || pt.id_tipo == 2006 || pt.id_tipo == 2007 || pt.id_tipo == 2008 || pt.id_tipo == 2001 || pt.id_tipo == 2003)){
          return true;
        }else{
          return false;
        }
        
       }else  if(perfil ==2023 ){
         if((pt.id_tipo == 2021 || pt.id_tipo == 2022 || pt.id_tipo == 2023 )){
           return true;
         }else{
          return false;
         }
       }
    }
   
   
       return true;
  }
  cargarCliente(): void {
   
    this.habilitabtn = this.datUsrService.crear;
  
    
    this.isDetails = this.datUsrService.isDetails;
    this.isDetails =(this.isDetails == undefined) ? false:this.isDetails;
   
    console.log("cargarCliente()======>",this.isDetails)
 try{
  this.usuarioModel  = this.datUsrService.usuariosModel

  if( this.usuarioModel == null){
    this.usuarioModel = new UsuariosModel();
    
  }

 }catch(w){
  this.router.navigate(['mantenimientoUsr']);
  console.log("catch ==> ",w);
  
 }
 if(!this.habilitabtn){
  this.titulo="Editar usuario";
  this.usuarioAntes = JSON.stringify(this.usuarioModel);
}else{
  this.usuarioModel.idPerfil =2000;
this.usuarioModel.idHorario = 4000;
this.usuarioModel.idHoraComida = 499;
this.usuarioModel.idDiaDescanso = 3000;
}
  }
  
 
  regresar():void{
  this.router.navigate(['mantenimientoUsr']);
}
  create(): void {
    this.loading = true;
     var peticion=   {
         idNoEmpleado:this.usuarioModel.noEmpleado,
       nombre:this.usuarioModel.nombre,
       aPaterno:this.usuarioModel.aPaterno,
       aMaterno:this.usuarioModel.aMaterno,
       idPerfilUser:this.usuarioModel.idPerfil,
       funcionSAP:505,
       idHorario:this.usuarioModel.idHorario,
       idHoraComida:this.usuarioModel.idHoraComida,
       idDiaDescanso:this.usuarioModel.idDiaDescanso,
       usuarioCreacion:this.usrActivo.idEmpleado,
       rol:this.usuarioModel.idPerfil,
       ip:"10.1563.17.15",
       ll:""
       }

    console.log("create==> peticion ==>",peticion);
    this.mantenimientoUsrServcie.createUsr(JSON.stringify(peticion))
      .subscribe(
        data => {
          console.log("Response ==> ",data)
          if(data.codigo == 2){
            swal.fire('Nuevo usuario', data.descripcion, 'success');
            this.loading = false;
          }else{
            swal.fire('Nuevo usuario', data.descripcion, 'success');
            
          }
          this.router.navigate(['mantenimientoUsr']);
          
          
        },
        err => {
          swal.fire('Nuevo notificación', `Ocurrio un error al crear la notificación`, 'error');
          this.loading = false;
          this.errores = err.error.errors as string[];
          console.error('Código del error desde el backend: ' + err.status+ err.error);
          console.error(err.error.errors);
        }
      );
  }

  update(): void {
    var datas = [];
    this.usuarioModelAntes = JSON.parse(this.usuarioAntes);
    console.log("update ==> datos anteriores ==>",this.usuarioModelAntes)
    console.log("update ==> datos despues ==>",this.usuarioModel)
    
    if(this.usuarioModelAntes.idPerfil != this.usuarioModel.idPerfil ){
      datas.push({ "idtc": 1, "antes": 	this.usuarioModelAntes.idPerfil , "despues":this.usuarioModel.idPerfil, "observacion": "CAMBIO DESDE FRONT" })
      datas.push({ "idtc": 4, "antes": 	this.usuarioModelAntes.idPerfil , "despues":this.usuarioModel.idPerfil, "observacion": "CAMBIO DESDE FRONT" })
      console.log("update ==> Id perfil dierentees ==>")
    }
    if(this.usuarioModelAntes.idHorario != this.usuarioModel.idHorario ){
      console.log("update ==> Id Horario dierentees ==>")
      datas.push({ "idtc": 3, "antes": 	this.usuarioModelAntes.idHorario , "despues":this.usuarioModel.idHorario, "observacion": "CAMBIO DESDE FRONT" })
    
    }

    if(this.usuarioModelAntes.idHoraComida != this.usuarioModel.idHoraComida ){
      datas.push({ "idtc": 6, "antes": 	this.usuarioModelAntes.idHoraComida , "despues":this.usuarioModel.idHoraComida, "observacion": "CAMBIO DESDE FRONT" })
      console.log("update ==> Id Horario comida  dierentees ==>")
    }
    if(this.usuarioModelAntes.idDiaDescanso != this.usuarioModel.idDiaDescanso ){
      datas.push({ "idtc": 2, "antes": 	this.usuarioModelAntes.idDiaDescanso , "despues":this.usuarioModel.idDiaDescanso, "observacion": "CAMBIO DESDE FRONT" })
      console.log("update ==> Id dia  dierentees ==>")
    }
    if(datas.length > 0){
      var peticion =  {
        "supervisor": this.usrActivo.idEmpleado,"empleado": this.usuarioModel.noEmpleado, "ip": "0.0.0.0", "cambios":datas
        
    }
    console.log("update() ==> json==>",peticion," ==> datas ==>",datas);
    this.mantenimientoUsrServcie.updateUsr(JSON.stringify(peticion))
      .subscribe(
      peticion => {

        
          swal.fire('Usuario Actualizado', `${peticion.descripcion}`, 'success');
          this.router.navigate(['mantenimientoUsr']);
        },
        err => {
          this.errores = err.error.errors as string[];
          console.error('Código del error desde el backend: ' + err.status);
          console.error(err.error.errors);
        }
      )
    }

    /*
    
      */
  }


}
