import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ReportesmdcService } from '../services/reportesMdcService';
import { PaginationInstance } from 'ngx-pagination';
import { formatDate } from '@angular/common';
import { ColFolio } from '../reporte-asigna/ColFolio';
import * as XLSX from 'xlsx';
import { MantenimientoUsrService } from '../mantenimiento-usr/mantenimiento-usr.ervice';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService'; 
import { saveAs } from 'file-saver';
 
@Component({
  selector: 'app-reporte-tiempo-dmdc',
  templateUrl: './reporte-tiempo-dmdc.component.html',
  styleUrls: ['../css/mesaDeControl.css']
})
export class ReporteTiempoDMdcComponent implements OnInit {

  @ViewChild('table', { static: false }) TABLE: ElementRef;
  title = 'Excel';
  loading: boolean = false;
  filtroSelect: number = 2;
  showSelect: boolean = false;
  showtetx: boolean = false;
  filtroPlaceHolder: string = "";
  filtroType: string = "text";
  dtoFiltro: string = "";
  ffechaInicio: {day:number,year: number, month: number};
  ffechaFin: {day:number,year: number, month: number};
  mascarausar:string="00000000";
  minlength = 0;
  maxlength = 0;
  activaBor:boolean= false;
  captcha:string;
  respCaptch:string;
  isbad:boolean=false;
  tittleBotton:string="";
  
  constructor(private reportesService: ReportesmdcService, private mantenimiento: MantenimientoUsrService, private userService: UserService) { }
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 8,
    currentPage: 1
  };
  empleadoSelect: number;
  usrActivo: UsuarioModel;
  fInicio: string = "";
  fFinal: string = "";
  fechaActual: Date;
  fechaActualR: Date = new Date();
  config: any;

  collection = { count: 60, data: [] };
  foliosReport: ColFolio[];

  ngOnInit(): void {
    this.usrActivo = this.userService.getUserLoggedIn();
    this.loadDataReport()
  }
  regresar() {
    this.config =
    {
      itemsPerPage: 8,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
  }
  loadDataReport(): void {
    console.log("-------------------***");
    this.foliosReport = [];
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null ) 
    {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fFinal = this.ffechaFin.day+"/"+this.ffechaFin.month+"/"+this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) 
    {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fInicio= this.ffechaInicio.day+"/"+this.ffechaInicio.month+"/"+this.ffechaInicio.year;
    }

    if(  this.dtoFiltro.length >= this.minlength &&  this.dtoFiltro.length <=this.maxlength){
      this.activaBor= false;
      var peticion = {
        "fInicio": this.fInicio, "fFinal": this.fFinal, "ban": (this.filtroSelect == 3) ? 2 : this.filtroSelect, "temp": this.dtoFiltro
      }
      console.log(" loadData() ===> ", peticion)
      this.fFinal = this.converir(this.fFinal);
      this.fInicio = this.converir(this.fInicio);
      this.collection.data = [];
      this.config = {
        itemsPerPage: 8,
        currentPage: 1,
        totalItems: this.collection.data.length
      };
      var timpoTotal;
      this.reportesService.getReportetiempoDe(JSON.stringify(peticion)).subscribe(
        resp => {
  
          if (resp.codigo == 2) {
            if (resp.dato != null) {
              if(resp.dato.length>0){
              resp.dato.forEach(element => {
                if (this.filtroSelect == 3) {
                  timpoTotal = this.formatDMH(this.tiempoEntreHoras(element.hrAtencion, element.hrRespuesta));
                  if (this.nuevoFiltro(timpoTotal, this.dtoFiltro)) {
                    this.collection.data.push(element)
                  }
                } else {
                  this.collection.data.push(element)
                }
  
              });
            }else{
              this.collection.data = [];
            }
            } else {
              this.collection.data = [];
            }
  
          }
  
          this.config = {
            itemsPerPage: 8,
            currentPage: 1,
            totalItems: this.collection.data.length
          };
          this.loading = false
  
  
  
  
        }, err => {
          this.loading = false;
          console.log("loadData()=> ", err)
        })
    }else{
      this.activaBor= true;
      this.loading=false;
    }

  

  }
  converirW(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[1] + "/" + nvalo[0] + "/" + nvalo[2];
  }
  converir(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[2] + "-" + nvalo[1] + "-" + nvalo[0];
  }
  nuevoFiltro(tempAtencion, filtro): boolean {
    var dp = tempAtencion.split(":");
    var nFil = dp[0].split(",");
    var valRet = false;
    switch (filtro) {
      case "10001":
        if (nFil.length > 1) {
          valRet = false;
        } else {
          if (dp[0] > 0)
            valRet = false;
          else if (dp[1] >= 0 && dp[1] < 5)
            valRet = true;

        }
        break;
      case "10002":
        if (nFil.length > 1) {
          valRet = false;
        } else
          if (dp[0] > 0)
            valRet = false;
          else if (dp[1] >= 5 && dp[1] < 10)
            valRet = true;
        break;
      case "10003":
        if (nFil.length > 1) {
          valRet = false;
        } if (dp[0] > 0)
          valRet = false;
        else if (dp[1] >= 10 && dp[1] < 15)
          valRet = true;
        break;
      case "10004":
        if (nFil.length > 1) {
          valRet = true;
        } if (dp[0] > 0)
          valRet = true;
        else if (dp[1] >= 15)
          valRet = true;
        break;
    }
    return valRet;
  }
  filtrosActivar(): void {
    this.activaBor = false;
    switch (Number.parseInt(this.filtroSelect.toString())) {
      case 2:
        this.showSelect = false;
        this.showtetx = false;
        this.dtoFiltro = "";
        this.minlength = 0;
        this.maxlength = 0;
        break;
      case 1:
        this.showSelect = false;
        this.showtetx = true;
        this.filtroPlaceHolder = "Número Empleado";
        this.filtroType = "text";
        this.dtoFiltro = "";
        this.mascarausar= "00000000"
        this.minlength = 5;
        this.maxlength = 10;
        break;
      case 3:
        this.showSelect = true;
        this.showtetx = false;
        this.filtroPlaceHolder = "Rango Tiempo";
        this.filtroType = "number";
        this.dtoFiltro = "0";
        this.minlength = 5;
        this.maxlength = 10;
        break;

    }
  }
  tiempoEntreHoras(date1, date2): string {
    var formatted;
    try {
      var navegat = this.navegatior();
      var start_actual_time;
      var end_actual_time;
      var tiempoT;
      if (navegat == "INTERNET EXPLORER") {
        var fechaSplit = date1.split(" ");
        var fechDate1 = fechaSplit[0].split("-");
        var horaDate1 = fechaSplit[1].split(":");
        var fechaSplit2 = date2.split(" ");
        var fechDate2 = fechaSplit2[0].split("-");
        var horaDate2 = fechaSplit2[1].split(":");
        start_actual_time = new Date(fechDate1[0], fechDate1[1] - 1, fechDate1[2], horaDate1[0], horaDate1[1], horaDate1[2]);
        end_actual_time = new Date(fechDate2[0], fechDate2[1] - 1, fechDate2[2], horaDate2[0], horaDate2[1], horaDate2[2]);
        tiempoT = end_actual_time - start_actual_time;
      } else {
        start_actual_time = new Date(date1);
        end_actual_time = new Date(date2);
        tiempoT = end_actual_time - start_actual_time;
      }
      var diff = tiempoT;
      var diffSeconds = diff / 1000;
      var HH = Math.floor(diffSeconds / 3600);
      var SS = (diffSeconds % 3600) % 60;
      diffSeconds = diffSeconds - SS;
      var MM = (diffSeconds % 3600) / 60;
      var DD = 0;
      SS = Math.round(SS)
      if (HH > 24) {
        DD = (HH / 24);
        DD = ~~DD;
        HH = HH % 24;
      }
      formatted = DD + "-" + HH + "-" + MM + "-" + SS;
    } catch (e) {
    }

    return formatted;
  }
  navegatior(): string {
    var navegador = navigator.userAgent;
    var msie = navegador.indexOf("MSIE ");
    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
      return "INTERNET EXPLORER";
    } else if (navigator.userAgent.indexOf('Firefox') != -1) {
      return "MOZILA FIREFOX";
    } else if (navigator.userAgent.indexOf('Chrome') != -1) {
      return "GOOGLE CHROME";
    } else if (navigator.userAgent.indexOf('Opera') != -1) {
      return "OPERA";
    } else {
      return "OTRO";
    }
  }
  formatDMH(forma): string {
    var ret = null;
    try {
      forma = forma.split("-");
      var d1s = ((forma[0] == 0) ? ("") : (forma[0] == 1) ? (forma[0] + " Dia , ") : (forma[0] + " Dias ,"));
      var h1s = ((forma[1] == 0) ? ("00") : ((forma[1] < 10) ? "0" + forma[1] : forma[1]));
      var m1s = ((forma[2] == 0) ? ("00") : ((forma[2] < 10) ? "0" + forma[2] : forma[2]));
      var s1s = ((forma[3] == 0) ? ("00") : ((forma[3] < 10) ? "0" + forma[3] : forma[3]));
      ret = (d1s + h1s + ":" + m1s + ":" + s1s)
    } catch (e) {
      // TODO: handle exception
    }

    return ret;
  }

  ExportTOExcel() {
    if (this.captcha == this.respCaptch) {
      this.isbad = false;
      this.loading = true;

      $("#closeModal").click();

      //      -----------------
      this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null ) 
    {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fFinal = this.ffechaFin.day+"/"+this.ffechaFin.month+"/"+this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) 
    {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fInicio= this.ffechaInicio.day+"/"+this.ffechaInicio.month+"/"+this.ffechaInicio.year;
    }

      var peticion = {
        "fInicio": this.fInicio, "fFinal": this.fFinal, "ban": (this.filtroSelect == 3) ? 3 : this.filtroSelect, "temp": this.dtoFiltro
      }
        console.log(peticion)
        this.reportesService.getReportetiempoDeExcel(JSON.stringify(peticion)).subscribe(
          resp => {
  
           try {
            if (resp.codigo == 2) {
              if (resp.dato != null) {
                this.downloadFile(resp.dato, "application/vnd.openxmlformats-officedocument.spreadsheetml")
                
  
              }
  
            }
            this.loading = false
           } catch (error) {
            this.loading = false
           }
           
  
          }, err => {
            this.loading = false;
            console.log("loadData()=> ", err)
          })
      /*
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Reporte');
    XLSX.writeFile(wb, 'ReporteTiempoDetalle_.xlsx');*/

  } else {
    this.isbad = true;
    if (this.respCaptch.length == 0) {
      this.tittleBotton = "Captcha es requerido"
    } else if (this.respCaptch.length < 8) {
      this.tittleBotton = "Captcha tiene que ser de 8 posiciones"
    } else {
      this.tittleBotton = "Captcha diferente "
    }


  }
  }

 
  creaCodigo() {
    this.tittleBotton = ""
    this.isbad = false
    this.captcha = this.randomString(8,
      '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ');
    this.respCaptch = "";
  }
  randomString(length, chars): string {
    var result = '';
    for (var i = length; i > 0; --i)
      result += chars[Math.round(Math
        .random()
        * (chars.length - 1))];
    return result;
  }

  downloadFile(blobContent, tyCont): void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});

    saveAs(blob, 'ReporteTiempoDetalle_.xlsx');
  }
  base64toBlob(base64Data, contentType): Blob {
    contentType = contentType || '';
    let sliceSize = 1024;
    let byteCharacters = atob(base64Data);
    let bytesLength = byteCharacters.length;
    let slicesCount = Math.ceil(bytesLength / sliceSize);
    let byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }


}
