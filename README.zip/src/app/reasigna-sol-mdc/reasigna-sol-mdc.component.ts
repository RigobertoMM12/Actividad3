import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { PaginationInstance } from 'ngx-pagination';
import { formatDate } from '@angular/common';
import { ColFolio } from '../reporte-asigna/ColFolio';
import { MantenimientoUsrService } from '../mantenimiento-usr/mantenimiento-usr.ervice';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService';
import { IniciomdcService } from '../iniciomdc/iniciomdc.service';
import { PeticionFolio } from '../iniciomdv/model/peticionFolio';
import { EmpleadoA } from '../iniciomdv/model/empleadosA';
import { SolicitudMdc } from '../iniciomdc/model/SolicitudMdc';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-reasigna-sol-mdc',
  templateUrl: './reasigna-sol-mdc.component.html',
  styleUrls: ['../css/mesaDeControl.css']
})
export class ReasignaSolMdcComponent implements OnInit {


  title = 'Excel';
  loading: boolean = false;
  filtroSelect: number = 1;
  showSelect: boolean = false;
  showtetx: boolean = false;
  filtroPlaceHolder: string = "Número Empleado";
  filtroType: string = "number";
  dtoFiltro: string = "";
  empleados: EmpleadoA[];
  peticionFolio: PeticionFolio;
  operadorSelect: number = 0;
  totalPendientes: number = 0;
  solicitudAsigna: string = "";
  prioridad: number = 0;
  banTodas:number=0;
  mascarausar:string="00000000";
  minlength = 5;
  maxlength = 10;
  solicitudSelect: SolicitudMdc = new SolicitudMdc();
  ffechaInicio: {day:number,year: number, month: number};
  ffechaFin: {day:number,year: number, month: number};
  activaBor :boolean= false;
  constructor(private iniciosmdvservice: IniciomdcService, private mantenimiento: MantenimientoUsrService, private userService: UserService) { }
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 8,
    currentPage: 1
  };
  empleadoSelect: number;
  usrActivo: UsuarioModel;
  fInicio: string = "";
  fFinal: string = "";
  fechaActual: Date;
  fechaActualR: Date = new Date();
  config: any;

  collection = { count: 60, data: [] };
  foliosReport: ColFolio[];

  ngOnInit(): void {
    this.usrActivo = this.userService.getUserLoggedIn();

  }
  regresar() {
    this.config =
    {
      itemsPerPage: 8,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
  }
  loadDataReport(): void {
    this.foliosReport = [];
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null ) 
    {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fFinal = this.ffechaFin.day+"/"+this.ffechaFin.month+"/"+this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) 
    {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fInicio= this.ffechaInicio.day+"/"+this.ffechaInicio.month+"/"+this.ffechaInicio.year;
    }

    this.peticionFolio = new PeticionFolio();
    this.peticionFolio.fFinal = this.fFinal;
    this.peticionFolio.fInicio = this.fInicio;
    
    this.peticionFolio.noEmpleado = Number(this.dtoFiltro);

    if(  this.peticionFolio.noEmpleado.toString().length >= this.minlength &&   this.peticionFolio.noEmpleado.toString().length <=this.maxlength){
      this.activaBor= false;
      this.collection.data = [];
      this.config = {
        itemsPerPage: 8,
        currentPage: 1,
        totalItems: this.collection.data.length
      };
      console.log(this.peticionFolio)
      this.iniciosmdvservice.getFoliosAlta(this.peticionFolio).subscribe(
        resp => {
  
          if (resp.codigo == 2) {
            if (resp.dato != null) {
              if (resp.dato.length > 0) {
                resp.dato.forEach(element => {
                  if (element.datosMesa.estado != 'POR ATENDER' && element.analista.idAnalista == Number(this.dtoFiltro))
                    this.collection.data.push(element)
  
                });
              } else {
                this.collection.data = [];
              }
            } else {
              this.collection.data = [];
            }
  
          }
  
          this.config = {
            itemsPerPage: 8,
            currentPage: 1,
            totalItems: this.collection.data.length
          };
          this.loading = false
  
  
  
  
        }, err => {
          this.loading = false;
          console.log("loadData()=> ", err)
        })
    }else{
      this.activaBor= true;
      this.loading= false;
    }
    

  }
  asignaSolicitudes(): void {
    if (this.operadorSelect != 0) {
      if( this.banTodas == 2){
        this.collection.data.forEach(element =>{
          this.solicitudSelect = element;
          this.asignaFolioManual();
        })
      }else{
        this.asignaFolioManual();
      }
    
    }
    
  }
  asignaFolioManual(): void {
    this.loading = true;
    if (this.operadorSelect != 0) {
      var peticion =
      {
        noSolicitud: this.solicitudSelect.solicitud.idSolicitud,
        noAdmin: this.usrActivo.idEmpleado,
        ip: "00.00.00.00",
        prioridad: this.prioridad,
        caractSol: (this.solicitudSelect.solicitud.condicion == 'CLIENTE NUEVO') ? 8001 : 8002,
        idSucursal: this.solicitudSelect.surcusal.idSucursalOrigen,
        reasignacion: 1,
        noEmpleado: this.operadorSelect,
      }

      console.log("asignaFolioManual() ===> peticion ==> ", peticion);
      this.iniciosmdvservice.asignaSolicitudManual(JSON.stringify(peticion)).subscribe(
        data => {
          this.loading = false;
          if (data.codigo == 2) {
            Swal.fire('Asignación', `Se ha asignado la solicitud ` + this.solicitudAsigna, 'success');
            this.loadDataReport();
          }
        });
    } else {
      this.loading = false;
    }

  }
  converirW(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[1] + "/" + nvalo[0] + "/" + nvalo[2];
  }
  converir(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[2] + "-" + nvalo[1] + "-" + nvalo[0];
  }
  asignaFolio(folA: SolicitudMdc,ban:number): void {
    this.loading = true;
    this.empleados = [];
    this.operadorSelect = 0;
    this.totalPendientes = 0;
    this.banTodas = ban;
    if(ban == 1){
      this.solicitudAsigna = ""+folA.solicitud.idSolicitud;
      this.solicitudSelect = folA;
    }else{
      this.solicitudAsigna ="";
      this.collection.data.forEach(element => {
        this.solicitudAsigna += element.solicitud.idSolicitud
        this.solicitudAsigna +=","
      });
      this.solicitudSelect = null;
    }
    this.iniciosmdvservice.getEmpleadoActivos({ tipoSolicitud:8001}).subscribe(
      data => {
        let empleado = data.dato;
        empleado.forEach(dato => {
          this.empleados.push(dato)
        })
        if (this.usrActivo.idPerfil == 2003 || this.usrActivo.idPerfil == 2002) {
          var adminCre = new EmpleadoA();
          if(this.usrActivo.nombreEmpleado != null){
            var resuls =this.usrActivo.nombreEmpleado.split(" ");
             adminCre.nombre  = resuls[0];
             adminCre.aPaterno = resuls[1];
             adminCre.aMaterno = resuls[2];
           }
          adminCre.maxSol = 4;
          adminCre.idEmpleado = this.usrActivo.idEmpleado;
          adminCre.noSolPendientes = this.usrActivo.solPendientes;
          this.empleados.push(adminCre)
        }
        this.loading = false;
      });
  }
  filtrosActivar(): void {
    switch (Number.parseInt(this.filtroSelect.toString())) {
      case 2:
        this.showSelect = false;
        this.showtetx = false;
        break;
      case 1:
        this.showSelect = false;
        this.showtetx = true;
        this.filtroPlaceHolder = "Número Empleado";
        this.filtroType = "tel";
        this.dtoFiltro = "";
        this.mascarausar= "00000000"
        this.minlength = 5;
        this.maxlength = 10;
        break;
      case 3:
        this.showSelect = true;
        this.showtetx = false;
        this.filtroPlaceHolder = "Rango Tiempo";
        this.filtroType = "number";
        this.dtoFiltro = "0";
        break;

    }
  }
  changeAsigna(): void {
    this.prioridad = 0;
    this.totalPendientes = 0;
    this.empleados.forEach(emple => {
      if (emple.idEmpleado == this.operadorSelect)
        this.totalPendientes = emple.noSolPendientes;
    })
  }

}
