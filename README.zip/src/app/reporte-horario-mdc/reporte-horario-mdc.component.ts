import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ReportesmdcService } from '../services/reportesMdcService';
import { PaginationInstance } from 'ngx-pagination';
import { formatDate } from '@angular/common';
import { ColFolio } from '../reporte-asigna/ColFolio';
import * as XLSX from 'xlsx';
import { MantenimientoUsrService } from '../mantenimiento-usr/mantenimiento-usr.ervice';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-reporte-horario-mdc',
  templateUrl: './reporte-horario-mdc.component.html',
  styleUrls: ['../css/mesaDeControl.css']
})
export class ReporteHorarioMdcComponent implements OnInit {

  @ViewChild('table', { static: false }) TABLE: ElementRef;
  title = 'Excel';
  loading: boolean = false;
  filtroSelect: number = 2;
  showSelect: boolean = false;
  ffechaInicio: {day:number,year: number, month: number};
  constructor(private reportesService: ReportesmdcService, private mantenimiento: MantenimientoUsrService, private userService: UserService) { }
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 8,
    currentPage: 1
  };
  empleadoSelect: number;
  usrActivo: UsuarioModel;
  fInicio: string = "";
  fechaActual: Date;
  fechaActualR: Date = new Date();
  config: any;

  collection = { count: 60, data: [] };
  foliosReport: ColFolio[];
  captcha:string;
  respCaptch:string;
  isbad:boolean=false;
  tittleBotton:string="";
  ngOnInit(): void {
    this.usrActivo = this.userService.getUserLoggedIn();
    this.loadDataReport()
  }
  loadDataReport(): void {
    this.foliosReport = [];
    this.loading = true;
    this.fechaActual = new Date();

    if (this.ffechaInicio == null) 
    {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fInicio = ((this.ffechaInicio.day.toString().length == 1)?"0"+this.ffechaInicio.day:this.ffechaInicio.day)+"/"+((this.ffechaInicio.month.toString().length == 1)?"0"+this.ffechaInicio.month:this.ffechaInicio.month)+"/"+this.ffechaInicio.year;
    }

    var peticion = {
      "fecha": this.fInicio, "ban": 1, "temp": 1
    }
    console.log(" loadData() ===> ", peticion)
    this.fInicio = this.converir(this.fInicio);

    this.collection.data = [];
    this.config = {
      itemsPerPage: 8,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
    this.crearArrResp();
    this.reportesService.getHorarios(JSON.stringify(peticion)).subscribe(
      resp => {

        if (resp.codigo == 2) {
          if (resp.dato != null) {
            if (resp.dato.length > 0) {
              resp.dato.forEach(element => {
                element.horario  = ((element.hora<10)?"":"")+element.hora+":00"+ " a "+ (((element.hora<9)?"":"")+(Number(element.hora)+ 1 ))+":00";
                this.collection.data[Number(element.hora)] = element;


              });
            } 

          } 
        }

        this.config = {
          itemsPerPage: 8,
          currentPage: 1,
          totalItems: this.collection.data.length
        };
        this.loading = false




      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      })

  }

  converir(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[2] + "-" + nvalo[1] + "-" + nvalo[0];
  }
  crearArrResp(): void {
    for (var i = 0; i < 24; i++) {
      this.collection.data.push({ horario: ((i < 10) ? "0" : "") + i + ":00" + " a " + (((i < 9) ? "0" : "") + (i + 1)) + ":00", ingresadas: "0", aprobadas: "0", observadas: "0", rechazadas: "0" });
    }
  }
  ExportTOExcel() {
    if(this.captcha == this.respCaptch){

      this.isbad = false;
      $("#closeModal").click();
      this.loading = true;
      this.fechaActual = new Date();
  
      if (this.ffechaInicio == null) 
      {
        this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
      } else 
      {
        this.fInicio = ((this.ffechaInicio.day.toString().length == 1)?"0"+this.ffechaInicio.day:this.ffechaInicio.day)+"/"+((this.ffechaInicio.month.toString().length == 1)?"0"+this.ffechaInicio.month:this.ffechaInicio.month)+"/"+this.ffechaInicio.year;
      }
  
      var peticion = {
        "fecha": this.fInicio
      }

      this.reportesService.getHorariosExcel(JSON.stringify(peticion)).subscribe(
        resp => {

        try {
          if (resp.codigo == 2) {
            if (resp.dato != null) {
              this.downloadFile(resp.dato, "application/vnd.openxmlformats-officedocument.spreadsheetml")

            }

          }
          this.loading = false
        } catch (error) {
          this.loading = false
        }
          

        }, err => {
          this.loading = false;
          console.log("loadData()=> ", err)
        })
/*
      const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Reporte');
      XLSX.writeFile(wb, 'ReporteHorarios_.xlsx');*/
    }else{
      this.isbad = true;
      if( this.respCaptch.length == 0){
        this.tittleBotton  = "Captcha es requerido"
      }else if( this.respCaptch.length < 8){
        this.tittleBotton  = "Captcha tiene que ser de 8 posiciones"
      }else{
        this.tittleBotton  = "Captcha diferente "
      }
     
    
    }
   
  }

  creaCodigo(){
    this.tittleBotton  = ""
    this.isbad = false
   this.captcha=  this.randomString(8,
      '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ');
      this.respCaptch = "";
  }
  randomString(length, chars):string{
    var result = '';
    for (var i = length; i > 0; --i)
    result += chars[Math.round(Math
        .random()
        * (chars.length - 1))];
    return result;
  }
  
  downloadFile(blobContent, tyCont): void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});

    saveAs(blob, 'ReporteHorarios_.xlsx');
  }
  base64toBlob(base64Data, contentType): Blob {
    contentType = contentType || '';
    let sliceSize = 1024;
    let byteCharacters = atob(base64Data);
    let bytesLength = byteCharacters.length;
    let slicesCount = Math.ceil(bytesLength / sliceSize);
    let byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }

}


