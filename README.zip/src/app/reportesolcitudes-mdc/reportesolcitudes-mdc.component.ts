import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ReportesmdcService } from '../services/reportesMdcService';
import { PaginationInstance } from 'ngx-pagination';
import { formatDate } from '@angular/common';
import { ColFolio } from '../reporte-asigna/ColFolio';
import * as XLSX from 'xlsx';
import { MantenimientoUsrService } from '../mantenimiento-usr/mantenimiento-usr.ervice';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService';
import { stringify } from 'querystring';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-reportesolcitudes-mdc',
  templateUrl: './reportesolcitudes-mdc.component.html',
  styleUrls: ['../iniciomdc/iniciomdc.component.css','../css/mesaDeControl.css']
})
export class ReportesolcitudesMdcComponent implements OnInit {

  @ViewChild('table', { static: false }) TABLE: ElementRef;
  title = 'Excel';
  loading: boolean = false;
  filtroSelect: number = 7;
  showSelect: boolean = false;
  showtetx: boolean = false;
  filtroPlaceHolder: string = "";
  filtroType: string = "text";
  dtoFiltro: string = "";
  mostrarNivel = false;
  datosReproceso: any[];
  datosTodos:any[];
  cantReproceso: number = 0;
  datoSelec: any;
  top: string = '50px';
  ffechaInicio: {day:number,year: number, month: number};
  ffechaFin: {day:number,year: number, month: number};
  mascarausar:string="00000000";
  minlength = 0;
  maxlength = 0;
  activaBor:boolean= false;
  captcha:string;
  respCaptch:string;
  isbad:boolean=false;
  tittleBotton:string="";

  constructor(private reportesService: ReportesmdcService, private mantenimiento: MantenimientoUsrService, private userService: UserService) { }
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 8,
    currentPage: 1
  };
  empleadoSelect: number;
  usrActivo: UsuarioModel;
  fInicio: string = "";
  fFinal: string = "";
  fechaActual: Date;
  fechaActualR: Date = new Date();
  config: any;

  collection = { count: 60, data: [] };
  foliosReport: ColFolio[];

  ngOnInit(): void {
    this.usrActivo = this.userService.getUserLoggedIn();
    this.loadDataReport()
  }
  regresar() {
    this.config =
    {
      itemsPerPage: 8,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
  }
  loadDataReport(): void {
    this.mostrarNivel = false;
    this.datosTodos=[];
    console.log("-------------------***");
    this.foliosReport = [];
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null ) 
    {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fFinal = this.ffechaFin.day+"/"+this.ffechaFin.month+"/"+this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) 
    {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fInicio= this.ffechaInicio.day+"/"+this.ffechaInicio.month+"/"+this.ffechaInicio.year;
    }

    if(  this.dtoFiltro.length >= this.minlength &&  this.dtoFiltro.length <=this.maxlength){
      this.activaBor= false;
      var peticion = {
        "fInicio": this.fInicio, "fFinal": this.fFinal, "ban": this.filtroSelect, "temp": this.dtoFiltro
      }
      console.log(" loadData() ===> ", peticion)
      this.fFinal = this.converir(this.fFinal);
      this.fInicio = this.converir(this.fInicio);
      this.collection.data = [];
      this.config = {
        itemsPerPage: 8,
        currentPage: 1,
        totalItems: this.collection.data.length
      };
      var id = 0;
      var solicitudActual = 0;
      this.reportesService.getReportetiempoDe(JSON.stringify(peticion)).subscribe(
        resp => {
  
          if (resp.codigo == 2) {
            if (resp.dato != null) {
              if (resp.dato.length > 0) {
  
                resp.dato.forEach(element => {
                  element.id = id++;
                  var docObservados = element.docObservados.split("||");
                  var ncadena = "";
                  var ndoc = "";
                  if (docObservados.length > 0) {
                    if (docObservados[0] != ": ") {
                      for (var a = 0; a < docObservados.length; a++) {
                        ndoc = docObservados[a].split("/");
                        ncadena += ndoc[0] + "/Pag:" + ndoc[1] + "; ";
  
                      }
                    }
                  }
                  element.docObservados = ncadena;
                  element.statusPedidoMesaDes = this.descStatus(element.statusPedidoMesa);
                  if (element.noSolicitud != solicitudActual) {
                    solicitudActual = element.noSolicitud;
                    element.statusActual = this.descStatus(element.statusActual);
  
                    this.collection.data.push(this.createDetallesReporte(element))
                    this.collection.data[this.collection.data.length - 1].reprocesos.push(this.createRepocesoReporte(element));
  
                  } else {
                    this.collection.data[this.collection.data.length - 1].reprocesos.push(this.createRepocesoReporte(element));
                  }
                  this.datosTodos.push(element)
                  // this.collection.data.push(element)
  
                });
              } else {
                this.collection.data = [];
              }
            } else {
              this.collection.data = [];
            }
  
          }
  
          this.config = {
            itemsPerPage: 8,
            currentPage: 1,
            totalItems: this.collection.data.length
          };
          this.loading = false
  
  
  
  
        }, err => {
          this.loading = false;
          console.log("loadData()=> ", err)
        })
    }else{
      this.activaBor= true;
      this.loading=false;
    }

   

  }
  createDetallesReporte(datos) {
    return {
      id: datos.id,
      idSucursalGes: datos.idSucursalGes,
      nombreSuc: datos.nombreSuc,
      nombreCliente: datos.nombreCliente,
      apellidoPCliente: datos.apellidoPCliente,
      apellidoMCliente: datos.apellidoMCliente,
      cu: datos.cu,
      noSolicitud: datos.noSolicitud,
      statusActual: datos.statusActual,
      reprocesos: []
    };
  }
  createRepocesoReporte(datos) {
    return {

      noReenvio: datos.noReenvio + 1,
      noEmpleado: datos.noEmpleado,
      nombreEmpleado: datos.nombreEmpleado,
      apellidoPEmpleado: datos.apellidoPEmpleado,
      apellidoMEmpleado: datos.apellidoMEmpleado,
      statusPedidoMesa: datos.statusPedidoMesa,
      observacionGral: datos.observacionGral,
      horaRespuesta: datos.horaRespuesta,
      horaIngreso: datos.horaIngreso,
      horaAsignacion: datos.horaAsignacion,
      horaAtencion: datos.horaAtencion,
      docObservados: datos.docObservados,
      noSolicitud: datos.noSolicitud,

    };
  }

  converirW(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[1] + "/" + nvalo[0] + "/" + nvalo[2];
  }
  converir(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[2] + "-" + nvalo[1] + "-" + nvalo[0];
  }
  obtenerPosicion(dataConsulta): void {
    this.datoSelec = dataConsulta;
    console.log(dataConsulta.id);
    this.datosReproceso = [];
    if (this.mostrarNivel)
      this.mostrarNivel = false
    else
      this.mostrarNivel = true;

    this.datosReproceso = dataConsulta.reprocesos;
    var p = $('#id' + dataConsulta.id);
    var position = p.position();
    this.top = "" + (position.top + 160) + "px"

  }
  filtrosActivar(): void {
    this.activaBor = false;
    this.dtoFiltro = "0";
    switch (Number.parseInt(this.filtroSelect.toString())) {
      case 7:
        this.showSelect = false;
        this.showtetx = false;
        this.minlength = 0;
        this.maxlength = 0;
        this.dtoFiltro = "";
        break;
      case 8:
        this.showSelect = false;
        this.showtetx = true;
        this.filtroPlaceHolder = "Código de Agencia";
        this.filtroType = "text";
        this.minlength = 3;
        this.maxlength = 6;
        this.mascarausar= "00000000"
        this.dtoFiltro = "";
        break;
      case 9:
        this.showSelect = false;
        this.showtetx = true;
        this.filtroPlaceHolder = "Número de Solicitud";
        this.filtroType = "text";
        this.dtoFiltro = "";
        this.minlength = 3;
        this.maxlength = 8;
        this.mascarausar= "00000000"
        break;

    }
  }
  descStatus(idSatt): string {
    var desSta: string = "";
    switch (idSatt) {
      case 7004:
        desSta = "AUTORIZADA MC"
        break;
      case 7005:
        desSta = "OBSERVADO MC"
        break;
      case 7007:
        desSta = "RECHAZADA MC"
        break;


    }
    return desSta;
  }
  ExportTOExcel() {
    if (this.captcha == this.respCaptch) {
      this.isbad = false;
      this.loading = true;

      $("#closeModal").click();

      //      -----------------
      this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null ) 
    {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fFinal = this.ffechaFin.day+"/"+this.ffechaFin.month+"/"+this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) 
    {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.fInicio= this.ffechaInicio.day+"/"+this.ffechaInicio.month+"/"+this.ffechaInicio.year;
    }


    var peticion = {
      "fInicio": this.fInicio, "fFinal": this.fFinal, "ban": this.filtroSelect, "temp": this.dtoFiltro
    }
        console.log(peticion)
        this.reportesService.getRepoSolicitudesExcel(JSON.stringify(peticion)).subscribe(
          resp => {
  
           try {
            if (resp.codigo == 2) {
              if (resp.dato != null) {
                this.downloadFile(resp.dato, "application/vnd.openxmlformats-officedocument.spreadsheetml")
                
  
              }
  
            }
            this.loading = false
           } catch (error) {
            this.loading = false
           }
           
  
          }, err => {
            this.loading = false;
            console.log("loadData()=> ", err)
          })
      /*
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Reporte');
    XLSX.writeFile(wb, 'ReporteSolicitudes_.xlsx');*/
  } else {
    this.isbad = true;
    if (this.respCaptch.length == 0) {
      this.tittleBotton = "Captcha es requerido"
    } else if (this.respCaptch.length < 8) {
      this.tittleBotton = "Captcha tiene que ser de 8 posiciones"
    } else {
      this.tittleBotton = "Captcha diferente "
    }


  }
  }
   creaCodigo() {
    this.tittleBotton = ""
    this.isbad = false
    this.captcha = this.randomString(8,
      '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ');
    this.respCaptch = "";
  }
  randomString(length, chars): string {
    var result = '';
    for (var i = length; i > 0; --i)
      result += chars[Math.round(Math
        .random()
        * (chars.length - 1))];
    return result;
  }

  downloadFile(blobContent, tyCont): void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});

    saveAs(blob, 'ReporteSolicitudes_.xlsx');
  }
  base64toBlob(base64Data, contentType): Blob {
    contentType = contentType || '';
    let sliceSize = 1024;
    let byteCharacters = atob(base64Data);
    let bytesLength = byteCharacters.length;
    let slicesCount = Math.ceil(bytesLength / sliceSize);
    let byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }

}
