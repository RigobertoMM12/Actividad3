import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import Swal from 'sweetalert2';
import { tap, timeout } from 'rxjs/operators';
import { FolioAlta } from './model/folioAlta';
import { IniciomdcService } from './iniciomdc.service';
import { PeticionFolio } from './model/peticionFolio';
import { PaginationInstance } from 'ngx-pagination';
import { HerperC } from '../helper/helper';
import { DtoExtra } from './model/dtoExtra';
import { formatDate } from '@angular/common';
import { EmpleadoA } from './model/empleadosA';
import { PeticionFolioFi } from './model/peticionFolioFi';
import { AsignaFolioModel } from './model/asignaFolioModel';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { StatusFinalCu } from './model/statusFinalCu';
import * as $ from 'jquery'
import { UserService } from '../header/UserService';
import { UsuariocModel } from '../header/model/usuariocModel';
import { SolicitudMdc } from './model/SolicitudMdc';
import { ListaExpediente } from './model/ListaExpediente';
import { ImagenM } from './model/ImagenM';
import { Referencia } from './model/Referencia';


@Component({
  selector: 'app-iniciomdc',
  templateUrl: './iniciomdc.component.html',
  styleUrls: ['./iniciomdc.component.css']
})
export class IniciomdcComponent implements OnInit,OnDestroy {
 @ViewChild('imgRef') img: ElementRef;
  solicitudes: SolicitudMdc[]  = [];

  solicudesxAtenter : SolicitudMdc[] = [];
  solicudesAsignados : SolicitudMdc[]= [];
  solicudesEnEvaluacion  :SolicitudMdc[]= [];
  solicudesAtendidas :SolicitudMdc[]= [];
  solicudesRechazadas: SolicitudMdc[]= [];
  solicudesObervadas : SolicitudMdc[]= [];
  
  foliosConstante = [];
  catAgirar:number=0;
  listaExpe :ListaExpediente[]=[];
  dtoEx :DtoExtra = new DtoExtra();
  valorActual:number=0;
  porcionActual:number=0;
  contaPage:number=0;
  docuementoSelect: ListaExpediente;
  solicitudSelect : SolicitudMdc = new SolicitudMdc();
  prioridad:number=0;
  pageSel:number=0;
  noExisteDocument:string;
  listaReferencias: Referencia[]=[];
  isExpediente:boolean;
  referenciaSele:Referencia
  messageErrorRef:string;
  validacionSolicitud:boolean=false;
  comentarioSolicitud:string;
  statusSolicitud:number=0;
  txtComAsesor:string="";
  comentarioAsesor:boolean= false;
  contadores : string[] = [];
  splitValues : string[]=[];
  dtoExtrac : string[]=[];
  empleados : EmpleadoA[];
  opcionSeleccionado :string; 
  loading = false;
  valSelec : string ="";
  fechaActual:Date;
  solicitudAsigna : number =0;
  operadorSelect : number =0;
  totalPendientes:number=0;
  dtoFiltro : string ="";
  showSelect : boolean = false;
  showtetx : boolean = false;
  filtroSelect : number= 6;
  filtroPlaceHolder :string= "";
  filtroType :string = "text";
  filtroMin :number=0;
  filtoMax : number = 0;
  mascarausar:string=""
  mostrarNivel = false;
  activaBor= false;
  comentarios : string;
  muestraOpera :boolean = true;  
  navV = { evaliacion: true, cliente:false,solicitud:false,mesa:false };
  asignaFolioModel : AsignaFolioModel = new AsignaFolioModel(); 
  messageError :string =""; 
  sEvaluaFolio : boolean = false; 
  exisSolPendie : boolean = false;
  usrActivo : UsuariocModel;
  top : string;
  left :string;
  statusValidacion = [
    {desc:"Por atender",decContador:"",isActivo:true},
    {desc:"Asignadas",decContador:"",isActivo:false},
    {desc:"En evaluacion",decContador:"",isActivo:false},
    {desc:"Atendidas",decContador:"",isActivo:false},
    {desc:"Rechazadas",decContador:"",isActivo:false},
    {desc:"Observadas",decContador:"",isActivo:false},
    {desc:"Todas",decContador:"",isActivo:false}

  ]
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 6,
    currentPage: 1
  };
  config: any;
  nvalo: string[];
  collection = { count: 60, data: [] };
  peticion :PeticionFolio = new PeticionFolio;
  reqFoliFi : PeticionFolioFi = new PeticionFolioFi();
  id:any;
  solPendientes:number;
  ffechaInicio: {day:number,year: number, month: number};
  ffechaFin: {day:number,year: number, month: number};
  idPerfil:number=0;
  solPendienteSs : any;
  isActivaSoli:boolean=false;
  todasT :number=0;
  //Metodos Iniciales Angular
  constructor(private iniciosmdvservice : IniciomdcService, public sanitizer: DomSanitizer,private userService: UserService ) { }

  ngOnDestroy():void{
    console.log("ngOnDestroy========>");
    if (this.id) 
    {
      clearInterval(this.id);
    }
  }

  ngOnInit(): void {
  
    this.loading  = true;
    this.usrActivo = this.userService.getUserLoggedIn();
    console.log("===============> getUserLoggedIn==>>>>>>ngOnInit====> Inicio ", this.userService.getUserLoggedIn())
    //setTimeout(() => {
      this.usrActivo = this.userService.getUserLoggedIn();
      this.idPerfil = this.usrActivo.idPerfil
      console.log("ngOnIntit()==> setTimeout ==> usrActivo ==>", this.usrActivo)
      this.loading  = false;
      if (this.usrActivo != null) {
        this.loadData(1);
      }
      this.id = setInterval(() => {
        this.refrescarTablaEstadoSala(); 
      }, 30000);

    //}, 200000 / 60);
  }
  
  //Termina Metodos Iniciales Angular

  //Metodos operacionales
  loadData(bande: number): void {
    console.log("loadData ==> bande ==>", bande)
    this.loading = true;
    this.fechaActual = new Date();
    var fechaFinal ="";
    var fechaInicio="";
  
   

    if (this.ffechaFin == null ) 
    {
      this.peticion.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.peticion.fFinal = this.ffechaFin.day+"/"+this.ffechaFin.month+"/"+this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) 
    {
      this.peticion.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.peticion.fInicio = this.ffechaInicio.day+"/"+this.ffechaInicio.month+"/"+this.ffechaInicio.year;
    }

    this.peticion.noEmpleado = this.usrActivo.id;
    console.log("loadData ==> peticion ==> ", this.peticion)
    if (bande == 3) 
    {
      this.loading = false;
      if (this.exisSolPendie == false) 
      {
        var nePeti = 
        {
          noEmpleado: this.peticion.noEmpleado,
          porAtender: parseInt(this.statusValidacion[0].decContador.split("Por atender : ")[1]),
          asignadas: parseInt(this.statusValidacion[1].decContador.split("Asignadas : ")[1]),
          enAtencion: parseInt(this.statusValidacion[2].decContador.split("En evaluacion : ")[1]),
          autorizadas: parseInt(this.statusValidacion[3].decContador.split("Atendidas : ")[1]),
          observadas: parseInt(this.statusValidacion[5].decContador.split("Observadas : ")[1]),
          rechazadas: parseInt(this.statusValidacion[4].decContador.split("Rechazadas : ")[1]),
          fInicio: this.peticion.fInicio,
          fFinal: this.peticion.fFinal,
        }
        console.log("loadData ==> newpeticion ==> ", nePeti);
        this.peticion.fFinal = this.converir(this.peticion.fFinal);
        this.peticion.fInicio = this.converir(this.peticion.fInicio);
        this.iniciosmdvservice.getFoliosAltaConstante(JSON.stringify(nePeti)).subscribe(data => 
        {
          if (data.codigo == 2) 
          {
            if (data.dato != null) {
              if (data.dato.length > 0) 
              {
                this.solPendienteSs = data.solPendienteSs;
                this.foliosConstante = data;
                this.exisSolPendie = true;
                console.log("loadData ==> getFoliosAltaConstante() ==> ", "Hay folios nuevos ")
                // this.asignaContadores(data, 1)
              }
            }
            
          } else
          {
            this.exisSolPendie = false;
          }
        }, erro => 
        {
          Swal.fire("Servicio no disponible", "", 'error');
          this.statusValidacion = [
            { desc: "Por atender", decContador: "Por atender : 0", isActivo: true },
            { desc: "Asignadas", decContador: "Asignadas : 0", isActivo: false },
            { desc: "En evaluacion", decContador: "En evaluacion : 0", isActivo: false },
            { desc: "Atendidas", decContador: "Atendidas : 0", isActivo: false },
            { desc: "Rechazadas", decContador: "Rechazadas : 0", isActivo: false },
            { desc: "Observadas", decContador: "Observadas  : 0", isActivo: false },
            { desc: "Todas", decContador: "Todas : 0", isActivo: false }

          ]
          this.loading = false;
        }
        );
      } else 
      {
        this.peticion.fFinal = this.converir(this.peticion.fFinal);
        this.peticion.fInicio = this.converir(this.peticion.fInicio);
      }
    } else if (this.filtroSelect == 6) 
    {
        if (bande == 1) 
        {

            this.iniciosmdvservice.getFoliosAlta(this.peticion).subscribe(
            data => 
            {
              this.solPendienteSs = data;
              this.isActivaSoli = false;
              this.asignaContadores(data, 1)
            }, erro => 
            {
              Swal.fire("Servicio no disponible", "", 'error');
              this.statusValidacion = [
                { desc: "Por atender", decContador: "Por atender : 0", isActivo: true },
                { desc: "Asignadas", decContador: "Asignadas : 0", isActivo: false },
                { desc: "En evaluacion", decContador: "En evaluacion : 0", isActivo: false },
                { desc: "Atendidas", decContador: "Atendidas : 0", isActivo: false },
                { desc: "Rechazadas", decContador: "Rechazadas : 0", isActivo: false },
                { desc: "Observadas", decContador: "Observadas  : 0", isActivo: false },
                { desc: "Todas", decContador: "Todas : 0", isActivo: false }

              ]
              this.loading = false;
            });
        } else 
        {
          console.log("getFoliosAltaComple () ==> ", this.peticion)
          this.iniciosmdvservice.getSolicitudesComple(this.peticion).subscribe(
            data => 
            {
              this.asignaContadores(data, 3);
            });
        }
    } else 
    {
        this.reqFoliFi.ban = Number.parseInt(this.filtroSelect.toString());
        this.reqFoliFi.temp = this.dtoFiltro;
        if(  this.reqFoliFi.temp.length >= this.filtroMin &&  this.reqFoliFi.temp.length<=this.filtoMax){
          this.activaBor= false;
          this.reqFoliFi.fFinal = this.peticion.fFinal
        this.reqFoliFi.fInicio = this.peticion.fInicio;
        console.log(this.reqFoliFi)
        this.iniciosmdvservice.getFoliosAltaFiltro(this.reqFoliFi).subscribe(
          data => 
          {
            this.asignaContadores(data, 2)
          })
        }else{
          this.loading = false;
          this.activaBor= true;
        }
        
    }

  }

  refrescarTablaEstadoSala():boolean
  {
    console.log("refrescarTablaEstadoSala() ==>>",new Date())
    this.loadData(3)
    // $$('#encasUnPwModal').modal('hide');
    return true;
  }
  
  asignaFolio(folA: SolicitudMdc): void
  {
    console.log("----------")
    this.loading = true;
    this.empleados = [];
    this.operadorSelect = 0;
    this.totalPendientes = 0;
    this.solicitudAsigna = folA.solicitud.idSolicitud;
    this.solicitudSelect = folA;
    this.iniciosmdvservice.getEmpleadoActivos({ tipoSolicitud: (this.solicitudSelect.solicitud.condicion == 'CLIENTE NUEVO') ? 8001 : 8002 }).subscribe(
      data => 
      {
        let empleado = data.dato;
        empleado.forEach(dato => {

          this.empleados.push(dato)
        })
        if (this.usrActivo.idPerfil == 2003 || this.usrActivo.idPerfil == 2001 || this.usrActivo.idPerfil == 2002) {
          var adminCre = new EmpleadoA();
          if(this.usrActivo.nombre != null){
           var resuls =this.usrActivo.nombre.split(" ");
            adminCre.nombre  = resuls[0];
            adminCre.aPaterno = resuls[1];
            adminCre.aMaterno = resuls[2];
          }
          adminCre.maxSol = 4;
          adminCre.idEmpleado = this.usrActivo.id;
          adminCre.noSolPendientes = 10;
          this.empleados.push(adminCre)
        }
        this.loading = false;
      });
  }

  asignaFolioManual(): void 
  {
    this.loading = true;
    if (this.operadorSelect != 0) 
    {
      var peticion = 
      {
        noSolicitud: this.solicitudSelect.solicitud.idSolicitud,
        noAdmin: this.usrActivo.id,
        ip: "00.00.00.00",
        prioridad: this.prioridad,
        caractSol: (this.solicitudSelect.solicitud.condicion == 'CLIENTE NUEVO') ? 8001 : 8002,
        idSucursal: this.solicitudSelect.surcusal.idSucursalOrigen,
        reasignacion: "",
        noEmpleado: this.operadorSelect,
      }

      console.log("asignaFolioManual() ===> peticion ==> ", peticion);
      this.iniciosmdvservice.asignaSolicitudManual(JSON.stringify(peticion)).subscribe(
        data => 
        {
          this.loading = false;
          if (data.codigo == 2) 
          {
            Swal.fire('Asignación', `Se ha asignado el folio ` + this.asignaFolioModel.folioAltaUnica, 'success');
            this.loadData(1);
          }
        });
    } else 
    {
      this.loading = false;
    }

  }

  saveStatusRef(): void 
  {
    this.validacionSolicitud = false;
    this.messageErrorRef = "";
    if (this.referenciaSele.status == 0) 
    {
      this.messageErrorRef = "Selecciona un status de documento"
    } else if ((this.referenciaSele.observacion == "" || this.referenciaSele.observacion == undefined))
    {
      this.messageErrorRef = "Ingresa comentarios"
    } else {
      var peticion = 
      {
        idRef: this.referenciaSele.idRef,
        observaciones: this.referenciaSele.observacion,
        status: this.referenciaSele.status,
        ip: "00.00.00.000",
        noEmpleado: this.usrActivo.id
      }
      this.loading = true;
      this.iniciosmdvservice.saveRefe(JSON.stringify(peticion)).subscribe(data => 
        {
        if (data.codigo == 2) 
        {
          this.loading = false;
          if (this.referenciaSele.status == 9001)
            this.referenciaSele.color = "blue"
          if (this.referenciaSele.status == 9002)
            this.referenciaSele.color = "orange"
          this.messageErrorRef = ""
          this.loading = false;
        } else 
        {
          try{
            this.messageErrorRef = data.descripcion;
            this.loading = false;
          }catch(e){
            this.messageErrorRef = "Ocurrio un error"
            this.loading = false;
          }
          
        }
      });

    }
  }

  saveStatusDocument(): void 
  {
    this.validacionSolicitud = false;
    this.messageError = "";
    if (this.docuementoSelect.idStatusDocumentAct == 0) 
    {
      this.messageError = "Selecciona un status de documento"
    } else if (this.docuementoSelect.idStatusDocumentAct == 9002 && (this.docuementoSelect.comenatarios == "" || this.docuementoSelect.comenatarios == undefined)) 
    {
      this.messageError = "Ingresa comentarios"
    } else if (this.valorActual+1 < this.docuementoSelect.imagenes.length) 
    {
      this.messageError = "Revisa todo el expediente"
    } else if (this.docuementoSelect.paginasObsv == "" && this.docuementoSelect.idStatusDocumentAct == 9002) 
    {
      this.messageError = "Deves de ingresar al menos una pagina  "
    } else 
    {
      if (this.porcionActual < this.listaExpe.length) 
      {
        this.loading = true;
        var objetoj = [{
          idDocumento: this.docuementoSelect.idTipoDoc,
          documentoDescrip: this.docuementoSelect.nombreDoc,
          idPersonDoc: "",
          obligatorio: 1,
          idStatusDocument: this.docuementoSelect.idStatusDocumentAct,
          observacion: ((this.docuementoSelect.comenatarios + "/" + this.docuementoSelect.paginasObsv) == "undefined/") ? "" : this.docuementoSelect.comenatarios + "/" + this.docuementoSelect.paginasObsv,
          comentSucursal: ""
        }]
        var peticion = 
        {
          noSolicitudTienda: this.solicitudSelect.solicitud.idSolicitud,
          idNoPedMesa: this.solicitudSelect.datosMesa.idNoPedidoMesa,
          ban: 0,//en duro
          statusGeneral: (this.solicitudSelect.datosMesa.estado == "POR ATENDER") ? 9002 : 9002,
          observacionGeneral: this.solicitudSelect.datosMesa.observacion,
          objetoj: JSON.stringify(objetoj),
          ip: "00.00.00.00",
          tiendaOrigen: this.solicitudSelect.surcusal.idSucursalOrigen,
          noEmpleado: this.usrActivo.id,
          noReenvios: this.solicitudSelect.datosMesa.reenvios,
          cu: this.solicitudSelect.cliente.idPaisCU + "-" + this.solicitudSelect.cliente.idCanalCU + "-" + this.solicitudSelect.cliente.idSucursalCU + "-" + this.solicitudSelect.cliente.idFolioCU,
          nombreAnalista: this.solicitudSelect.analista.nombreAnalista + " " + this.solicitudSelect.analista.aPaternoAnalista + " " + this.solicitudSelect.analista.aMaternoAnalista
        };
        console.log("saveStatusDocument() ==> peticion ==> ", peticion)
        this.iniciosmdvservice.saveExpedi(JSON.stringify(peticion)).subscribe(data => 
          {
          if (data.codigo == 402) 
          {
            this.docuementoSelect.calificado=2
            this.loading = false;
            if (this.docuementoSelect.idStatusDocumentAct == 9001)
              this.docuementoSelect.color = "blue"
            if (this.docuementoSelect.idStatusDocumentAct == 9002)
              this.docuementoSelect.color = "orange"
            this.messageError = "";
            //if( this.porcionActual >0)
            //this.porcionActual--;
            //this.porcionActual++;
            console.log("  this.porcionActual Antes  ==> ",  this.porcionActual )
            this.porcionActual = this.docuementoSelect.posicionId+1;
            console.log("  this.porcionActual  ==> ",  this.porcionActual )
            if (this.porcionActual < this.listaExpe.length) 
            {
              console.log("  evaluarAct  ==> ", this.listaExpe )
              this.evaluarAct(this.listaExpe[this.porcionActual]);
            } else 
            {
              this.porcionActual--;
            }
          } else 
          {
            try{
              this.messageError = data.descripcion;
              this.loading = false;
            }catch(e){
              this.messageError = "Ocurrio un error"
              this.loading = false;
            }
           
          }
        });
      }

    }
  }

  saveSatatusSol(): void {
    this.loading = true;
    this.validacionSolicitud = false;
    console.log("safeSatatusSol ==> ", this.comentarioSolicitud + " ==> ", this.statusSolicitud);
    if (this.statusSolicitud > 0) 
    {
      var peticion = 
      {
        noSolicitudTienda: this.solicitudSelect.solicitud.idSolicitud,
        idNoPedMesa: this.solicitudSelect.datosMesa.idNoPedidoMesa,
        ban: 1,//en duro
        statusGeneral: this.statusSolicitud,
        observacionGeneral: (this.comentarioSolicitud == undefined) ? "" : this.comentarioSolicitud,
        objetoj: "",
        ip: "00.00.00.00",
        tiendaOrigen: this.solicitudSelect.surcusal.idSucursalOrigen,
        noEmpleado: this.usrActivo.id,
        noReenvios: this.solicitudSelect.datosMesa.reenvios,
        cu: this.solicitudSelect.cliente.idPaisCU + "-" + this.solicitudSelect.cliente.idCanalCU + "-" + this.solicitudSelect.cliente.idSucursalCU + "-" + this.solicitudSelect.cliente.idFolioCU,
        nombreAnalista: this.solicitudSelect.analista.nombreAnalista + " " + this.solicitudSelect.analista.aPaternoAnalista + " " + this.solicitudSelect.analista.aMaternoAnalista
      };
      console.log("safeSatatusSol ==> peticion ==> ", peticion);
      this.iniciosmdvservice.saveExpedi(JSON.stringify(peticion)).subscribe(data => 
      {
        if (data.codigo == 402) 
        {
          this.loadData(1);
          this.loading = false;
          $("#closeModal").click();
          Swal.fire('Status final folio', `Se ha  ` + ((this.statusSolicitud == 7004) ? "Autorizado" : (this.statusSolicitud == 7005) ? "Observado" : "Rechazado") + ` la solicitud ` + this.solicitudSelect.solicitud.idSolicitud, 'success');
        } else 
        {
          this.loading = false;
        }

      });
    }

  }

  folioEvalua(folA: SolicitudMdc): void 
  {
    
    this.navV = { evaliacion: true, cliente: false, solicitud: false, mesa: false };
    folA.datosMesa.tiempoAsigna = this.tiempoEntreHoras(folA.datosMesa.fechaCreacion, folA.datosMesa.fechaAsignada);
    if (folA.datosMesa.estado == "EN EVALUACION" || folA.datosMesa.estado == "ASIGNADA")
      folA.datosMesa.tiempoAtencion = this.tiempoEntreHoras(folA.datosMesa.fechaAsignada, new Date());
    else
      folA.datosMesa.tiempoAtencion = this.tiempoEntreHoras(folA.datosMesa.fechaAsignada, folA.datosMesa.fechaAtencion);

    this.solicitudSelect = undefined;
    this.referenciaSele = undefined;
    this.isExpediente = true;
    this.validacionSolicitud = false;
    this.comentarioSolicitud = "";
    this.statusSolicitud = 0;
    this.listaReferencias = [];
    this.valorActual = 0;
    this.solicitudSelect = folA;
    this.sEvaluaFolio = (this.solicitudSelect.datosMesa.estado === "ASIGNADA" || this.solicitudSelect.datosMesa.estado === "EN EVALUACION")
    var peticion1 = { cuenta: this.solicitudSelect.cliente.noCuenta }
    console.log("peticion1 ==>", peticion1)
    var indexfiltro = null;
    this.loading = true;
    this.listaExpe = [];
    
    this.messageError ="";
    this.messageErrorRef="";
    this.iniciosmdvservice.getExpedienteElectronico(JSON.stringify(peticion1)).subscribe(data => 
    {
      if (data.codigo == 2) 
      {
        console.log("responsgetExpedienteElectronico  ==> ", data)
        this.noExisteDocument = ""
        var dtoSpli = [];
        var antes = "";
        var cadena = "";
        var conta = 0;
        var contaNew = 1;
        var listaExpe1 = [];
        var expd: ListaExpediente;
        var imageness: ImagenM;
        data.dato.sort()
        indexfiltro = data.dato.map(function (expe) 
        {
          dtoSpli = expe.split("-")
          imageness = new ImagenM();
          if (antes == "") 
          {
            expd = new ListaExpediente();
            expd.idTipoDoc = dtoSpli[0];
            expd.nombreDoc = dtoSpli[1];
            expd.color = "black"
            expd.idStatusDocumentAct = 0;
            expd.idStatusDocumentAnt = 0;
            expd.posicionId = conta;
            expd.desabilita = true
            expd.paginasObsv = ""
            expd.comentSucursal = "";
            antes = dtoSpli[1];
            cadena += dtoSpli[1] + " | ";
            conta++;
            expd.imagenes = [];
            listaExpe1.push(expd)
          } else if (antes != dtoSpli[1]) 
          {
            expd = new ListaExpediente();
            contaNew = 1;
            antes = dtoSpli[1];
            cadena += dtoSpli[1] + " | ";
            expd.idTipoDoc = dtoSpli[0];
            expd.nombreDoc = dtoSpli[1];
            expd.color = "black"
            expd.idStatusDocumentAct = 0;
            expd.idStatusDocumentAnt = 0;
            expd.desabilita = false;
            expd.paginasObsv = "";
            expd.comentSucursal = "";
            expd.posicionId = conta;
            expd.imagenes = [];
            listaExpe1.push(expd)
            conta++;
          }
          imageness.urlD = dtoSpli[2];
          imageness.posicion = contaNew++;
          expd.imagenes.push(imageness)
        })
        var conttt  =  0;
        listaExpe1.sort(function(a, b) {
         
          return Number(a.idTipoDoc)- Number(b.idTipoDoc);
        })
        var conttt  =  0;
        listaExpe1.forEach(element => {
          element.posicionId = conttt;
          conttt++;
          this.listaExpe.push(element)
        });
        //this.listaExpe = listaExpe1;
        this.docuementoSelect = this.listaExpe[0]
        var peticion = 
        {
          idNoPedMesa: this.solicitudSelect.datosMesa.idNoPedidoMesa,
          ban: 1
        }
        this.iniciosmdvservice.getExpeRefBetaFinal(JSON.stringify(peticion)).subscribe(data => 
          {
          if (data.codigo == 2) 
          {
            if (data.dato.expedientes.length > 0) 
            {
              for (var i = 0; i < this.listaExpe.length; i++) 
              {
                for (var j = 0; j < data.dato.expedientes.length; j++) 
                {
                  if (this.listaExpe[i].idTipoDoc == data.dato.expedientes[j].idDocumento) 
                  {
                    this.listaExpe[i].comentSucursal = data.dato.expedientes[j].comentSucursal;
                    this.listaExpe[i].idStatusDocumentAct = data.dato.expedientes[j].idStatusDocument;
                    this.listaExpe[i].idStatusDocumentAnt = data.dato.expedientes[j].idStatusDocument;
                    this.listaExpe[i].calificado=1
                    var splVa = data.dato.expedientes[j].observacion.split("/");
                    this.listaExpe[i].comenatarios = splVa[0];;
                    if (splVa.length > 0) 
                    {
                      this.listaExpe[i].paginasObsv = splVa[1]
                    }

                    if (this.listaExpe[i].idStatusDocumentAct == 9001)
                      this.listaExpe[i].color = "blue"
                    if (this.listaExpe[i].idStatusDocumentAct == 9002)
                      this.listaExpe[i].color = "orange"
                  }
                }
              }
            } if (data.dato.referencias.length > 0) 
            {
              for (var a = 0; a < data.dato.referencias.length; a++) 
              {
                data.dato.referencias[a].posicion = a + 1;
                if (data.dato.referencias[a].status == 9001)
                  data.dato.referencias[a].color = "blue"
                if (data.dato.referencias[a].status == 9002)
                  data.dato.referencias[a].color = "orange"

                this.listaReferencias.push(data.dato.referencias[a])
              }
            }
            this.loading = false;
          } else 
          {
            this.loading = false;
          }

        });
      } else 
      {
        this.loading = false;
        this.noExisteDocument = "No existen Documentos"
        var dtoSpli = [];
        var antes = "";
        var cadena = "";
        var conta = 0;
        var contaNew = 1;
        var listaExpe1 = [];
        var expd: ListaExpediente;
        var imageness: ImagenM;
      }
    });
  }

  evaluarSolciitud(): void 
  {
    this.messageError = "";
    if (this.validacionSolicitud == false) 
    {
      var existExp = false;
      var existRef = false;
      for (var a = 0; a < this.listaExpe.length; a++) 
      {
        if (this.listaExpe[a].idStatusDocumentAct == 0) 
        {
          this.listaExpe[a].color = "red";
          existExp = true;
        }
      }
      for (var a = 0; a < this.listaReferencias.length; a++) 
      {
        if (this.listaReferencias[a].status == 0) 
        {
          this.listaReferencias[a].color = "red";
          existRef = true;
        }
      }
      if(this.solicitudSelect.datosMesa)
      {
          for (var a = 0; a < this.listaExpe.length; a++) 
        {
          if (this.listaExpe[a].idStatusDocumentAnt == 9002 && this.listaExpe[a].calificado == 1) 
          {
            //if (this.listaExpe[a].idStatusDocumentAct == this.listaExpe[a].idStatusDocumentAnt) {
              this.listaExpe[a].color = "red";
              existExp = true;
            //}
            
          }
        }
      }
      if (existExp) 
      {
        this.validacionSolicitud = false;
        this.messageError = "Revisa todo el expediente"
      } else if (existRef) 
      {
        this.validacionSolicitud = false;
        this.messageError = "Revisa todos las referencias"
      } else 
      {
        this.validacionSolicitud = true;
        this.statusSolicitud = (this.asignaStatusManual()) ? 7004 : 7005;
      }

    } else 
    {
      if (this.statusSolicitud == 0) 
      {
        this.messageErrorRef = "Selecciona status de la solicitud"
      } else if (this.comentarioSolicitud == "") 
      {
        this.messageErrorRef = "Ingresa Comentarios de la solicitud"
      } else {
        this.saveSatatusSol();
      }
    }
  }
  misSolicitudesAsigna(){
  /*  this.iniciosmdvservice.getSolicitudesComple(this.peticion).subscribe(
      data => 
      {
        this.asignaContadores(data, 3);
      });*/
      
      if((this.solPendienteSs.datoExtra.autorizadas >0 || this.solPendienteSs.datoExtra.observadas>0 || this.solPendienteSs.datoExtra.rechazadas>0 ) && this.isActivaSoli == false){
        this.isActivaSoli = true;
        if (this.ffechaFin == null ) 
        {
          this.peticion.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
        } else 
        {
          this.peticion.fFinal = this.ffechaFin.day+"/"+this.ffechaFin.month+"/"+this.ffechaFin.year;
        }
    
        if (this.ffechaInicio == null) 
        {
          this.peticion.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
        } else 
        {
          this.peticion.fInicio = this.ffechaInicio.day+"/"+this.ffechaInicio.month+"/"+this.ffechaInicio.year;
        }
    
        this.peticion.noEmpleado = this.usrActivo.id;

        this.iniciosmdvservice.getSolicitudesComple(this.peticion).subscribe(
          data => 
          {
            data.dato.forEach(element => {
              this.solPendienteSs.dato.push(element)
            });
            this.asignaContadores(this.solPendienteSs,4);
          });
      }else{
        this.asignaContadores(this.solPendienteSs,4);
      }

  }
  //End Metodos operacionales
  //Metodos Auxiliares
    restarC(): void 
    {
      this.catAgirar=0;
      if (this.valorActual > 0) 
      {
        this.valorActual--;
      }
    }

    sumarC(): void 
    {
      this.catAgirar=0;
      if (this.valorActual < this.docuementoSelect.imagenes.length-1) 
      {
        this.valorActual++;
      }
    }

    converir(fecha) : string
    {
      this.nvalo= fecha.split("/");
      return this.nvalo[2]+"-"+this.nvalo[1]+"-"+this.nvalo[0];
    }

    converirW(fecha) : string
    {
      this.nvalo= fecha.split("/");
      return this.nvalo[1]+"/"+this.nvalo[0]+"/"+this.nvalo[2];
    }

    navegatior():string
    {
      var navegador = navigator.userAgent;
      var msie = navegador.indexOf("MSIE "); 
      if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) 
      {
        return "INTERNET EXPLORER";
      } else if (navigator.userAgent.indexOf('Firefox') !=-1) 
      {
        return "MOZILA FIREFOX";
      } else if (navigator.userAgent.indexOf('Chrome') !=-1) 
      {
        return "GOOGLE CHROME";
      } else if (navigator.userAgent.indexOf('Opera') !=-1) 
      {
        return "OPERA";
      } else 
      {
        return "OTRO";
      }
  }

    tiempoEntreHoras(date1, date2): string 
    {
      var formatted;
      try 
      {
        var navegat = this.navegatior();
        var start_actual_time;
        var end_actual_time;
        var tiempoT;
        if (navegat == "INTERNET EXPLORER") 
        {
          var fechaSplit = date1.split(" ");
          var fechDate1 = fechaSplit[0].split("-");
          var horaDate1 = fechaSplit[1].split(":");
          var fechaSplit2 = date2.split(" ");
          var fechDate2 = fechaSplit2[0].split("-");
          var horaDate2 = fechaSplit2[1].split(":");
          start_actual_time = new Date(fechDate1[0], fechDate1[1] - 1, fechDate1[2], horaDate1[0], horaDate1[1], horaDate1[2]);
          end_actual_time = new Date(fechDate2[0], fechDate2[1] - 1, fechDate2[2], horaDate2[0], horaDate2[1], horaDate2[2]);
          tiempoT = end_actual_time - start_actual_time;
        } else 
        {
          start_actual_time = new Date(date1);
          end_actual_time = new Date(date2);
          tiempoT = end_actual_time - start_actual_time;
        }
        var diff = tiempoT;
        var diffSeconds = diff / 1000;
        var HH = Math.floor(diffSeconds / 3600);
        var SS = (diffSeconds % 3600) % 60;
        diffSeconds = diffSeconds - SS;
        var MM = (diffSeconds % 3600) / 60;
        var DD = 0;
        SS = Math.round(SS)
        if (HH > 24) 
        {
          DD = (HH / 24);
          DD = ~~DD;
          HH = HH % 24;
        }
        formatted = DD + "-" + HH + "-" + MM + "-" + SS;
      } catch (e) {
      }

      return formatted;
    }

    obetnerPosicion(expediente): void 
    {
      if (this.comentarioAsesor == false) 
      {
        this.comentarioAsesor = true;
      } else
      {
        this.comentarioAsesor = false;
      }
      this.txtComAsesor = expediente.comentSucursal;
      var p = $('#id' + expediente.idTipoDoc);
      var position = p.position();
      var top = position.top - 20;
      var left = position.left + 20;
      var p1 = $("#webuiPopover31");
      p1.css(
        "top", top
      );
      p1.css(
        "left", left
      );

    }

    asignaContadores(data:any,ban:number):void
      {
        console.log("asignaContadores")
        this.contadores = [];
        var primer = this.peticion.fInicio.split("/");
        if(primer.length>1)
        {
          this.peticion.fFinal =  this.converir(this.peticion.fFinal);
          this.peticion.fInicio =  this.converir(this.peticion.fInicio);
        }
    
        if(ban < 3)
        {
            this.solicudesxAtenter =[];
            this.solicudesAsignados = []
            this.solicudesEnEvaluacion =[]
            this.solicitudes =[];
        }
        if(ban == 4){
          this.solicudesxAtenter =[];
          this.solicudesAsignados = []
          this.solicudesEnEvaluacion =[]
          this.solicitudes =[];
          this.solicudesAtendidas = []
        this.solicudesRechazadas = [];
        this.solicudesObervadas = []
          let folAltaa = data.dato as FolioAlta[];
          var foliosXuser :FolioAlta[] = [];
          folAltaa.forEach(element => {
            if(element.analista.idAnalista == this.usrActivo.id){
              foliosXuser.push(element)
            }
          });
          data.dato=foliosXuser;
        }
        this.solicudesAtendidas = []
        this.solicudesRechazadas = [];
        this.solicudesObervadas = []
        this.loading = false
        let folAlta1 : any= data.dato;
        let folAlta : any=[];
        var fff= new Date();
        var dd1 = (fff.getDate() < 10 ? '0' : '') + fff.getDate();
				var mm1 = ((fff.getMonth() + 1) < 10 ? '0' : '') + (fff.getMonth() + 1); 
				var aa1 = fff.getFullYear();
        folAlta1.forEach(element => {
          var fffinal = aa1+"-"+mm1+"-"+dd1+" "+ new Date().getHours()+":"+new Date().getMinutes()+":"+ new Date().getSeconds();
        if(element.datosMesa.estado ==  "POR ATENDER"){
         
          var tiempoEntr = this.tiempoEntreHoras(element.datosMesa.fechaCreacion,fffinal);
          element.datosMesa.circulo=this.showTrafficLight(tiempoEntr);
        }else   if(element.datosMesa.estado ==  "EN EVALUACION" || element.datosMesa.estado ==  "ASIGNADA"){
          var tiempoEntr = this.tiempoEntreHoras(element.datosMesa.fechaAsignada,fffinal);
          element.datosMesa.circulo=this.showTrafficLight(tiempoEntr);
        }else   {
          var tiempoEntr = this.tiempoEntreHoras(element.datosMesa.fechaAsignada,element.datosMesa.fechaAtencion);
          element.datosMesa.circulo=this.showTrafficLight(tiempoEntr);
        }
          

          folAlta.push(element);

        });
        if(ban ==4 && folAlta.length==0){
          this.contadores.push("Por atender : "+0)
          this.contadores.push("Asignadas : "+0)
          this.contadores.push("En evaluacion : "+0)
          this.contadores.push("Atendidas : "+0)
          this.contadores.push("Rechazadas : "+ 0)
          this.contadores.push("Observadas : "+0)
          this.contadores.push("Todas : "+0);
          this.statusValidacion =
          [
              {desc:"Por atender",decContador:this.contadores[0],isActivo:false},
              {desc:"Asignadas",decContador:this.contadores[1],isActivo:false},
              {desc:"En evaluacion",decContador:this.contadores[2],isActivo:false},
              {desc:"Atendidas",decContador:this.contadores[3],isActivo:false},
              {desc:"Rechazadas",decContador:this.contadores[4],isActivo:false},
              {desc:"Observadas",decContador:this.contadores[5],isActivo:false},
              {desc:"Todas",decContador:this.contadores[6],isActivo:false}
          ]
          this.statusValidacion[0].isActivo = true;
        }else{
          this.dtoEx =data.datoExtra;
          folAlta.forEach(folio => 
          {
            let folios: any = folio;
            switch (folios.datosMesa.estado) 
            {
              case "POR ATENDER":
                this.solicudesxAtenter.push(folios)
                break;
              case "ASIGNADA":
                this.solicudesAsignados.push(folios)
                break;
              case "EN EVALUACION":
                this.solicudesEnEvaluacion.push(folios)
                break;
              case "AUTORIZADA MC":
                this.solicudesAtendidas.push(folios)
                break;
              case "RECHAZADA MC":
                this.solicudesRechazadas.push(folios)
                break;
              case "OBSERVADO MC":
                this.solicudesObervadas.push(folios)
                break;
            }
            this.solicitudes.push(folios)
          });
          this.contadores.push("Por atender : "+this.solicudesxAtenter.length)
          this.contadores.push("Asignadas : "+this.solicudesAsignados.length)
          this.contadores.push("En evaluacion : "+this.solicudesEnEvaluacion.length)
          this.contadores.push("Atendidas : "+((this.dtoEx == undefined)?this.solicudesAtendidas.length :(ban==4)?this.solicudesAtendidas.length:this.dtoEx.autorizadas))
          this.contadores.push("Rechazadas : "+((this.dtoEx == undefined)?this.solicudesRechazadas.length :(ban==4)?this.solicudesRechazadas.length:this.dtoEx.rechazadas))
          this.contadores.push("Observadas : "+((this.dtoEx == undefined)?this.solicudesObervadas.length :(ban==4)?this.solicudesObervadas.length:this.dtoEx.observadas))
          if(this.usrActivo.idPerfil == 2002 || this.usrActivo.idPerfil == 2001)
          {
            this.contadores.push("Todas : "+(this.solicudesxAtenter.length +this.solicudesAsignados.length+this.solicudesEnEvaluacion.length+
              ((this.dtoEx == undefined)?this.solicudesAtendidas.length :(ban==4)?this.solicudesAtendidas.length:this.dtoEx.autorizadas) +
               ((this.dtoEx == undefined)?this.solicudesRechazadas.length:(ban==4)?this.solicudesRechazadas.length :this.dtoEx.rechazadas)+ 
               ((this.dtoEx == undefined)?this.solicudesObervadas.length :(ban==4)?this.solicudesObervadas.length:this.dtoEx.observadas)))
               this.todasT = (this.solicudesxAtenter.length +this.solicudesAsignados.length+this.solicudesEnEvaluacion.length+
                ((this.dtoEx == undefined)?this.solicudesAtendidas.length :(ban==4)?this.solicudesAtendidas.length:this.dtoEx.autorizadas) +
                 ((this.dtoEx == undefined)?this.solicudesRechazadas.length:(ban==4)?this.solicudesRechazadas.length :this.dtoEx.rechazadas)+ 
                 ((this.dtoEx == undefined)?this.solicudesObervadas.length :(ban==4)?this.solicudesObervadas.length:this.dtoEx.observadas));
          }else if(this.usrActivo.idPerfil == 2003)
          {
            this.contadores.push("Todas : "+(this.solicudesAsignados.length+this.solicudesEnEvaluacion.length));
          }
          this.statusValidacion =
          [
              {desc:"Por atender",decContador:this.contadores[0],isActivo:false},
              {desc:"Asignadas",decContador:this.contadores[1],isActivo:false},
              {desc:"En evaluacion",decContador:this.contadores[2],isActivo:false},
              {desc:"Atendidas",decContador:this.contadores[3],isActivo:false},
              {desc:"Rechazadas",decContador:this.contadores[4],isActivo:false},
              {desc:"Observadas",decContador:this.contadores[5],isActivo:false},
              {desc:"Todas",decContador:this.contadores[6],isActivo:false}
          ]
          if(ban ==1)
          {
            if(this.usrActivo.idPerfil == 2002 || this.usrActivo.idPerfil == 2001)
            {
              this.statusValidacion[0].isActivo = true;
              this.opcionSeleccionado= "Por atender : "+this.solicudesxAtenter.length;
              this.collection.data = this.solicudesxAtenter;
              this.muestraOpera = false;
            }else if(this.usrActivo.idPerfil == 2003)
            {
              this.statusValidacion[1].isActivo = true;
              this.opcionSeleccionado= "Asignadas : "+this.solicudesAsignados.length;
              this.collection.data = this.solicudesEnEvaluacion;
              this.muestraOpera = false;
              this.capturar();
            }
          }
          else
          {
            this.statusValidacion[6].isActivo = true;
            this.opcionSeleccionado= "Todas : "+this.solicitudes.length
            this.collection.data = this.solicitudes;
          }
        }
       
        this.config = 
        {
          itemsPerPage: 5,
          currentPage: 1,
          totalItems: this.collection.data.length
        };
      }

    delateImage(): void 
    {
      if (this.pageSel == 999) 
      {
        this.docuementoSelect.paginasObsv = "";
      } else if (this.pageSel > 0 && this.pageSel < 999) 
      {
        var resulSpl = this.docuementoSelect.paginasObsv.split(",")
        this.daletePo(resulSpl);
      }
    }

    daletePo(arreDatos):void
      {
        this.docuementoSelect.paginasObsv ="";
        var valo;
          for(var a = 0 ; a<arreDatos.length;a++)
          {
            if(arreDatos[a] != this.pageSel)
            {
              valo =   this.docuementoSelect.paginasObsv.split(",");
              if(a == 0 || valo[0] =="")
              {
                this.docuementoSelect.paginasObsv  = arreDatos[a]
              }else
              {
                this.docuementoSelect.paginasObsv  +="," +arreDatos[a]
              }
            }
            
          }
      }

    addImage():void
    {
        if(this.pageSel ==999 )
        {
          this.docuementoSelect.paginasObsv ="";
            for(var a = 0; a< this.docuementoSelect.imagenes.length;a++)
            {
              if(a == 0)
                 this.docuementoSelect.paginasObsv  =this.docuementoSelect.imagenes[a].posicion.toString();
              else
                this.docuementoSelect.paginasObsv  += ","+this.docuementoSelect.imagenes[a].posicion.toString();
            }
        }else if(this.pageSel >0 )
        {
          var resulSpl = this.docuementoSelect.paginasObsv.split(",")
          if(resulSpl.length>0 && resulSpl[0] != "")
          {
            if(!this.validaExiste(resulSpl))
               this.docuementoSelect.paginasObsv += ","+this.pageSel.toString();
          }else
          {
            this.docuementoSelect.paginasObsv =this.pageSel.toString();
          }
        }else{
          
        }
        
      }

    validaExiste(arreDatos):boolean
    {
        var  existe:boolean= false;
          for(var a = 0 ; a<arreDatos.length;a++)
          {
            if(arreDatos[a] == this.pageSel)
            {
              existe = true;
              break;
            }
          }
        return existe;
      }

    showTabs(valueTab): boolean 
    {
      var isReturn: boolean = false;
        try 
        {
          if(valueTab != undefined){

            this.splitValues = valueTab.split(":")
            this.valSelec = this.splitValues[0];
            switch (this.valSelec.trim()) 
            {
              case "Por atender":
                if (this.usrActivo.idPerfil == 2002 || this.usrActivo.idPerfil == 2001) 
                {
                  isReturn = false;
                } else 
                {
                  isReturn = true;
                }
                break;
              case "Asignadas":
                isReturn = false;
                break;
              case "En evaluacion":
                isReturn = false;
                break;
              case "Atendidas":
                if (this.usrActivo.idPerfil == 2002 || this.usrActivo.idPerfil == 2001) 
                {
                  isReturn = false;
                } else 
                {
                  isReturn = true;
                }
                break;
              case "Rechazadas":
                if (this.usrActivo.idPerfil == 2002 || this.usrActivo.idPerfil == 2001) 
                {
                  isReturn = false;
                } else 
                {
                  isReturn = true;
                }
      
                break;
              case "Observadas":
                if (this.usrActivo.idPerfil == 2002 || this.usrActivo.idPerfil == 2001) 
                {
                  isReturn = false;
                } else 
                {
                  isReturn = true;
                }
                break;
              case "Todas":
                isReturn = false;
                break;
            }
          }
          
          
        } catch (e) 
        {
     
        }
        return isReturn;
      }

    activarSelec(ev: string): void {
        switch (ev) 
        {
          case "evaluacion":
            this.navV = { evaliacion: true, cliente: false, solicitud: false, mesa: false };
            break;
          case "cliente":
            this.navV = { evaliacion: false, cliente: true, solicitud: false, mesa: false };
            break;
          case "solicitud":
            this.navV = { evaliacion: false, cliente: false, solicitud: true, mesa: false };
            break;
          case "mesa":
            this.navV = { evaliacion: false, cliente: false, solicitud: false, mesa: true };
            break;
    
        }
      }

    changeSelect(valu: any): void 
    {
      console.log("changeSelect() ==> valu ==> " + valu)
      this.limpiar();
      for (var a = 0; a < this.statusValidacion.length; a++) 
      {
        if (this.statusValidacion[a].decContador == valu) 
        {
          this.statusValidacion[a].isActivo = true;
          break
        }
      }
      this.opcionSeleccionado = valu;
      this.capturar();
    }
    
    limpiar(): void 
    {
      this.statusValidacion[0].isActivo = false;
      this.statusValidacion[1].isActivo = false;
      this.statusValidacion[2].isActivo = false;
      this.statusValidacion[3].isActivo = false;
      this.statusValidacion[4].isActivo = false;
      this.statusValidacion[5].isActivo = false;
      this.statusValidacion[6].isActivo = false;
    }

    changeAsigna(): void 
    {
      this.prioridad = 0;
      this.totalPendientes = 0;
      this.empleados.forEach(emple => 
      {
        if (emple.idEmpleado == this.operadorSelect)
          this.totalPendientes = emple.noSolPendientes;
      })
    }

    evaluarAct(docuemento): void 
    {
      console.log("evaluarAct ==> ",docuemento)
      this.referenciaSele = undefined;
      this.messageError = "";
      this.messageErrorRef = "";
      this.validacionSolicitud = false;
      this.isExpediente = true;
      this.docuementoSelect = docuemento;
      this.porcionActual = this.docuementoSelect.posicionId;
      this.valorActual = 0;
      this.pageSel = 0;
      this.messageError = ""
      this.docuementoSelect.paginasObsv = (this.docuementoSelect.paginasObsv == undefined || this.docuementoSelect.paginasObsv == "undefined") ? "" : this.docuementoSelect.paginasObsv;
    }

    evaluarRef(referenciaSel: Referencia) 
    {
      this.messageError = "";
      this.messageErrorRef = "";
      this.validacionSolicitud = false;
      this.referenciaSele = referenciaSel;
      this.isExpediente = false;
      this.docuementoSelect = undefined
    }

    capturar(): void 
    {
      this.muestraOpera = true;
      this.splitValues = this.opcionSeleccionado.split(":")
      this.valSelec = this.splitValues[0];
      switch (this.valSelec.trim()) 
      {
        case "Por atender":
          this.muestraOpera = false;
          this.collection.data = this.solicudesxAtenter;
          break;
        case "Asignadas":
          this.collection.data = this.solicudesAsignados;
          break;
        case "En evaluacion":
          this.collection.data = this.solicudesEnEvaluacion;
          break;
        case "Atendidas":
          if (this.solicudesAtendidas.length == 0 && Number.parseInt(this.splitValues[1].trim()) != 0) {
            this.loadData(2);
          } else {
            this.collection.data = this.solicudesAtendidas;
          }          
          break;
        case "Rechazadas":
          if (this.solicudesRechazadas.length == 0 && Number.parseInt(this.splitValues[1].trim()) != 0) {
            this.loadData(2);
          } else {
            this.collection.data = this.solicudesRechazadas;
          }
          break;
        case "Observadas":
          if (this.solicudesObervadas.length == 0 && Number.parseInt(this.splitValues[1].trim()) != 0) {
            this.loadData(2);
          } else {
            this.collection.data = this.solicudesObervadas;
          }
          break;
        case "Todas":
          if (Number.parseInt(this.splitValues[1].trim()) != this.solicitudes.length) {
            this.loadData(2);
          } else {
            this.collection.data = this.solicitudes;
          }
          break;
      }
      this.config = 
      {
        itemsPerPage: 5,
        currentPage: 1,
        totalItems: this.collection.data.length
      };
    }

    asignaStatusManual(): boolean 
    {
      var isAutorizado = true;
      for (var a = 0; a < this.listaExpe.length; a++) 
      {
        if (this.listaExpe[a].idStatusDocumentAct == 9002) 
        {
          isAutorizado = false;
          break;
        }
      }
      return isAutorizado;
    }

    actualizarPendientes(): void 
    {
     
      this.userService.setUserLoggedIn(this.usrActivo)
      this.solPendienteSs =this.foliosConstante;
      this.isActivaSoli = false;
      this.asignaContadores(this.foliosConstante, 1)
      this.exisSolPendie = false;
    }

    filtrosActivar() : void
    {
      this.activaBor = false;
      this.dtoFiltro="";
      switch(Number.parseInt(this.filtroSelect.toString()))
      {
        case 6:
          this.showSelect = false;
          this.showtetx =  false;
         
          break;
          case 5:
            this.showSelect = false;
            this.showtetx =  true;
            this.filtroPlaceHolder = "Número de analista";
            this.filtroType = "tel";
            this.dtoFiltro ="";
            this.filtroMin=5;
            this.filtoMax= 8;
            this.mascarausar= "00000000"
            break;
          case 1:
            this.showSelect = false;
            this.showtetx =  true;
            this.filtroPlaceHolder = "Cliente Único(02-01-2252-2222-0)";
            this.filtroType = "text";
            this.dtoFiltro ="";
            this.filtroMin=14;
            this.filtoMax= 16;
            this.mascarausar= "00-00-0000-0000-0"
            break;
            case 2:
            this.showSelect = true;
            this.showtetx =  false;
            this.dtoFiltro ="0";
            break;
            case 3:
              this.showSelect = false;
              this.showtetx =  true;
              this.filtroPlaceHolder = "Sucursal";
              this.filtroType = "tel";
              this.dtoFiltro ="";
              this.filtroMin=3;
               this.filtoMax= 5;
               this.mascarausar= "00000"
            break;
            case 4:
              this.showSelect = false;
              this.showtetx =  true;
              this.filtroPlaceHolder = "Número de Salicitud";
              this.filtroType = "tel";
              this.dtoFiltro ="";
              this.filtroMin=3;
            this.filtoMax= 8;
            this.mascarausar= "00000"
            break;
      }
    }
    girarImagen():void{
      this.catAgirar +=45; 
      if( this.catAgirar == 360)
          this.catAgirar=0;
      $("#imganeB64").css("transform","rotate("+this.catAgirar+"deg)")
    }

    showTrafficLight(formatted):string{
      formatted =  formatted.split("-");
			var trafficLight ="";
			if(formatted[0]>0 || formatted[1]>0 || formatted[2]>30)
      trafficLight ="assets/img/rojo.png";
			else if(formatted[2]>20 && formatted[2] <= 30)
				trafficLight ="assets/img/amarillo.png";
			else if(formatted[2] <= 20)
				trafficLight ="assets/img/verde.png";
			return trafficLight;
    }

    obtenerPosicion(pocicion): void {
     console.log("obtenerPosicion ==> ",pocicion)
     
      if (this.mostrarNivel)
        this.mostrarNivel = false
      else
        this.mostrarNivel = true;
  
      var p = $('#id' + pocicion.idTipoDoc);
      this.txtComAsesor = pocicion.comentSucursal;
      var position = p.position();
      this.top = "" + (position.top + 230) + "px"
      this.left = "" + (position.left +90) + "px"
  
    }
  //End Metodos Auxiliares


}
