export class AsignaFolioModel {
  folioAltaUnica:string;
  empleadoAsigna:number;
  admin: number;
}
