export class StatusFinalCu {
  id:string;
  desc:string;
  status: number =0;
}
