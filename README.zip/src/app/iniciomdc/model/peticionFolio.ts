export class PeticionFolio {
  fInicio:string;
  fFinal:string;
  noEmpleado: number = 180794;
}
