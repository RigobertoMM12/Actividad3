export class DatosMesa {
    idNoPedidoMesa: number;
    fechaCreacion: string;
    estado: string;
    observacion: string;
    fechaAtencion: string;
    asignada: number;
    fechaAsignada: string;
    prioridad: number;
    reenvios: number
    tiempoAsigna:string;
    tiempoAtencion:string;
}