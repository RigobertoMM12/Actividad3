export class AnalistaMdcM{
    idAnalista: number;
    nombreAnalista: string;
    aPaternoAnalista: string;
    aMaternoAnalista: string;  
}