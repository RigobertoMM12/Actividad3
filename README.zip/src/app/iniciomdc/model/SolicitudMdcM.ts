export class SolicitudMdcM {
    idSolicitud: number;
    presupuesto: number;
    capacidadPago: number;
    idTipoSolicitud: number;
    tipoSolicitud: string;
    idCondicionSolicitud: number;
    condicionSolicitud: string;
    producto: string;
    condicion: string;
}