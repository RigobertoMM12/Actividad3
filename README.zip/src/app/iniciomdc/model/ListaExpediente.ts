import { ImagenM } from './ImagenM';

export class ListaExpediente {
    idTipoDoc: number;
    nombreDoc: string;
    idStatusDocumentAct: number;
    idStatusDocumentAnt: number;
    posicionId: number;
    desabilita: boolean;
    calificado: number;
    color: string;
    imgC: 1;
    comentSucursal: string;
    comenatarios:string;
    paginasObsv:string;
    imagenes: ImagenM[];
    

}