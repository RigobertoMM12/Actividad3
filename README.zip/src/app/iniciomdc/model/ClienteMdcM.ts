export class ClienteMdcM{
    nombre: string;
    aPaterno: string;
    aMaterno: string;
    dpi: number;
    cu: string;
    noCuenta: number;
    idPaisCU: number;
    idCanalCU: number;
    idSucursalCU: number;
    idFolioCU: string;
    negocio: string;
    tienda: string;
    cliente: string;
    dv: string   
}