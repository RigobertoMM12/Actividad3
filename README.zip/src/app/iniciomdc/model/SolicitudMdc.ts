import { DatosMesa } from './DatosMesa';
import { Surcusal } from './Surcusal';
import { SolicitudMdcM } from './SolicitudMdcM';
import { ClienteMdcM } from './ClienteMdcM';
import { AnalistaMdcM } from './AnalistaMdcM';

export class SolicitudMdc{
    datosMesa : DatosMesa;
    surcusal: Surcusal;
    solicitud: SolicitudMdcM;
    cliente:ClienteMdcM;
    analista:AnalistaMdcM;
}