export class Referencia{
aMaterno: string;
aPaterno: string;
celular: string;
idRef: number;
idTipoRef: number;
nombre: string;
observacion: string;
parentesco: string;
status: number;
telefono: string;
tipoRef: string;
color:string;
posicion:number;
}