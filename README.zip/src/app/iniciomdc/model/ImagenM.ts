export class ImagenM {
    imgB64: string;
    imgHeight: number;
    imgWidth: number;
    tipo: number;
    posicion:number;
    urlD: string
}