export class Empleado {
  numEmpleado:number;
  nombreEmpleado:string;
  apellidosEmpleado:string;
  numSucursal:number;
  nombreSucursal:string;
}
