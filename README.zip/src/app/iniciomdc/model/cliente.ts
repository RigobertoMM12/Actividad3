export class Cliente {
  pNombreCliente:string =null;
  sNombreCliente:string =null;;
  apPaterno:string=null;;
  apMaterno:string =null;;
  apCasado:string=null;;
  fechaNacimiento:string=null;;
  nacionalidad:string =null;;
  parentesco:string=null;;
  fotoCliente:string=null;;
}
