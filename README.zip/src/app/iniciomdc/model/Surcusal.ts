export class Surcusal{
    idSucursalOrigen: string;
    sucursalOrigen: string;
    idSucrusalVendedor: number;
    sucursalVendedora: string;
}