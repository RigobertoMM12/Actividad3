import { Cliente } from './cliente';
import { Solicitud } from './solicitud';
import { Empleado } from './Empleado';
import { AnalistaMdcM } from './AnalistaMdcM';
/*
*/

export class FolioAlta {
  analista:AnalistaMdcM
  cliente:Cliente;
  solicitud:Solicitud;
  empleado:Empleado;
 /* empleado:Empleado;
  solicitud:Solicitud;*/
}
