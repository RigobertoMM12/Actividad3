export class EmpleadoA {
  idEmpleado: number
  nombre: string
  aPaterno: string
  aMaterno: string
  maxSol: number
  noSolPendientes: number
}
