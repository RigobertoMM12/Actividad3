export class DtoExtra {
  porAtender: number
  asignadas: number
  enAtencion: number
  autorizadas: number
  rechazadas: number
  observadas: number
}
