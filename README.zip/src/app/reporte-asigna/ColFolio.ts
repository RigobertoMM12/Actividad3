export class ColFolio {
folio: string;
sucursal : string;
fechaGeneracion: string;
asesorGenera: string;
fechaAsigna: string;
numeroOperadorAsignado: string;
nombreOperadorAsignado: string;
estatus: string;
folioAsignados: string;
folioAtendidos: string;
}