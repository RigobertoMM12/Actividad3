import { Cliente } from './cliente';
import { Solicitud } from './solicitud';
import { Empleado } from './Empleado';
/*
*/

export class FolioAlta {
  cliente:Cliente;
  solicitud:Solicitud;
  empleado:Empleado;
 /* empleado:Empleado;
  solicitud:Solicitud;*/
}
