import { Component, OnInit, ViewChild, ElementRef, OnDestroy, AfterViewInit } from '@angular/core';
import Swal from 'sweetalert2';
import { tap, timeout } from 'rxjs/operators';
import { FolioAlta } from './model/folioAlta';
import { IniciomdvService } from './iniciomdv.service';
import { PeticionFolio } from './model/peticionFolio';
import { PaginationInstance } from 'ngx-pagination';
import { HerperC } from '../helper/helper';
import { DtoExtra } from './model/dtoExtra';
import { formatDate } from '@angular/common';
import { EmpleadoA } from './model/empleadosA';
import { PeticionFolioFi } from './model/peticionFolioFi';
import { AsignaFolioModel } from './model/asignaFolioModel';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { StatusFinalCu } from './model/statusFinalCu';
import * as $ from 'jquery'
import { UserService } from '../header/UserService';
import { UsuarioModel } from '../header/model/usuarioModel';
import Push from 'push.js';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-iniciomdv',
  templateUrl: './iniciomdv.component.html',
  styleUrls: ['./iniciomdv.component.css']
})
export class IniciomdvComponent implements OnInit,OnDestroy {
 @ViewChild('imgRef', { static: false }) img: ElementRef;
  foliosAlta: FolioAlta[]  = [];

  foliosAltaxAtenter : FolioAlta[] = [];
  foliosAltaAsignados : FolioAlta[]= [];
  foliosaltaEnEvaluacion  :FolioAlta[]= [];
  foliosAltaAtendidas :FolioAlta[]= [];
  foliosAltaRechazadas: FolioAlta[]= [];
  foliosAltaCancelados : FolioAlta[]= [];
  foliosConstante = [];
  dtoEx :DtoExtra = new DtoExtra();
  foliSelect : FolioAlta = new FolioAlta();
  contadores : string[] = [];
  splitValues : string[]=[];
  dtoExtrac : string[]=[];
  empleados : EmpleadoA[];
  opcionSeleccionado :string;
  helpe : HerperC;
  loading = false;
  valSelec : string ="";
  fechaActual:Date;
  folioAsigna : string ="";
  operadorSelect : number =0;
  totalPendientes:number=0;
  dtoFiltro : string ="";
  showSelect : boolean = false;
  showtetx : boolean = false;
  filtroSelect : number= 5;
  filtroPlaceHolder :string= "";
  filtroType :string = "text";
  mmMenorEd : boolean = false;
  llaveExpe:string;
  primerPregunta : string;
  segundoPregunta : string;
  comentarios : string;
  muestraOpera :boolean = true;
  urlDigitalizaFrama :string ="";
  navV = { evaliacion: true, cliente:false,solicitud:false };
  asignaFolioModel : AsignaFolioModel = new AsignaFolioModel();
  urlSafe: SafeResourceUrl;
  urlSafeExpUnic : SafeResourceUrl;
  messageError :string ="";
  isMenorEdad: boolean = false;
  isHominimo : boolean = false;
  listaCU : StatusFinalCu[]=[];
  valueCU :string= "Selecciona el status del cu";
  statusSelectCu:number =0;
  showFrame  :boolean= false;
  showRechazo : boolean = false;
  showQuestion : boolean = true;
  sEvaluaFolio : boolean = false;
  sReintentaFolio : boolean = false;
  verModal : boolean = false;
  exisSolPendie : boolean = false;
  nnnn :number= 0;
  statusCu =  [{id:0,value:"Selecciona el status del cu"},{id:1,value:"No coincide"},{id:2,value:"Coincide"}];
  motivosRechazo =  [{ id:0, value:"Selecciona un motivo de rechazo"},{id:8001, value:"Hay una coincidencia para este cliente"},{ id:8002, value:"Existe más de una coincidencia para este cliente"}];
  motivoRechazoSel :number = 0;
  photoSelect :string ="";
  photoSelectSecury :any ="data:image/png;base64, ";
  usrActivo : any;
  isCasada :boolean= false;
  listaExpeAlta :any[]=[];
  listaExpeAltaN :any[]=[];
  tiempoEjecucion : number;
  uriRedirecPush="";
  statusValidacion = [
    {desc:"Por atender",decContador:"",isActivo:true},
    {desc:"Asignadas",decContador:"",isActivo:false},
    {desc:"En evaluacion",decContador:"",isActivo:false},
    {desc:"Atendidas",decContador:"",isActivo:false},
    {desc:"Rechazadas",decContador:"",isActivo:false},
    {desc:"Canceladas",decContador:"",isActivo:false},
    {desc:"Todas",decContador:"",isActivo:false}

  ]
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 6,
    currentPage: 1
  };
  config: any;
  nvalo: string[];
  collection = { count: 60, data: [] };
  peticion :PeticionFolio = new PeticionFolio;
  reqFoliFi : PeticionFolioFi = new PeticionFolioFi();
  id:any;
  solPendientes:number;
  ffechaInicio: { day: number, year: number, month: number };
  ffechaFin: { day: number, year: number, month: number };
  mascarausar: string = "";
  minlength = 0;
  maxlength = 0;
  activaBor: boolean = false;
  imgSelect ="";
  descEx = "";
  valorActual = 0;
  catAgirar  =0;
  expActual = 0;
  ultimoExp  = 0;

  imgSelectN ="";
  descExN = "";
  valorActualN = 0;
  catAgirarN  =0;
  expActualN = 0;
  ultimoExpN  = 0;
  exiteExpN = false;
  
  exiteExp = false;
  navegador =  "";
  habilitarReenvios=0;
  
  constructor(private iniciosmdvservice : IniciomdvService, public sanitizer: DomSanitizer,private userService: UserService,private el: ElementRef ) { }
 
  ngOnDestroy():void{
    console.log("ngOnDestroy========>");
    if (this.id) {
      clearInterval(this.id);
    }
  }
  ngOnInit(): void {
    this.uriRedirecPush =environment.redirectUri;
    this.navegador  = this.navegatior();
    this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl("");
    this.photoSelectSecury = this.sanitizer.bypassSecurityTrustResourceUrl(this.photoSelectSecury);
    this.loading  = true;
  //  setTimeout(() => {
      this.usrActivo = this.userService.getUserLoggedIn();
    
     
      console.log("ngOnIntit()==> setTimeout ==> usrActivo ==>", this.usrActivo)
    
     
      this.loading  = false;
      if (this.usrActivo != null) {
        this.loadData(1);
      }
        try{
          var param22 = this.usrActivo.tabla.filter(function(el) {
            return el.idParametro==22;
          })
          if(param22.length>0){
          this.habilitarReenvios=parseInt( param22[0].valor);
          }else{
             this.habilitarReenvios  =0 ;
          }
          
        }catch(e){this.habilitarReenvios =0;}

      try{
      var Valores = this.usrActivo.tabla.filter(function(el) {
        return el.idParametro==21;
      })
      console.log("ngOnIntit()==> setTimeout ==> Valores ==>", Valores)
      if(Valores.length>0){
      if(Valores[0].valor!=0){
        console.log("ngOnIntit()==> setTimeout ==> Valores.valor ==>", Valores[0].valor)
        if(Valores.length >0){
          this.tiempoEjecucion = parseInt(Valores[0].descValor);
          this.tiempoEjecucion  = ( this.tiempoEjecucion == NaN) ?60000: this.tiempoEjecucion;
        }else{
          this.tiempoEjecucion =60000;
        }
  
       this.id = setInterval(() => {
          this.refrescarTablaEstadoSala(); 
        }, this.tiempoEjecucion);
        
      }
    }
    }catch(e){console.log(e)}
        //}, 30000);//6000

    //}, 200000 / 60);



  }

  refrescarTablaEstadoSala():boolean{
    console.log("refrescarTablaEstadoSala() ==>>",new Date())
   this.loadData(3)
   // $$('#encasUnPwModal').modal('hide');
   return true;
  }
  capturar():void{
    this.muestraOpera  = true;
    this.splitValues =this.opcionSeleccionado.split(":")
    this.valSelec = this.splitValues[0];
    switch(this.valSelec.trim()){
      case "Por atender":
        this.muestraOpera  = false;
        this.collection.data = this.foliosAltaxAtenter;
        break;
        case "Asignadas":
          this.collection.data = this.foliosAltaAsignados;
          break;
          case "En evaluacion":
          this.collection.data = this.foliosaltaEnEvaluacion;
          break;
          case "Atendidas":
          if(this.foliosAltaAtendidas.length ==  0 && Number.parseInt(this.splitValues[1].trim()) != 0){
            this.loadData(2);
          }else{
            this.collection.data = this.foliosAltaAtendidas;
          }

          break;
          case "Rechazadas":
          if(this.foliosAltaRechazadas.length ==  0 && Number.parseInt(this.splitValues[1].trim()) != 0){
            this.loadData(2);
          }else{
            this.collection.data = this.foliosAltaRechazadas;
          }

          break;
          case "Canceladas":
          if(this.foliosAltaCancelados.length ==  0 && Number.parseInt(this.splitValues[1].trim()) != 0){
            this.loadData(2);
          }else{
            this.collection.data = this.foliosAltaCancelados;
          }
          break;
          case "Todas":
          if(Number.parseInt(this.splitValues[1].trim()) != this.foliosAlta.length){
            this.loadData(2);
          }else{
            this.collection.data = this.foliosAlta;
          }

          break;
    }
    this.config = {
      itemsPerPage: 5,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
  }
  loadData(bande: number): void {
    console.log("loadData ==> bande ==>",bande)
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null ) 
    {
      this.peticion.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.peticion.fFinal = ((this.ffechaFin.day.toString().length == 1)?"0"+this.ffechaFin.day:this.ffechaFin.day)+"/"+((this.ffechaFin.month.toString().length == 1)?"0"+this.ffechaFin.month:this.ffechaFin.month)+"/"+this.ffechaFin.year;
      
    }

    if (this.ffechaInicio == null) 
    {
      this.peticion.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else 
    {
      this.peticion.fInicio = ((this.ffechaInicio.day.toString().length == 1)?"0"+this.ffechaInicio.day:this.ffechaInicio.day)+"/"+((this.ffechaInicio.month.toString().length == 1)?"0"+this.ffechaInicio.month:this.ffechaInicio.month)+"/"+this.ffechaInicio.year;

    }


    //this.peticion.fFinal = formatDate(this.peticion.fFinal, 'MM/dd/yyyy', 'es');
    //this.peticion.fInicio = formatDate(this.peticion.fInicio, 'MM/dd/yyyy', 'es');
    //this.peticion.fFinal = this.converirW(this.peticion.fFinal);

   // this.peticion.fInicio = this.converirW(this.peticion.fInicio);
    this.peticion.noEmpleado = this.usrActivo.idEmpleado;
    console.log("loadData ==> peticion ==> ", this.peticion)
    if(bande == 3){
      this.loading = false;
      if(this.exisSolPendie== false){
      var nePeti ={
        noEmpleado:this.peticion.noEmpleado ,
        
        porAtender:parseInt( this.statusValidacion[0].decContador.split("Por atender : ")[1]),
					asignadas: parseInt( this.statusValidacion[1].decContador.split("Asignadas : ")[1]),
					enEvaluacion: parseInt( this.statusValidacion[2].decContador.split("En evaluacion : ")[1]),
					autorizadas: parseInt( this.statusValidacion[3].decContador.split("Atendidas : ")[1]),
					canceladas: parseInt( this.statusValidacion[5].decContador.split("Canceladas : ")[1]),
              rechazadas: parseInt( this.statusValidacion[4].decContador.split("Rechazadas : ")[1]),
              fInicio: this.peticion.fInicio,
        fFinal : this.peticion.fFinal,
      }
      var nePetin ={
        noEmpleado:this.peticion.noEmpleado ,
              fInicio: this.peticion.fInicio,
        fFinal : this.peticion.fFinal,
      }
      console.log("loadData ==> newpeticion ==> ", nePetin);
      this.peticion.fFinal =  this.converir(this.peticion.fFinal);
      this.peticion.fInicio =  this.converir(this.peticion.fInicio);
      this.iniciosmdvservice.getFoliosAltaConstante(JSON.stringify(nePetin)).subscribe(data => {
        
        if(data.codigo == 2){
         
          if(data.datoExtra.porAtender != nePeti.porAtender  || (data.datoExtra.asignadas != nePeti.asignadas ) 
          || (data.datoExtra.enAtencion != nePeti.enEvaluacion )  || (data.datoExtra.autorizadas != nePeti.autorizadas ) 
          || (data.datoExtra.rechazadas != nePeti.rechazadas ) || (data.datoExtra.canceladas != nePeti.canceladas ) ){
              this.exisSolPendie = true;
              this.solPendientes = data.solPendientes;
          }
          /*
          if(data.dato.length >0){
            this.solPendientes = data.solPendientes;
            this.foliosConstante  = data;
            this.exisSolPendie = true;
            Push.create("Mesa De Validacion", {
              body: "Existen cambios los status de en las solicitudes",
              icon: 'assets/img/BAZ.png',
              timeout: 4000,
              
              onClick: function () {
                  window.focus();
                  this.close();
              }
          });
            console.log("loadData ==> getFoliosAltaConstante() ==> ", "Hay folios nuevos ")
           // this.asignaContadores(data, 1)
          }*/

        }else{
          this.exisSolPendie = false;
        }
          
        }, erro => {
          console.log("====>")
          Swal.fire("Servicio no disponible", "", 'error');
          this.statusValidacion = [
            { desc: "Por atender", decContador: "Por atender : 0", isActivo: true },
            { desc: "Asignadas", decContador: "Asignadas : 0", isActivo: false },
            { desc: "En evaluacion", decContador: "En evaluacion : 0", isActivo: false },
            { desc: "Atendidas", decContador: "Atendidas : 0", isActivo: false },
            { desc: "Rechazadas", decContador: "Rechazadas : 0", isActivo: false },
            { desc: "Canceladas", decContador: "Canceladas  : 0", isActivo: false },
            { desc: "Todas", decContador: "Todas : 0", isActivo: false }

          ]
          this.loading = false;
        }
      );
      }else{
        this.peticion.fFinal =  this.converir(this.peticion.fFinal);
      this.peticion.fInicio =  this.converir(this.peticion.fInicio);
      }
      

    }else 
    if (this.filtroSelect == 5) {
      if (bande == 1) {
        this.iniciosmdvservice.getFoliosAlta(this.peticion).pipe(

          tap(data => {
            this.asignaContadores(data, 1)
          }, erro => {
            console.log("====>")
            Swal.fire("Servicio no disponible", "", 'error');
            this.statusValidacion = [
              { desc: "Por atender", decContador: "Por atender : 0", isActivo: true },
              { desc: "Asignadas", decContador: "Asignadas : 0", isActivo: false },
              { desc: "En evaluacion", decContador: "En evaluacion : 0", isActivo: false },
              { desc: "Atendidas", decContador: "Atendidas : 0", isActivo: false },
              { desc: "Rechazadas", decContador: "Rechazadas : 0", isActivo: false },
              { desc: "Canceladas", decContador: "Canceladas  : 0", isActivo: false },
              { desc: "Todas", decContador: "Todas : 0", isActivo: false }

            ]
            this.loading = false;
          })
        ).subscribe(folio => {
        }
        );
      } else {
        this.iniciosmdvservice.getFoliosAltaComple(this.peticion).subscribe(
        data => {
            this.asignaContadores(data, 3);
          });
      }

    } else {
      this.reqFoliFi.ban = Number.parseInt(this.filtroSelect.toString());
      this.reqFoliFi.temp = this.dtoFiltro;
      if(  this.reqFoliFi.temp.length >= this.minlength &&  this.reqFoliFi.temp.length<=this.maxlength){
        this.activaBor= false;
      this.reqFoliFi.fFinal = this.peticion.fFinal
      this.reqFoliFi.fInicio = this.peticion.fInicio;
      console.log(this.reqFoliFi)
      this.iniciosmdvservice.getFoliosAltaFiltro(this.reqFoliFi).subscribe(
        data => {
          this.asignaContadores(data, 2)
        }
      )

    }else{
      this.loading = false;
      this.activaBor= true;
    }
    }

  }
  asignaContadores(data:any,ban:number):void{
    this.contadores = [];
    var primer = this.peticion.fInicio.split("/");
    if(primer.length>1){
      this.peticion.fFinal =  this.converir(this.peticion.fFinal);
      this.peticion.fInicio =  this.converir(this.peticion.fInicio);
    }
 
    if(ban != 3){
        this.foliosAltaxAtenter =[];
        this.foliosAltaAsignados = []
        this.foliosaltaEnEvaluacion =[]
        this.foliosAlta =[];
    }
    this.foliosAltaAtendidas = []
    this.foliosAltaRechazadas = [];
    this.foliosAltaCancelados = []
    this.loading = false
    let folAlta = data.dato as FolioAlta[];
    this.dtoEx =data.datoExtra;
    folAlta.forEach(folio => {
      let folios: any = folio;
      switch (folios.solicitud.statusAltaUnica) {
        case 9001:
          this.foliosAltaxAtenter.push(folios)
          break;
        case 9002:
          this.foliosAltaAsignados.push(folios)
          break;
        case 9003:
          this.foliosaltaEnEvaluacion.push(folios)
          break;
        case 9004:
          this.foliosAltaAtendidas.push(folios)
          break;
        case 9005:
          this.foliosAltaRechazadas.push(folios)
          break;
        case 9006:
          this.foliosAltaCancelados.push(folios)
          break;
      }
      this.foliosAlta.push(folios)
    });
     this.contadores.push("Por atender : "+this.foliosAltaxAtenter.length)
     this.contadores.push("Asignadas : "+this.foliosAltaAsignados.length)
     this.contadores.push("En evaluacion : "+this.foliosaltaEnEvaluacion.length)
     this.contadores.push("Atendidas : "+((this.dtoEx == undefined)?this.foliosAltaAtendidas.length :this.dtoEx.autorizadas))
     this.contadores.push("Rechazadas : "+ ((this.dtoEx == undefined)?this.foliosAltaRechazadas.length :this.dtoEx.rechazadas));
     this.contadores.push("Canceladas : "+((this.dtoEx == undefined)?this.foliosAltaCancelados.length :this.dtoEx.canceladas))
     if(this.usrActivo.idPerfil == 2022){
     this.contadores.push("Todas : "+(this.foliosAltaxAtenter.length +this.foliosAltaAsignados.length+this.foliosaltaEnEvaluacion.length+((this.dtoEx == undefined)?this.foliosAltaAtendidas.length :this.dtoEx.autorizadas) + ((this.dtoEx == undefined)?this.foliosAltaRechazadas.length :this.dtoEx.rechazadas)+ ((this.dtoEx == undefined)?this.foliosAltaCancelados.length :this.dtoEx.canceladas)))
     }else if(this.usrActivo.idPerfil == 2021){
      this.contadores.push("Todas : "+(this.foliosAltaAsignados.length+this.foliosaltaEnEvaluacion.length));
     }
     this.statusValidacion =
     [
        {desc:"Por atender",decContador:this.contadores[0],isActivo:false},
        {desc:"Asignadas",decContador:this.contadores[1],isActivo:false},
        {desc:"En evaluacion",decContador:this.contadores[2],isActivo:false},
        {desc:"Atendidas",decContador:this.contadores[3],isActivo:false},
        {desc:"Rechazadas",decContador:this.contadores[4],isActivo:false},
        {desc:"Canceladas",decContador:this.contadores[5],isActivo:false},
        {desc:"Todas",decContador:this.contadores[6],isActivo:false}
     ]
    if(ban ==1)
    {
      if(this.usrActivo.idPerfil == 2022){
        this.statusValidacion[0].isActivo = true;
        this.opcionSeleccionado= "Por atender : "+this.foliosAltaxAtenter.length;
        this.collection.data = this.foliosAltaxAtenter;
        this.muestraOpera = false;
      }else if(this.usrActivo.idPerfil == 2021){
        this.statusValidacion[1].isActivo = true;
        this.opcionSeleccionado= "Asignadas : "+this.foliosAltaAsignados.length;

        this.collection.data = this.foliosaltaEnEvaluacion;
        this.muestraOpera = false;
        this.capturar();
      }
     
    }
    else
    {
      this.statusValidacion[6].isActivo = true;
      this.opcionSeleccionado= "Todas : "+this.foliosAlta.length
      this.collection.data = this.foliosAlta;
    }


    this.config = 
    {
      itemsPerPage: 5,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
  }
  asignaFolio(folA: FolioAlta): void {
    this.loading = true;
    this.empleados = [];
    this.operadorSelect = 0;
    this.totalPendientes = 0;
    this.folioAsigna = folA.solicitud.folioAltaUnica;
    this.foliSelect = folA;
    this.iniciosmdvservice.getPeradorActivos().pipe(tap(data => {
      this.loading = false;
      let empleado = data.dato;
      empleado.forEach(dato => {
        this.empleados.push(dato)
      })
    })).subscribe(folio => {

      //this.foliosAlta = folio
    });
  }

  folioEvalua(folA: FolioAlta): void {

    this.foliSelect = folA;
    this.photoSelect ="-";
    console.log("folioEvalua() ==> foliSelect ==>",this.foliSelect)
    var verifica="";
    var llaveExpe1 =""
    this.messageError="";
    var cuAplica : string ="";
    this.listaCU = [];
    this.valueCU = "Lista de clientes unicos";
    this.isHominimo = false;
    this.showFrame = false;
    this.showRechazo = false;
    this.mmMenorEd = true;
    this.loading = true;
    this.showQuestion = true;
    this.empleados = [];
    this.operadorSelect =0;
    this.totalPendientes = 0;
    this.imgSelect =  "";
    this.ultimoExp=  0;
    this.descEx  = "";

    this.valorActual = 0;
    this.catAgirar  =0;
    this.expActual = 0;
    this.ultimoExp  = 0;
    this.listaExpeAlta = [];
    this.imgSelectN ="";
    this.descExN = "";
    this.valorActualN = 0;
    this.catAgirarN  =0;
    this.expActualN = 0;
    this.ultimoExpN  = 0;
    this.exiteExpN = false;
    this.listaExpeAltaN = [];
    this.exiteExp = false;
    this.folioAsigna = this.foliSelect.solicitud.folioAltaUnica;
    this.comentarios = this.foliSelect.solicitud.comentarios;
    this.primerPregunta = this.foliSelect.solicitud.respuesta1;
    this.segundoPregunta = this.foliSelect.solicitud.respuesta2;
    this.motivoRechazoSel = this.foliSelect.solicitud.motivoRechazo;
    this.sEvaluaFolio=(parseInt(this.foliSelect.solicitud.statusAltaUnica) <= 9003);
    if(this.habilitarReenvios ==1)
    this.sReintentaFolio=(parseInt(this.foliSelect.solicitud.statusAltaUnica) >9003);
    else
    this.sReintentaFolio=false;

    
    console.log("folioEvalua() ==> apCasado==> ",this.foliSelect.cliente.apCasado)
    this.isCasada = (this.foliSelect.cliente.apCasado == null || this.foliSelect.cliente.apCasado == '')?false:true;
    this.activarSelec('evaluacion');
    this.messageError ="";
    if (this.navegador == "INTERNET EXPLORER")
    this.nuevaImplVisor1(folA.solicitud.folioAltaUnica, folA.empleado.numSucursal);
    //this.sEvaluaFolio  = (this.foliSelect.solicitud.statusAltaUnica === "9001" || this.foliSelect.solicitud.statusAltaUnica === "9002" || this.foliSelect.solicitud.statusAltaUnica === "9003" )?true:false;
    // Generar frame para expediente alta
    this.llaveExpe = folA.solicitud.folioAltaUnica+"-"+folA.empleado.numSucursal+"-"+folA.empleado.numSucursal;
    llaveExpe1 = folA.solicitud.folioAltaUnica+"MM"+folA.empleado.numSucursal+"MM"+folA.empleado.numSucursal;
    verifica = this.verificAltaUnica(llaveExpe1);
    var complementURL = "DigVisorWeb/visor.jsp?llave="+this.llaveExpe+"&id=2&verifica="+verifica;
    this.urlSafe= this.sanitizer.bypassSecurityTrustResourceUrl(this.usrActivo.tabla[0].descValor+complementURL);
    console.log("folioEvalua() ==> urlSafe==> ",this.urlSafe)
    // End Generar frame para expediente alta

    // valida si es menor de edad para contruir frame de Tutor
    if(this.foliSelect.solicitud.flujoAlta == 3003){
      this.isMenorEdad = true;
      cuAplica  = this.foliSelect.solicitud.clientesUnicos;
      if(cuAplica != null){
        var cuAplicaA  = cuAplica.split(",");
        if(this.navegador   == "INTERNET EXPLORER")
        this.nuevaImplVisor2(cuAplicaA[0],cuAplicaA[1],cuAplicaA[2],cuAplicaA[3])
        else
         this.construcFrame(cuAplicaA); //Pendiente 
      }
    

    }else{
      this.isMenorEdad = false;
    }
    //  Termina valida si es menor de edad para contruir frame de Tutor

    // Pasar folio a en evalucion si status es 9002
    if(this.foliSelect.cliente.fotoCliente !="SIN FOTO"){
      var peticion1 = {
        idFoto :this.foliSelect.solicitud.folioAltaUnica
      }
      console.log("folioEvalua() ==> getPhotoPeticion ==>",peticion1) 
  
      this.iniciosmdvservice.getPhoto(JSON.stringify(peticion1)).subscribe(      data => {
        if(data.codigo == 1){
          this.photoSelect = data.dato;
          
          var im: HTMLImageElement = this.el.nativeElement.querySelector('#imgRef'); 
          im.src = "data:image/png;base64, "+this.photoSelect;
          
        }else{
          this.photoSelect ="";
        }
       
      });
    }else{
      this.photoSelect ="";
    }
    
    this.loading = false;
    if(this.foliSelect.solicitud.statusAltaUnica == "9002" && parseInt(this.foliSelect.solicitud.empleadoAsigna) == this.usrActivo.idEmpleado ){
      var peticion = {
        noEmpleado : this.usrActivo.idEmpleado,
        folioAltaUnica :this.foliSelect.solicitud.folioAltaUnica,
        statusFinal : "9003"
      }
      console.log("folioEvalua() ==> cambiarStatusoPeticion ==>",peticion) ;
      this.iniciosmdvservice.cambiarStatus(JSON.stringify(peticion)).subscribe(resp => {
        console.log("folioEvalua() ==> cambiarStatusoPeticion ==>",resp) ;
        
        this.loading = false;
        this.loadData(1);
      } );
     
    }else{
      this.loading = false;
    }
    
    // End Pasar folio a en evalucion si status es 9002

  }
  changeSelect(valu:any):void {
    console.log("changeSelect() ==> valu ==> "+valu)
    this.limpiar();
    for(var a = 0;a<this.statusValidacion.length;a++){
      if(this.statusValidacion[a].decContador == valu ){
        this.statusValidacion[a].isActivo = true;
        break
      }
    }
    this.opcionSeleccionado = valu;
    this.capturar();

  }

  limpiar():void{
    this.statusValidacion[0].isActivo = false;
    this.statusValidacion[1].isActivo = false;
    this.statusValidacion[2].isActivo = false;
    this.statusValidacion[3].isActivo = false;
    this.statusValidacion[4].isActivo = false;
    this.statusValidacion[5].isActivo = false;
    this.statusValidacion[6].isActivo = false;

  }

  construcFrame(cuAplicaA):void{
    var verifica  = this.endParam(cuAplicaA);
    console.log("construcFrame() -> verifica ",verifica);
    var complementURL = "DigVisorExpUnico/?pais="+cuAplicaA[0]+"&canal="+cuAplicaA[1]+"&suc="+cuAplicaA[2]+"&fol="+cuAplicaA[3]+"&verifica="+verifica;
    console.log("construcFrame() -> urlSafeExpUnic", (this.usrActivo.tabla[0].descValor+complementURL))
    this.urlSafeExpUnic= this.sanitizer.bypassSecurityTrustResourceUrl(this.usrActivo.tabla[0].descValor+complementURL);
  }

  changeAsigna():void{
    this.totalPendientes =0;
    this.empleados.forEach(emple =>{
      if(emple.idEmpleado == this.operadorSelect)
      this.totalPendientes = emple.noSolPendientes;
    })
  }

  converir(fecha) : string{
    this.nvalo= fecha.split("/");
    return this.nvalo[2]+"-"+this.nvalo[1]+"-"+this.nvalo[0];
  }
  converirW(fecha) : string{
    this.nvalo= fecha.split("/");
    return this.nvalo[1]+"/"+this.nvalo[0]+"/"+this.nvalo[2];
  }

  filtrosActivar() : void{
    this.showSelect = false;
    this.showtetx =  false;
    this.activaBor = false;
    this.mascarausar= "";
    this.dtoFiltro="";
   
    switch(Number.parseInt(this.filtroSelect.toString())){
      case 5:
        this.showSelect = false;
        this.showtetx =  false;
        this.mascarausar= "";
        break;
        case 1:
          this.dtoFiltro ="";
          //this.mascarausar= "00000000000000000";

          this.showSelect = false;
          this.showtetx =  true;
          this.filtroPlaceHolder = "Folio alta";
          this.filtroType = "text";
          this.minlength=16;
          this.maxlength= 20;
          setTimeout(() => {this.mascarausar= "00000000000000000";}, 100);
          break;
          case 2:
          this.showSelect = true;
          this.showtetx =  false;
          this.dtoFiltro ="0";
          this.minlength=1;
          this.maxlength= 4;
         // this.mascarausar= "";
          break;
          case 3:
            this.dtoFiltro ="";
           // this.mascarausar= "00000";
           
            this.showSelect = false;
            this.showtetx =  true;
            this.filtroPlaceHolder = "Sucursal";
            this.filtroType = "text";
            this.minlength=3;
            this.maxlength= 5;
            setTimeout(() => {this.mascarausar= "00000";}, 100);
          break;
          case 4:
            this.dtoFiltro ="";
            //this.mascarausar= "00000000";
            
            this.showSelect = false;
            this.showtetx =  true;
            this.filtroPlaceHolder = "Numero de operador";
            this.filtroType = "text";
           
            this.minlength= 5;
            this.maxlength= 8;
            setTimeout(() => {this.mascarausar= "00000000";}, 100);
          break;
    }
  }

  asignaFolioManual():void {
    
    this.loading = true;
    if(this.operadorSelect != 0){
      this.asignaFolioModel.empleadoAsigna  = this.operadorSelect;
      this.asignaFolioModel.folioAltaUnica  = this.foliSelect.solicitud.folioAltaUnica
      this.asignaFolioModel.admin = this.usrActivo.idEmpleado;
      console.log("asignaFolioManual() ===> ",this.asignaFolioModel);
      this.iniciosmdvservice.asignaFolioManual(this.asignaFolioModel).pipe(

        tap(data => {
          this.loading = false;
          if(data.codigo == 2 ){
            Swal.fire('Asignación', `Se ha asignado el folio `+this.asignaFolioModel.folioAltaUnica, 'success');
            this.loadData(1);
          }
          if(data.codigo == 24 ){
            Swal.fire('Asignación fallida', `El folio `+this.asignaFolioModel.folioAltaUnica+" ya se encuentra asignado", 'warning');
            this.loadData(1);
          }

        })
      ).subscribe(folio => {
      }
        );
    }else{
      this.loading = false;
    }

  }
  restarC(): void 
  {
    this.catAgirar=0;
    if (this.valorActual > 0) 
    {
   
      this.valorActual--;
      this.imgSelect =  this.listaExpeAlta[ this.expActualN].url[this.valorActualN];    
    }
  }
  restarCN(): void 
  {
    this.catAgirarN=0;
    if (this.valorActualN > 0) 
    {
   
      this.valorActualN--;
      this.imgSelectN =  this.listaExpeAltaN[ this.expActualN].url[this.valorActualN];    
    }
  }
  sumarC(): void 
  {
    this.catAgirar=0;
    if (this.valorActual < this.listaExpeAlta[this.expActual].url.length-1) 
    {
    
      this.valorActual++;
      this.imgSelect =  this.listaExpeAlta[ this.expActual].url[this.valorActual];    
    }
  }
  sumarCN(): void 
  {
    this.catAgirarN=0;
    if (this.valorActualN < this.listaExpeAltaN[this.expActualN].url.length-1) 
    {
    
      this.valorActualN++;
      this.imgSelectN =  this.listaExpeAltaN[ this.expActualN].url[this.valorActualN];    
    }
  }

  girarImagen():void{
    this.catAgirar +=45; 
    if( this.catAgirar == 360)
        this.catAgirar=0;
    $("#imganeB64").css("transform","rotate("+this.catAgirar+"deg)")
  }

  selectDocumen(id){
    console.log("selectDocumen ===>",id);
    this.valorActual = 0;
    this.ultimoExp = this.listaExpeAlta[id].url.length;
    this.expActual= id;
    this.imgSelect =  this.listaExpeAlta[id].url[0];    
    this.descEx = this.listaExpeAlta[id].descipcion;
  }
  selectDocumenN(id){
    console.log("selectDocumen ===>",id);
    this.valorActualN = 0;
    this.ultimoExpN = this.listaExpeAltaN[id].url.length;
    this.expActualN= id;
    this.imgSelectN =  this.listaExpeAltaN[id].url[0];    
    this.descExN = this.listaExpeAltaN[id].descipcion;
  }

  nuevaImplVisor1(folioAlta,sucursal){
     console.log("nuevaImplVisor1() ===>",folioAlta," ====>" , sucursal);

    var peticion ={
      cuenta:folioAlta,
      sucursal:sucursal
    }
    console.log("nuevaImplVisor1() ===> peticion ==> ",peticion);
    var expedienteNueo = [];
    var expedi = {descipcion:"",url:[], id:0};
    var descpExp = "";
    var urls:any[] =[];
    var asignar =false;
    var idd =-1;
    this.exiteExp = false;
    this.iniciosmdvservice.getExpeVisorA(JSON.stringify(peticion)).subscribe(data => 
      {
        if(data.codigo ==1)
          {
            this.exiteExp = true;;
            data.dato.forEach(element => {

            
             

              if(descpExp == ""){
                descpExp = element.descripcion;
                idd++;
                urls.push( element.url );
                console.log("nuevaImplVisor1() ===> Nuevo  ==> ");
              }else if (descpExp == element.descripcion){
                urls.push( element.url );
                console.log("nuevaImplVisor1() ===> Igual  ==> ");
              }else{
                
                expedi.url = urls;
                expedi.descipcion = descpExp;
                expedi.id = idd;
                this.listaExpeAlta.push(expedi);
                console.log("nuevaImplVisor1() ===> Nuevo  ==> ");
                
                expedi = {descipcion:"",url:[],id:0};
                urls =[];
                descpExp =null;
                idd++;
                descpExp = element.descripcion;
                urls.push( element.url );
                
              }

             

            });
            expedi.id = idd;
            expedi.url = urls;
            expedi.descipcion = descpExp;
            this.listaExpeAlta.push(expedi);
            this.imgSelect =  this.listaExpeAlta[0].url[0];
            this.ultimoExp=  this.listaExpeAlta[0].url.length;
            this.descEx  = this.listaExpeAlta[0].descipcion;
            console.log("====> OK",urls);
          }  else{
            this.exiteExp = false;
             console.error("====> ERROR",data);
          }      

       }, erro => {
        console.log("====> False",erro)
       
      });
  }
  verificAltaUnica(llave:string):string{
    var sumaImpar = 0;
		var sumaPar = 0 ;
		var valuSuma =0;
		var resta =0;
		var diaActual = new Date();
		var dd1 = (diaActual.getDate() < 10 ? '0' : '') + diaActual.getDate();
		var mm1 = ((diaActual.getMonth() + 1) < 10 ? '0' : '') + (diaActual.getMonth() + 1);
		var aa1 = diaActual.getFullYear();
    var nDa = aa1+mm1+dd1
    var llaveClean  = llave.replace("MM","");
    llaveClean  = llaveClean.replace("MM","");
    var nval = llaveClean+nDa;
    var imp ="";
		var par ="";
    for(var m =0;m<nval.length; m++)
    {
      if(m%2 == 0)
      {
				imp +=nval[m]+"+";
				sumaImpar += parseInt(nval[m]);
      }
      else
      {
				sumaPar += parseInt(nval[m]);
				par += nval[m]+"+";
			}
		}
		sumaImpar = sumaImpar  * 3;

		valuSuma = sumaPar+ sumaImpar;
		resta = valuSuma%10;
    if(resta != 0)
    {
			resta = (resta-10) * -1;
		}
    return ""+sumaImpar+valuSuma+resta;
  }
  endParam(cuSplit): string {
		var sumaImpar = 0;
		var sumaPar = 0 ;
    var valuSuma =0;
		var resta =0;
		var diaActual = new Date();
		var dd1 = (diaActual.getDate() < 10 ? '0' : '') + diaActual.getDate();
		var mm1 = ((diaActual.getMonth() + 1) < 10 ? '0' : '') + (diaActual.getMonth() + 1);
		var aa1 = diaActual.getFullYear();
    var nDa = aa1+mm1+dd1;
		var cu= cuSplit;
		var nDa1 = cu[0]+cu[1]+cu[2]+cu[3];
		var nval = nDa1+nDa;
		var imp ="";
    var par ="";

    for(var m =0;m<nval.length; m++)
    {
      if(m%2 == 0)
      {
				imp +=nval[m]+"+";
		  	sumaImpar += parseInt(nval[m]);
      }else
      {
				sumaPar += parseInt(nval[m]);
				par += nval[m]+"+";
			}
		}
	  sumaImpar = sumaImpar  * 3;
		valuSuma = sumaPar+ sumaImpar;
		resta = valuSuma%10;
    if(resta != 0)
    {
			resta = (resta-10) * -1;
		}
		return ""+sumaImpar+valuSuma+resta;
	}
  reintentarFolio(): void {
    var petition  = {
      folioAltaUnica : this.foliSelect.solicitud.folioAltaUnica ,
      noEmpleado : this.usrActivo.idEmpleado,
      statusFinal : this.foliSelect.solicitud.statusAltaUnica,
      clientesValidos: this.foliSelect.solicitud.clientesUnicosValidos,
      comentarios : this.foliSelect.solicitud.comentarios,

  }
  this.ejecutaReintentarFolio(petition)
  console.log("reintentarFolio() ==> petition ==> "+petition)

  }
  evaluFolio(): void {
  // jQuery("#closeModal").click();
  
    this.messageError="";
    if(this.primerPregunta == "" || this.primerPregunta ==null || this.segundoPregunta == "" || this.segundoPregunta== null|| this.comentarios=="" || this.comentarios==null){
			if(this.primerPregunta == "" || this.primerPregunta ==null)
				this.messageError  = 	this.messageError +"Contesta la pregunta uno. ";
			if(this.primerPregunta == "" || this.segundoPregunta== null) 
      this.messageError  = 	this.messageError +"Contesta la pregunta dos. ";
      if(this.comentarios == "" || this.comentarios==null)
      this.messageError  = 	this.messageError +"Ingresa comentarios. ";
      console.log("evaluFolio() ==> messageError ==> "+this.messageError)
		}else
		if(this.primerPregunta == "no" || this.segundoPregunta == "no"){
      console.log("Se manda a cancelar");;
      var petition  = {
        folioAltaUnica : this.foliSelect.solicitud.folioAltaUnica ,
        noEmpleado : this.usrActivo.idEmpleado,
        statusFinal : 9006,
        comentarios : this.comentarios,
        respuestaUno : this.primerPregunta,
        respuestaDos : this.segundoPregunta,
        respuestaTres : "",
        clientesValidos : "",
        ip:"10.51.213.249",
        motivoRechazo:""

    }
    this.ejecutaStatusFinal(petition,"Cancela");
    }else{
      if(this.foliSelect.solicitud.motivoAlta != 2001 && (this.primerPregunta == "si" && this.primerPregunta == "si") ){
        var petition  = {
          folioAltaUnica : this.foliSelect.solicitud.folioAltaUnica ,
          noEmpleado : this.usrActivo.idEmpleado,
          statusFinal : 9004,
          comentarios : this.comentarios,
          respuestaUno : this.primerPregunta,
          respuestaDos : this.segundoPregunta,
          respuestaTres : "no",
          clientesValidos : "",
          ip:"10.51.213.249",
          motivoRechazo:""

      }
      this.ejecutaStatusFinal(petition,"Autoriza");
      }else
      if(this.foliSelect.solicitud.motivoAlta == 2001 && (this.primerPregunta == "si" && this.primerPregunta == "si") && this.listaCU.length ==0 ){
      this.isHominimo = true;
      var arCu = this.foliSelect.solicitud.clientesUnicos.split(",");// quitar 
      var dataArr = new Set(arCu);
      arCu = [...dataArr];
      var ss = new StatusFinalCu();
      this.showQuestion = false;
      ss.desc="Lista de clientes unicos";
      ss.id="Lista de clientes unicos";
      this.listaCU.push(ss);
      for(var a =0; a<arCu.length;a++){
        var ss = new StatusFinalCu();
        ss.desc=arCu[a];
        ss.id=arCu[a];
        this.listaCU.push(ss);

      }

    }else if(this.foliSelect.solicitud.motivoAlta == 2001 && !this.validarStatusCu()){
        console.log("evaluFolio()","YA NO FALTAN ");
        if(this.validarSiRechaza()){
          console.log("evaluFolio()","SE RECHAZA  ");
          if(!this.showRechazo){
              this.showRechazo = true;
          }else if(this.motivoRechazoSel == 0){
            this.messageError  = "Selecciona un motivo de rechazo"
          }else{
            this.messageError  ="";
             var petitiona  = {
              folioAltaUnica : this.foliSelect.solicitud.folioAltaUnica ,
              noEmpleado : this.usrActivo.idEmpleado,
              statusFinal : 9005,
              comentarios : this.comentarios,
              respuestaUno : this.primerPregunta,
              respuestaDos : this.segundoPregunta,
              respuestaTres : "si",
              clientesValidos : this.cadenaCuValidos(),
              ip:"10.51.213.249",
              motivoRechazo:this.motivoRechazoSel

          }
          console.log("evaluFolio() -> Rechazo ->peticion", petitiona);
          this.ejecutaStatusFinal(petitiona,"Rechaza");

          }
        }else{
          var petition  = {
            folioAltaUnica : this.foliSelect.solicitud.folioAltaUnica ,
            noEmpleado :this.usrActivo.idEmpleado,
            statusFinal : 9004,
            comentarios : this.comentarios,
            respuestaUno : this.primerPregunta,
            respuestaDos : this.segundoPregunta,
            respuestaTres : "no",
            clientesValidos : "",
            ip:"10.51.213.249",
            motivoRechazo:""

        }
        this.ejecutaStatusFinal(petition,"Autoriza");
          console.log("evaluFolio()","SE AUTORIZA  ");
        }

    }else{

    }
    }
  }

  validarSiRechaza (): boolean{
    var rechaza =false;
    this.listaCU.forEach(element => {
      if(element.status == 2){
        rechaza =true;
      }
    });
    return rechaza;

  }
  cadenaCuValidos (): string{
   var rspCadena ="";
    this.listaCU.forEach(element => {
      if(element.status == 2){
        rspCadena = element.desc+"|"
      }
    });
    return rspCadena;

  }
  validarStatusCu():boolean{
    var faltanStatus = false;
    var cuFalta : string[]=[];
    for(var a =1;a<this.listaCU.length;a++){

      if(this.listaCU[a].status ==0){
        cuFalta.push(this.listaCU[a].desc);
        faltanStatus = true;
      }
    }

    if(cuFalta.length>1){
      this.messageError = "Selecciona el status de los cu: "+cuFalta[0]
      for(var a = 1;a< cuFalta.length ; a++){
        this.messageError += ", "+cuFalta[a]
      }


    }else if(cuFalta.length == 1){
      this.messageError = "Selecciona el status del cu: "+cuFalta[0]
    }
    console.log("validarStatusCu()",cuFalta)
    return faltanStatus;
  }

  ejecutaStatusFinal (peticion,accion):void{
    this.loading = true;
    this.messageError ="";
    var tipoMensaje =accion;
    console.log("ejecutaStatusFinal() ==> peticion ==> ",peticion)
    this.iniciosmdvservice.statusFinalFolio(peticion).pipe(

      tap(data => {
        this.loading = false;
        if(data.codigo == 1 ){
          $("#cerrarBtn").click();
          if(this.usrActivo.solPendientes >1){
            this.usrActivo.solPendientes = this.usrActivo.solPendientes -1;
            this.userService.setUserLoggedIn(this.usrActivo);
          }
          var a = Swal.fire('Status final folio', `Se ha  ` +tipoMensaje+` el folio `+this.foliSelect.solicitud.folioAltaUnica, 'success');
          /*
          a.then(mesa => {
            if (mesa.value || mesa.dismiss) {
              $("#cerrarBtn").click();
              console.log("=============>===>===>===>===>===>", "url");
              $("#closeModal").click();
            }
           


          })*/
          a = null;
          this.loadData(1);

        }else if(data.codigo ==  22)
        this.messageError = "El folio: "+this.foliSelect.solicitud.folioAltaUnica+" no lo tienes asignado";

      })
    ).subscribe(folio => {
    }
      );
  }
  ejecutaReintentarFolio (peticion):void{
    this.loading = true;
    this.messageError ="";
    var tipoMensaje ="Reintentado";
    console.log("ejecutaStatusFinal() ==> peticion ==> ",peticion)
    this.iniciosmdvservice.ejecutaReintentarFolio(peticion).pipe(

      tap(data => {
        this.loading = false;
        if(data.codigo == 1 ){
          $("#cerrarBtn").click();
          var a = Swal.fire('Status final folio', `Se ha  ` +tipoMensaje+` el folio `+this.foliSelect.solicitud.folioAltaUnica, 'success');
          a = null;
          this.loadData(1);

        }else
        Swal.fire('Status final folio', `Ocurrio un error al reintentar actualizar el folio `+this.foliSelect.solicitud.folioAltaUnica, 'error');

      })
    ).subscribe(folio => {
    }
      );
  }
  actualizarPendientes():void{
    this.usrActivo.solPendientes  = this.solPendientes;
    console.log("actualizarPendientes()==> ",this.usrActivo.solPendientes)
    this.userService.setUserLoggedIn(this.usrActivo)
    //this.asignaContadores(this.foliosConstante,1)
    this.loadData(1);
    this.exisSolPendie= false;
  }
  loadFrame(): void {
    console.log(this.valueCU)
    if (this.valueCU == "Lista de clientes unicos") {
      this.showFrame = false;
    } else {
      this.showFrame = true;
      var cuAplicaA = this.valueCU.split("-");
      if(this.navegador   == "INTERNET EXPLORER")
      this.nuevaImplVisor2(cuAplicaA[0],cuAplicaA[1],cuAplicaA[2],cuAplicaA[3])
      else 
      this.construcFrame(cuAplicaA)
    }
  }
  nuevaImplVisor2(paisCu,canalCu,sucursalCu,folioCu){
    console.log("nuevaImplVisor2() ===>",paisCu," ====>" , canalCu," ====>" , sucursalCu," ====>" , folioCu);

   var peticion ={
    pais:paisCu,
    canal:canalCu,
    sucursal:sucursalCu,
    folio:folioCu
   }
   console.log("nuevaImplVisor2() ===> peticion ==> ",peticion);
   var expedienteNueo = [];
   this.listaExpeAltaN = [];
   var expedi = {descipcion:"",url:[], id:0};
   var descpExp = "";
   var urls:any[] =[];
   var asignar =false;
   var urlN   = "";
   var idd =-1;
   this.iniciosmdvservice.getExpeVisorB(JSON.stringify(peticion)).subscribe(data => 
     {
       if(data.codigo ==1)
         {
           this.exiteExpN = true;
           data.dato.forEach(element => {
             if(descpExp == ""){
               descpExp = element.tipoDoc + " - " + element.nombreDoc ;
               idd++;
               //urlN = element.ruta.replace("http://digitalizacion.servicios.baz1.com","https://10.48.195.135:8443/fqdnDigitaliza")
               urls.push( element.ruta );
               console.log("nuevaImplVisor1() ===> Nuevo  ==> ");
             }else if (descpExp == (element.tipoDoc + " - " + element.nombreDoc)){
               
               urls.push( element.ruta );
               console.log("nuevaImplVisor1() ===> Igual  ==> ");
             }else{
               
               expedi.url = urls;
               expedi.descipcion = descpExp;
               expedi.id = idd;
               this.listaExpeAltaN.push(expedi);
               console.log("nuevaImplVisor1() ===> Nuevo  ==> ");
               
               expedi = {descipcion:"",url:[],id:0};
               urls =[];
               descpExp =null;
               idd++;
               descpExp = element.tipoDoc + " - " + element.nombreDoc;
               urls.push( element.ruta );
               
             }
           });
           expedi.id = idd;
           expedi.url = urls;
           expedi.descipcion = descpExp;
           this.listaExpeAltaN.push(expedi);
           this.imgSelectN =  this.listaExpeAltaN[0].url[0];
           this.ultimoExpN =  this.listaExpeAltaN[0].url.length;
           this.descExN  = this.listaExpeAltaN[0].descipcion;
           console.log("====> OK",urls);
         }  else{
          this.exiteExpN = false;
          this.imgSelectN ="";
          this.descExN = "";
          this.valorActualN = 0;
          this.catAgirarN  =0;
          this.expActualN = 0;
          this.ultimoExpN  = 0;
          this.listaExpeAltaN  =[];
            console.error("====> ERROR",data);
         }      

      }, erro => {
       console.log("====> False",erro)
      
     });
 }
  saveStatusCu(): void {
    if (this.valueCU != "Lista de clientes unicos") {
      if (this.statusSelectCu == 0) {

      } else {
        for (var a = 1; a < this.listaCU.length; a++) {
          if (this.listaCU[a].id == this.valueCU) {
            this.listaCU[a].status = this.statusSelectCu;
            break;
          }
        }
      }
    }
  }
  activarSelec(ev: string): void {
    switch (ev) {
      case "evaluacion":
        this.navV = { evaliacion: true, cliente: false, solicitud: false };
        console.log("activarSelec ==>", this.photoSelect)
        setTimeout(() => {
        try {
         
          var im: HTMLImageElement = this.el.nativeElement.querySelector('#imgRef'); 
          im.src = "data:image/png;base64, "+this.photoSelect;
        //  this.img.nativeElement.src = "data:image/png;base64, " + this.photoSelect;
        } catch (error) {
         
        }
      }, 1000);
        break;
      case "cliente":
        this.navV = { evaliacion: false, cliente: true, solicitud: false };
        break;
      case "solicitud":
        this.navV = { evaliacion: false, cliente: false, solicitud: true };
        break;

    }
  }
  showTabs(valueTab):boolean{
    var isReturn:boolean = false;
    ///console.log("showTabs ==> this.valSelec ==>",valueTab)
    try{
      if(valueTab != undefined){
        this.splitValues =valueTab.split(":")
        this.valSelec = this.splitValues[0];
        //console.log("showTabs ==> this.valSelec ==>",this.valSelec.trim())
        switch(this.valSelec.trim()){
          case "Por atender":
            if(this.usrActivo.idPerfil==2022){
              isReturn= false;
            }else{
              isReturn= true;
            }
            break;
            case "Asignadas":
              isReturn= false;
              break;
              case "En evaluacion":
                isReturn= false;
              break;
              case "Atendidas":
                if(this.usrActivo.idPerfil==2022){
                  isReturn= false;
                }else{
                  isReturn= true;
                }
    
              break;
              case "Rechazadas":
                if(this.usrActivo.idPerfil==2022){
                  isReturn= false;
                }else{
                  isReturn= true;
                }
    
              break;
              case "Canceladas":
                if(this.usrActivo.idPerfil==2022){
                  isReturn= false;
                }else{
                  isReturn= true;
                }
              break;
              case "Todas":
                isReturn= false;
    
              break;
        }
      }
    }catch(e){
    }
    return isReturn;
  }
  navegatior():string
  {
    var navegador = navigator.userAgent;
    var msie = navegador.indexOf("MSIE "); 
    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) 
    {
      return "INTERNET EXPLORER";
    } else if (navigator.userAgent.indexOf('Firefox') !=-1) 
    {
      return "MOZILA FIREFOX";
    } else if (navigator.userAgent.indexOf('Chrome') !=-1) 
    {
      return "GOOGLE CHROME";
    } else if (navigator.userAgent.indexOf('Opera') !=-1) 
    {
      return "OPERA";
    } else 
    {
      return "OTRO";
    }
}


}
