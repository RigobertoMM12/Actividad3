import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IniciomdvComponent } from './iniciomdv.component';

describe('IniciomdvComponent', () => {
  let component: IniciomdvComponent;
  let fixture: ComponentFixture<IniciomdvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IniciomdvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IniciomdvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
