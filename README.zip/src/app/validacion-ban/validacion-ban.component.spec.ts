import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidacionBanComponent } from './validacion-ban.component';

describe('ValidacionBanComponent', () => {
  let component: ValidacionBanComponent;
  let fixture: ComponentFixture<ValidacionBanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidacionBanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidacionBanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
