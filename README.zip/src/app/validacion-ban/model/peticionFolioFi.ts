export class PeticionFolioFi {
  fInicio:string;
  fFinal:string;
  ban:number;
  temp:string;
  idFlujo: number = 1;
}
