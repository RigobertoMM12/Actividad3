export class BancaDigital {
  cu:string =null;
  dpi:string =null;
  fechaVencimientoDpi:string ="";
  edoCivil:string=null;
  fechaApertura:string =null;
  genero:string=null;
  pais:string=null;
  noCuenta:string =null;
  telefono:string =null;
}
