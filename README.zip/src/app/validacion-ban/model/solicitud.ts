export class Solicitud {
  idBitacoraAltaUnica:number;
  folioAltaUnica:string;
  clientesUnicos:string;
  motivoAlta:number;
  descMotivoAlta:string;
  flujoAlta:number =0;
  descFlujoAlta:string;
  statusAltaUnica:number;
  descStatusAltaUnica:string;
  fechaLlegada:string;
  fechaAsignada:string;
  fechaIniciaEvaluacion:string;
  fechaTerminaEvaluacion:string;
  empleadoAsigna:string;
  nombreEmpleadoAsigna:string;
  empleadoEvalua:string;

  comentarios:string;
  nombreEmpleadoEvalua:string;
  clientesUnicosValidos:string;

  motivoRechazo:number;
  pregunta1:string;
  respuesta1:string;
  pregunta2:string;
  respuesta2:string;
  pregunta3:string;
  respuesta3:string;


}
