import { TestBed } from '@angular/core/testing';

import { ValidacionBanserviceService } from './validacion-banservice.service';

describe('ValidacionBanserviceService', () => {
  let service: ValidacionBanserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ValidacionBanserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
