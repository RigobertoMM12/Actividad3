import { Injectable } from '@angular/core';
import { FolioAlta }from './model/folioAlta'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { Observable, throwError, from, of } from 'rxjs';
import swal from 'sweetalert2';

import { Router } from '@angular/router';
import { PeticionFolio } from './model/peticionFolio';
import { DtoExtra } from './model/dtoExtra';
import { PeticionFolioFi } from './model/peticionFolioFi';
import { AsignaFolioModel } from './model/asignaFolioModel';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ValidacionBanserviceService {

  
  private urlEndPoint: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/getNotificaciones';
  //private ulrgetFoliosAuto : string =  environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/getSolicitudConstante_beta';
  private ulrgetFoliosAuto : string =  environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/getSolicitudConstante_v2_beta';
  private urlConsultaFolios: string =environment.apiUrl+  'mesacontrolguatemala/mesavalidacion/getSolicitud_beta';
  private urlConsultaOperadores: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/empleadosActivos';
  private urlConsultaFolioFiltro: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/filtros_beta';
  private urlConsultaFoliocomple: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/getSolicitudComple_beta';
  private urlAsignaFolio: string =environment.apiUrl+  'mesacontrolguatemala/mesavalidacion/asignarSolicitudManual_beta';
  private urlStatusFinalFolio: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/cambioStatusFinal_beta';
  private urlReintentarStatusFolio: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/actualizarStatus_beta';
  private urlCambioFolio: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/cambioStatus_beta';
  private urlGetPhoto: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/obtenerFoto_beta';

  private urlgetExpeVisorA: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/getRutasWeb_beta';
  private urlgetExpeVisorB: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/getExpUnico_beta';
  private urlgetExpeVisorC: string = (environment.apiUrl)+ 'mesacontrolguatemala/mesavalidacion/getExpedientesApiDigi_beta';
  
  private httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
  private httpHeaderss = new HttpHeaders({ 'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Credentials': 'true',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE' });
  constructor(private http: HttpClient, private router: Router) { }
  
  getFoliosAlta(peticion:PeticionFolio): Observable<any>  {
    return this.http.post(this.urlConsultaFolios,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }
  getFoliosAltaConstante(peticion:String): Observable<any>  {
    return this.http.post(this.ulrgetFoliosAuto,peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }
  getFoliosAltaFiltro(peticion:PeticionFolioFi): Observable<any>  {
    return this.http.post(this.urlConsultaFolioFiltro,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      }
      )
    );
  }
  getFoliosAltaComple(peticion:PeticionFolio): Observable<any>  {
    return this.http.post(this.urlConsultaFoliocomple,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      }
      )
    );
  }
  cambiarStatus(peticion:string): Observable<any>  {
    return this.http.post(this.urlCambioFolio,peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      }
      )
    );
  }
  statusFinalFolio(peticion:string): Observable<any>  {
    return this.http.post(this.urlStatusFinalFolio,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      }
      )
    );
  }
  ejecutaReintentarFolio(peticion:string): Observable<any>  {
    return this.http.post(this.urlReintentarStatusFolio,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      }
      )
    );
  }
  getPeradorActivos(): Observable<any>  {
    return this.http.post(this.urlConsultaOperadores,null).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      }
      )
    );
  }
  asignaFolioManual(peticion:AsignaFolioModel): Observable<any>  {
    return this.http.post(this.urlAsignaFolio,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      }
      )
    );
  }
  getPhoto(peticion:string): Observable<any>  {
    return this.http.post(this.urlGetPhoto,peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 200) {
          return e.error.text;
          
        }
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }
  getExpeVisorC(peticion:string): Observable<any>  {
    return this.http.post(this.urlgetExpeVisorC,peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }
  getExpeVisorA(peticion:string): Observable<any>  {
    return this.http.post(this.urlgetExpeVisorA,peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }
  getExpeVisorB(peticion:string): Observable<any>  {
    return this.http.post(this.urlgetExpeVisorB,peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }
}
