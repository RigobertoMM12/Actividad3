import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ReportesmdcService } from '../services/reportesMdcService';
import { PaginationInstance } from 'ngx-pagination';
import { formatDate } from '@angular/common';
import { ColFolio } from '../reporte-asigna/ColFolio';
import * as XLSX from 'xlsx';
import { MantenimientoUsrService } from '../mantenimiento-usr/mantenimiento-usr.ervice';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService';
import { saveAs } from 'file-saver';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-paramtros-mdc',
  templateUrl: './paramtros-mdc.component.html',
  styleUrls: ['../css/mesaDeControl.css']
})
export class ParamtrosMdcComponent implements OnInit {

  isReporte: boolean = false;
  title = 'Excel';
  loading: boolean = false;
  ffechaInicio: { day: number, year: number, month: number };
  ffechaFin: { day: number, year: number, month: number };
  constructor(private reportesService: ReportesmdcService, private mantenimiento: MantenimientoUsrService, private userService: UserService) { }
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 6,
    currentPage: 1
  };
  empleadoSelect: number;
  usrActivo: UsuarioModel;
  fInicio: string = "";
  fFinal: string = "";
  fechaActual: Date;
  fechaActualR: Date = new Date();
  config: any;

  collection = { count: 60, data: [] };
  collectionReport = { count: 60, data: [] };
  foliosReport: ColFolio[];
  captcha: string;
  respCaptch: string;
  isbad: boolean = false;
  isbadId: boolean = false;
  isbadDesc: boolean = false;
  isbadVal: boolean = false;
  isActual:number=0;
  tittleBotton: string = "";
  parametroA : any = {idParametro:null,descripcion:null,valor:null,descValor:null};
  descQueAce = "";
  ngOnInit(): void {
    this.usrActivo = this.userService.getUserLoggedIn();
    this.loadDataParametros()
    //this.loadData()
  }

  loadDataParametros(): void {
    console.log("")
    this.loading = true;
    var perticion = { noEmpleado:this.usrActivo.idEmpleado }
    this.mantenimiento.getParametros(JSON.stringify(perticion)).subscribe(
      data => {
        if(data.codigo == 102){
          this.collection.data = [];
        this.collection.data = data.dato.tabla;
          this.loading = false
          this.config = {
            itemsPerPage: 6,
            currentPage: 1,
            totalItems: this.collection.data.length
          };
        }else{
          this.loading = false
        }
        
        
      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      });
  }
  modificaCrea(parametro,ban):void{
    this.isActual =  ban;
    if(ban == 1){
      this.descQueAce = "MODIFICAR PARÁMETRO"
      this.parametroA = parametro;
    }else{
      this.descQueAce = "CREAR PARÁMETRO"
      this.parametroA = {idParametro:null,descripcion:null,valor:"",descValor:null};
    }
    
  }
  ejecutarV():void{
    console.log("this.parametroA.idParametro  ==> ",this.parametroA.idParametro )
    if(this.parametroA.idParametro == "" || this.parametroA.idParametro == null || this.parametroA.descripcion == "" || this.parametroA.descripcion == null || this.parametroA.valor == "" || this.parametroA.valor == null){
      if(this.parametroA.idParametro == "" || this.parametroA.idParametro == null){
        this.isbadId =  true
      }
      if(this.parametroA.descripcion == "" || this.parametroA.descripcion == null){
        this.isbadDesc =  true
      }
      if(this.parametroA.valor == "" || this.parametroA.valor == null){
        this.isbadVal =  true
      }
    }else{
      $("#closeModal").click();
      this.loading = true;
      var perticion={
        paquete:"GSCRMCPA0004",
        sp:"GSCRMCSPM0006",
        xmlName:"",
        xml:'<?xml version="1.0" encoding="ISO-8859-1" standalone="yes"?><Registros><Registro   FIPARAMETROID="'+this.parametroA.idParametro +'" FCDESCRIPCION="'+this.parametroA.descripcion+'" FCVALOR="'+((this.parametroA.descValor == null)?"": this.parametroA.descValor)+'" FIVALOR="'+this.parametroA.valor+'"  FIEMPLOYEEID="'+this.usrActivo.idEmpleado+'" FCIPADDRESS="10.89.41.115"/></Registros>'
      }
      console.log("parametros==> ",perticion)
      
      this.mantenimiento.alterUParametros(JSON.stringify(perticion)).subscribe(
        data => {
          if(data.codigo == 2){
           if (this.isActual == 1){
            this.loading = true;
            Swal.fire(
              'Parámetro Modificado!',
              `Parámetro  ${this.parametroA.idParametro} modificado con éxito.`,
              'success'
            )
            this.loadDataParametros();
           }else{
            this.loading = true;
            Swal.fire(
              'Parámetro Creado!',
              `Parámetro  ${this.parametroA.idParametro} creado con éxito.`,
              'success'
            )
            this.loadDataParametros();
           }
          }else{
            this.loading = false
          }
          
          
        }, err => {
          this.loading = false;
          console.log("loadData()=> ", err)
        });

    }
    
  }

    bajaParametro(parametro): void {

      Swal.fire({
        title: 'Está seguro?',
        text: `¿Seguro que desea eliminar el parametro ${parametro.idParametro} - ${parametro.descripcion}?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Si, eliminar!',
        cancelButtonText: 'No, cancelar!'
      }).then((result) => {
        if (result.value) {
         
   this.loading = true;
   var perticion = { id:parametro.idParametro, catalogo:"GSCRMCCT0007"};
   this.mantenimiento.deleteParametros(JSON.stringify(perticion)).subscribe(
     data => {
       if(data.codigo == 2){
         Swal.fire(
           'Parametro Elimnado!',
           `Parametro  ${parametro.idParametro} - ${parametro.descripcion} eliminado con éxito.`,
           'success'
         )
         this.loadDataParametros();
       }else{
         this.loading = false
       }
       
       
     }, err => {
       this.loading = false;
       console.log("loadData()=> ", err)
     });
    
        } else if (result.dismiss === Swal.DismissReason.cancel || result.dismiss === Swal.DismissReason.backdrop || result.dismiss === Swal.DismissReason.esc) {
          Swal.fire(
            'Cancelado',
            'Se cancelo',
            'error'
          )
        }
      })

    console.log("==========> ",parametro)

     
  }
  

  showReport(noEmpleye): void {
    this.empleadoSelect = noEmpleye;
    console.log("showReport==> noEmpleye==> ", noEmpleye)
    this.isReporte = true;
    this.collectionReport.data = [];
    this.config = {
      itemsPerPage: 6,
      currentPage: 1,
      totalItems: this.collectionReport.data.length
    };
    this.loadDataBitacora();

  }
  ExportTOExcel() {
    if (this.captcha == this.respCaptch) {
      this.isbad = false;
      $("#closeModal").click();

      //      -----------------
      this.loading = true;
      this.fechaActual = new Date();
      if (this.ffechaFin == null) {
        this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
      } else {
        this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
      }

      if (this.ffechaInicio == null) {
        this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
      } else {
        this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
      }



      var peticion = {
        "fInicio": this.fInicio, "fFinal": this.fFinal, "noEmpleado": this.empleadoSelect
      }
      console.log(" loadData() ===> ", peticion)
      this.fFinal = this.converir(this.fFinal);
      this.fInicio = this.converir(this.fInicio);

      this.reportesService.getReporteSesionExcel(JSON.stringify(peticion)).subscribe(
        resp => {

          if (resp.codigo == 2) {
            if (resp.dato != null) {
              this.downloadFile(resp.dato, "application/vnd.openxmlformats-officedocument.spreadsheetml")

            }

          }
          this.loading = false

        }, err => {
          this.loading = false;
          console.log("loadData()=> ", err)
        })

/*
      const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Reporte');
      XLSX.writeFile(wb, 'ReporteSesion_.xlsx');*/
    } else {
      this.isbad = true;
      if (this.respCaptch.length == 0) {
        this.tittleBotton = "Captcha es requerido"
      } else if (this.respCaptch.length < 8) {
        this.tittleBotton = "Captcha tiene que ser de 8 posiciones"
      } else {
        this.tittleBotton = "Captcha diferente "
      }


    }
  }
 
  regresar() {
    this.isReporte = false; this.config = {
      itemsPerPage: 6,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
  }
  loadDataBitacora(): void {
    console.log("-------------------***");
    this.foliosReport = [];
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null) {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
    }



    var peticion = {
      "fInicio": this.fInicio, "fFinal": this.fFinal, "noEmpleado": this.empleadoSelect
    }
    console.log(" loadData() ===> ", peticion)
    this.fFinal = this.converir(this.fFinal);
    this.fInicio = this.converir(this.fInicio);
    this.reportesService.getReporteSesion(JSON.stringify(peticion)).subscribe(
      resp => {

        if (resp.codigo == 2) {
          if (resp.dato != null) {
            resp.dato.forEach(element => {
              this.collectionReport.data.push(element)
            });
          }

        }

        this.config = {
          itemsPerPage: 6,
          currentPage: 1,
          totalItems: this.collectionReport.data.length
        };
        this.loading = false




      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      })

  }
  converirW(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[1] + "/" + nvalo[0] + "/" + nvalo[2];
  }
  converir(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[2] + "-" + nvalo[1] + "-" + nvalo[0];
  }
  creaCodigo() {
    this.tittleBotton = ""
    this.isbad = false
    this.captcha = this.randomString(8,
      '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ');
    this.respCaptch = "";
  }
  randomString(length, chars): string {
    var result = '';
    for (var i = length; i > 0; --i)
      result += chars[Math.round(Math
        .random()
        * (chars.length - 1))];
    return result;
  }

  downloadFile(blobContent, tyCont): void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});

    saveAs(blob, 'ReporteSesion_.xlsx');
  }
  base64toBlob(base64Data, contentType): Blob {
    contentType = contentType || '';
    let sliceSize = 1024;
    let byteCharacters = atob(base64Data);
    let bytesLength = byteCharacters.length;
    let slicesCount = Math.ceil(bytesLength / sliceSize);
    let byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }
  navegatior():string
    {
      var navegador = navigator.userAgent;
      var msie = navegador.indexOf("MSIE "); 
      if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) 
      {
        return "INTERNET EXPLORER";
      } else if (navigator.userAgent.indexOf('Firefox') !=-1) 
      {
        return "MOZILA FIREFOX";
      } else if (navigator.userAgent.indexOf('Chrome') !=-1) 
      {
        return "GOOGLE CHROME";
      } else if (navigator.userAgent.indexOf('Opera') !=-1) 
      {
        return "OPERA";
      } else 
      {
        return "OTRO";
      }
    }
}
