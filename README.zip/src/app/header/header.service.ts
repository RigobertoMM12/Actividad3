import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UsuariocModel } from './model/UsuariocModel';
import { Observable, throwError, timer, Subject } from 'rxjs';
import { map, catchError, shareReplay, timeout } from 'rxjs/operators';
import Swal from 'sweetalert2';
import { environment } from '../../environments/environment';
import { valorReloj } from './model/valorReloj';

@Injectable()
export class MyHeaderService {
  //Variables Reloj
  clock: Observable<Date>;
  infofecha$ = new Subject<valorReloj>();
  vr: valorReloj;
  ampm: string;
  hours: number;
  minute: string;
  weekday: string;
  months: string;
  //end Variables Reloj

  //private urlEndPoint: string = environment.apiUrl + 'oolpanama-1/mesavalidacion/sesion_beta';

  private urlAuthenticate: string = environment.apiUrlC + 'usuarios/authenticate';

  private urlEndPoint: string = environment.apiUrl + 'mesacontrolguatemala/sesion_beta';
  private urlSessionLlave: string = environment.apiUrl + 'mesacontrolguatemala/sesion_llavemaestra_beta';
  
  private httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json;charset=UTF-8' });
  constructor(private http: HttpClient, private router: Router) {
    this.clock = timer(0, 1000).pipe(map(t => new Date()), shareReplay(1));
  }

  starSessionN(peticion: string): Observable<any> {
    return this.http.get(this.urlAuthenticate+peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore: any = response;
        //let datosEmpleado = notSore.dato as UsuarioModel;
        return notSore;
      }
      ), catchError(e => {
        console.log("catchError()-->", e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          Swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }


        return throwError(e);
      })
    );
  }

  starSession(peticion: string): Observable<any> {
    return this.http.post(this.urlEndPoint, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore: any = response;
        //let datosEmpleado = notSore.dato as UsuarioModel;
        return notSore;
      }
      ), catchError(e => {
        console.log("catchError()-->", e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          Swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }


        return throwError(e);
      })
    );
  }
  starSessionLL(peticion: string): Observable<any> {
    console.log("INICIA <==>",new Date())
    return this.http.post(this.urlSessionLlave, peticion, { headers: this.httpHeaders }).pipe(
      timeout(20000),
      map(response => {

        let notSore: any = response;
       /* let datosEmpleado =null;
        if(notSore.codigo == 107){
          Swal.fire("Problema con inicio de session",notSore.descripcion, 'error');
        }else{
          datosEmpleado = notSore.dato as UsuarioModel;
        }*/
        
        return notSore;
      }
      ), catchError(e => {
        console.log("Termina <==>",new Date())
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          Swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }


        return throwError(e);
      })
    );
  }
  getInfoReloj(): Observable<valorReloj> {
    this.clock.subscribe(t => {
      this.hours = t.getHours() % 12;
      this.hours = this.hours ? this.hours : 12;
      this.vr = {
        hora: this.hours,
        minutos: (t.getMinutes() < 10) ? '0' + t.getMinutes() : t.getMinutes().toString(),
        ampm: t.getHours() > 11 ? 'PM' : 'AM',
        diaymes: t.toLocaleString('es-MX', { day: '2-digit', month: 'long' }).replace('.', '').replace('-', ' '),
        diadesemana: t.toLocaleString('es-MX', { weekday: 'long' }).replace('.', ''),
        segundo: t.getSeconds() < 10 ? '0' + t.getSeconds() : t.getSeconds().toString()

      }
      this.infofecha$.next(this.vr);
    });
    
    return this.infofecha$.asObservable();

  }

}