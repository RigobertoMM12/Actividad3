export class valorReloj {
    hora: number;
    minutos: string;
    ampm: string;
    diadesemana: string;
    diaymes: string;
    segundo: string;
  }