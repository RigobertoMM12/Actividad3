export class TablaParametros {
    idParametro:number;
    descripcion:string;
    valor: string ;
    descValor: string ;
    
}
  