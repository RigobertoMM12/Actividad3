export class UsuariocModel {
    id:number;
    nombre:string;
    aPaterno:number;
    aMaterno: string ;
    usuario: string ;
    pass: string ;
    fechaCreacion: number ;
    status:number;
    idPerfil:number =2022;
}
  