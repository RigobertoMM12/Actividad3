import { Component } from '@angular/core';
import { MyHeaderService } from './header.service';
import { UsuariocModel } from './model/UsuariocModel';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { UserService } from './UserService';
import * as $ from 'jquery';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { valorReloj } from './model/valorReloj';
import { NGXLogger } from 'ngx-logger';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent {
  //Variables Reloj
  datos$: Observable<valorReloj>;
  hora: number;
  minutos: string;
  dia: string;
  fecha: string;
  ampm: string;
  segundos: string;
  title: string;
  //end Variables Reloj
  loading = false;
  usrActivo: UsuariocModel = new UsuariocModel();
  fechaDia: any;
  existeSession: boolean = false;
  timeOut: any;
  noEmpleado = 0;
  menu = { validacionC: false, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios: false,validacionBan: false} //JAGP
  constructor(private headerService: MyHeaderService, private router: Router, private userService: UserService, private location: Location, private logger: NGXLogger) { }
  isAltaUnica: boolean = false;
  isAltaUnica1: boolean = false;
  isMesaAdmin: boolean = false;
  isMesaC: boolean = false;
  isMesaC1: boolean = false;
  isCyaal: boolean = false;
  emploteT: number;
  nameT: string;
  tittleBotton: string = "";
  isbad: boolean = false;
  valueCierre: string = "";
  showF:boolean = false;
  showC:boolean = false;

  ngOnInit(): void {
    this.datos$ = this.headerService.getInfoReloj();
    this.datos$.subscribe(x => {
      this.usrActivo = this.userService.getUserLoggedIn();
      this.hora = x.hora;
      this.minutos = x.minutos;
      this.dia = x.diadesemana;
      this.fecha = x.diaymes;
      this.ampm = x.ampm;
      this.segundos = x.segundo
    });

    console.log(" pathname ========= > ", location.pathname);
    var datos = location.pathname.split("/");
    if (datos.length > 1) {
      this.activarmenu(datos[2])
    }
    this.loadData();
    this.fechaDia = new Date();
  }

  afterClick(ruta): void {

    this.activarmenu(ruta)
    ruta = "" + ruta
    if (ruta == "misSolicitudes")
      ruta = "solicitudes"
    this.router.navigate(['/' + ruta]);
    console.log("afterClick-()====> pathname ========= > ", location.pathname);
  }
  activarmenu(ruta): void {
    switch (ruta) {
      case "":
        this.menu = { validacionC: true, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios: false,validacionBan: false}//JAGP
        break;
      case "consultaExpe":
        this.menu = { validacionC: false, consultaExp: true, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios: false ,validacionBan: false}//JAGP
        break;
        case "validacionBan":
        this.menu = { validacionC: false, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios: false ,validacionBan: true}//JAGP
        break;

      case "reporteValidacion":
      case "reporteAtenciont":
      case "reporteAsigna":
      case "reporteAtencion":
        this.menu = { validacionC: false, consultaExp: false, reportes: true, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios: false ,validacionBan: false}//JAGP
        break;
      case "notificaciones":
        this.menu = { validacionC: false, consultaExp: false, reportes: false, notificacion: true, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios: false ,validacionBan: false}//JAGP
        break;
      case "solicitudes":
        this.menu = { validacionC: false, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: true, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios: false ,validacionBan: false}//JAGP
        break;
      case "misSolicitudes":
        this.menu = { validacionC: false, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: true, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios: false ,validacionBan: false}//JAGP
        break;
      case "reporteSolicitudes":
      case "reporteResumen":
      case "reporteTiempoD":
      case "reporteTiempoR":
      case "reporteSesion":
        this.menu = { validacionC: false, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: true, reporteSucursal: false, reasignaSol: false, usuarios: false ,validacionBan: false}//JGAP
        break;
      case "reporteHorario":
      case "reportReenvio":
      case "reporteObservados":
      case "reporteGeografia":
        this.menu = { validacionC: false, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: true, reasignaSol: false, usuarios: false ,validacionBan: false}//JAGP
        break;
      case "reasignaSol":
        this.menu = { validacionC: false, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: true, usuarios: false ,validacionBan: false}//JAGP
        break;
      case "mantenimientoUsr":
        this.menu = { validacionC: false, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios: true ,validacionBan: false}//JAGP
        break;
    }
  }
  closeSession(): void {
    if(this.valueCierre == ""){
      Swal.fire('Atención', `Por favor selecciona una motivo de cierre de sesión`, 'warning');
    }else{
    this.loading = true;
    var peticion = {
      noEmpleado: this.usrActivo.id,
      codigoSesion:this.valueCierre,
      nombre: "",
      aPaterno: "",
      aMaterno: "",
      noIntentos: 1,
      iniSesion: 1,
      ll: "",
      navegador: this.navegatior(),
    }
    console.log("loadData() ==> peticion ==> ", peticion);
     $("#myModalCesion").click();

    this.headerService.starSession(JSON.stringify(peticion)).subscribe(
      usr => {
        this.userService.removeUserLoggedIn();
        this.existeSession = false;
        this.loading = false;
        this.router.navigate(['sinSe']);
        var url = "https://auth.socio.gs/nidp/jsp/logoutSuccess_latest.jsp?rp=https://www.google.com";
        $(location).attr('href', url);
        
      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      },
      () => this.navigate()
    );

    console.log("closeSession-()====> Termina cierre session ========= > ");
    }
  }

  navigate() {
   
  }

  loadData(): void {

    console.log("==============>loadData()========>", this.userService.getUserLoggedIn())
    console.log("==============>loadData()========>path =>", location)
    console.log("==============>loadData()========>path1 =>", location.href)
    console.log("==============>loadData()========>path2 =>", location.pathname)
    console.log("==============>loadData()========>path3 =>", location.toString())
    
    //this.userService.removeUserLoggedIn();

    var mmm = this.userService.getUserLoggedIn();
    if (mmm != null) {
      if (mmm.idPerfil == 0) {
        this.userService.setUserLoggedIn(null)
      }
    }
    
    
    this.loading = false;
    var code = location.toString().split("&")
    var code = code[0].split("code=");
    console.log("==============>loadData()========>code =>", code[1])
    if (code.length > 1) {
      console.log("==============>loadData()========>code =>", code[1])
    }
    

  //INICIA   

    if (this.userService.getUserLoggedIn() == null) {
      this.router.navigate(['login']);
    }else {
      this.existeSession = true;
      this.usrActivo = this.userService.getUserLoggedIn();
      this.isMesaAdmin = true;
      
      this.title = 'Mesa De Validación Guatemala';
      switch (location.pathname) {
        case "/":
        case "/MesaDeControlGuatemala/":
        //case "/mantenimientoUsr"://JAGP
        case "/solicitudes"://Mesa de control
        case "/misSolicitudes":
        case "/reasignaSol":
        case "/reporteSesion":
        case "/reporteResumen":
        case "/reporteTiempoD":
        case "/reporteSolicitudes":
        case "/reporteTiempoR":
        case "/reporteHorario":
        case "/reporteGeografia":
        case "/reporteObservados":
        case "/reportReenvio":
          this.menu = { validacionC: true, consultaExp: false, reportes: false, notificacion: false, buzonGeneral: false, misSolicitud: false, reporteMesa: false, reporteSucursal: false, reasignaSol: false, usuarios : false ,validacionBan: false}//JAGP
          this.router.navigate(['']);
          break;
      }


     

    }




  }
  

  clickPruba() {
    console.log("=============>clickPruba==============>")
  }


  nombre: string = 'Rigoberto Martinez Mateo';
  decFolio: string = "Folios pendientes por validar:"


  

  navegatior(): string {
    var navegador = navigator.userAgent;
    var msie = navegador.indexOf("MSIE ");
    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
      return "INTERNET EXPLORER";
    } else if (navigator.userAgent.indexOf('Firefox') != -1) {
      return "MOZILA FIREFOX";
    } else if (navigator.userAgent.indexOf('Chrome') != -1) {
      return "GOOGLE CHROME";
    } else if (navigator.userAgent.indexOf('Opera') != -1) {
      return "OPERA";
    } else {
      return "OTRO";
    }
  }
  modalSesion(): void {
    var hoy = new Date();
    var dd = (hoy.getDate() < 10 ? '0' : '') + hoy.getDate();
    var mm = ((hoy.getMonth() + 1) < 10 ? '0' : '') + (hoy.getMonth() + 1);
    var aa = hoy.getFullYear();
    var hh1 = hoy.getHours();
    var mm1 = hoy.getMinutes();
    var ss1 = hoy.getSeconds();
    var fechaI = aa + "-" + mm + "-" + dd + " " + hh1 + ":" + mm1 + ":" + ss1;
    

  }
  tiempoResMas = function (date1, date2) {
    var navegat = this.navegatior();
    var start_actual_time;
    var end_actual_time;
    var tiempoT;
    if (navegat == "INTERNET EXPLORER") {
      var fechaSplit = date1.split(" ");
      var fechDate1 = fechaSplit[0].split("-");
      var horaDate1 = fechaSplit[1].split(":");
      var fechaSplit2 = date2.split(" ");
      var fechDate2 = fechaSplit2[0].split("-");
      var horaDate2 = fechaSplit2[1].split(":");

      start_actual_time = new Date(fechDate1[0], fechDate1[1] - 1, fechDate1[2], horaDate1[0], horaDate1[1], horaDate1[2]);
      end_actual_time = new Date(fechDate2[0], fechDate2[1] - 1, fechDate2[2], horaDate2[0], horaDate2[1], horaDate2[2]);
      tiempoT = end_actual_time - start_actual_time;
    } else {
      start_actual_time = new Date(date1);
      end_actual_time = new Date(date2);
      tiempoT = end_actual_time - start_actual_time;
    }
    return tiempoT;
  }
  evaluarTresFH = function (horaComEn, horaComidaSa, time) {
    var navegat = this.navegatior();
    var horaComEn_time;
    var horaComidaSa_time;
    var end_actual_time;
    var tiempoT;
    if (navegat == "INTERNET EXPLORER") {
      var fechaSplit = horaComEn.split(" ");
      var fechDate1 = fechaSplit[0].split("-");
      var horaDate1 = fechaSplit[1].split(":");
      var fechaSplit2 = horaComidaSa.split(" ");
      var fechDate2 = fechaSplit2[0].split("-");
      var horaDate2 = fechaSplit2[1].split(":");
      var fechaSplit3 = time.split(" ");
      var fechDate3 = fechaSplit3[0].split("-");
      var horaDate3 = fechaSplit3[1].split(":");

      horaComEn_time = new Date(fechDate1[0], fechDate1[1] - 1, fechDate1[2], horaDate1[0], horaDate1[1], horaDate1[2]);
      horaComidaSa_time = new Date(fechDate2[0], fechDate2[1] - 1, fechDate2[2], horaDate2[0], horaDate2[1], horaDate2[2]);
      end_actual_time = new Date(fechDate3[0], fechDate3[1] - 1, fechDate3[2], horaDate3[0], horaDate3[1], horaDate3[2]);
    } else {
      horaComEn_time = new Date(horaComEn);
      horaComidaSa_time = new Date(horaComidaSa);
      end_actual_time = new Date(time);
    }

    return (end_actual_time > horaComEn_time && end_actual_time < horaComidaSa_time);
  }
}