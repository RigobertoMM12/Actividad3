import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { PaginationInstance } from 'ngx-pagination';
import { ReportesmdvService } from './../reporte-asigna/reportesmdv.service';

import { formatDate } from '@angular/common';
import * as XLSX from 'xlsx';
import { ColRepoAten } from './../reporte-atencion/ColRepoAten';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-reporte-validacion',
  templateUrl: './reporte-validacion.component.html',
  styleUrls: ['./reporte-validacion.component.css']
})
export class ReporteValidacionComponent implements OnInit {


  title = 'Excel';
  loading: boolean = false;
  constructor(private reportesService: ReportesmdvService) { }
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 6,
    currentPage: 1
  };
  fInicio: string = "";
  fFinal: string = "";
  fechaActual: Date;
  fechaActualR: Date = new Date();
  config: any;
  ffechaInicio: { day: number, year: number, month: number };
  ffechaFin: { day: number, year: number, month: number };
  collection = { count: 60, data: [] };
  today = new Date()
  minDate = { year: 2010, month: 5, day: 25 };
  maxDate= { year: 2020, month: 5, day: 25 };
  startDate = {year:new Date().getFullYear(),month: ((new Date().getMonth() + 1) < 10 ? '0' : '') + (new Date().getMonth() + 1), day: (new Date().getDate() < 10 ? '0' : '') + new Date().getDate()};

  ngOnInit(): void {
    this.today.setDate(this.today.getDate() - 30);
    this.minDate = { year: this.today.getFullYear(), month: (this.today.getMonth() + 1), day: this.today.getDate()  };
    this.today.setDate(this.today.getDate() + 30);
    this.maxDate = { year: this.today.getFullYear(), month: (this.today.getMonth() + 1), day: this.today.getDate()  };
    this.loadData()
  }
  ExportTOExcel() {
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null) {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
    }
    var peticion = {
      "fInicio": this.fInicio, "fFinal": this.fFinal
    }
    console.log(" loadData() ===> ", peticion)
    this.reportesService.getReporteValidacionExpExcel(JSON.stringify(peticion)).subscribe(
      resp => {

        if (resp.codigo == 2) {
          if (resp.dato != null) {
            this.downloadFile(resp.dato, "application/vnd.openxmlformats-officedocument.spreadsheetml")

          }

        }
        this.loading = false

      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      })
    /*
  const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);  
  const wb: XLSX.WorkBook = XLSX.utils.book_new();  
  XLSX.utils.book_append_sheet(wb, ws, 'Reporte');  
  XLSX.writeFile(wb, 'ReporteAtencionTotales_.xlsx');  */
  }
  loadData(): void {
    console.log("-------------------***");
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null) {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
    }

    //this.fFinal = this.converirW(this.fFinal);

    // this.fInicio = this.converirW(this.fInicio);
    var peticion = {
      "fInicio": this.fInicio, "fFinal": this.fFinal
    }
    console.log(" loadData() ===> ", peticion)
    this.collection.data = [];
    this.reportesService.getReporteValidacionExp(JSON.stringify(peticion)).subscribe(
      resp => {

        if (resp.codigo == 1) {
          if (resp.dato != null) {
            console.log("loadData() => resp.dato ==>", resp.dato)
            resp.dato.forEach(element => {
              element.succ = this.sepraSucursalC(element.cuenta,1) 
              element.cuentaaaa = this.sepraSucursalC(element.cuenta,2) 
              this.collection.data.push(element)
            });
          }

        }

        this.config = {
          itemsPerPage: 8,
          currentPage: 1,
          totalItems: this.collection.data.length
        };
        this.loading = false




      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      })

  }
  converirW(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[1] + "/" + nvalo[0] + "/" + nvalo[2];
  }
  converir(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[2] + "-" + nvalo[1] + "-" + nvalo[0];
  }
  sepraSucursalC(cuenta: string, ban: number): string {
    var retu: string;
    if (cuenta != null) {
      if (cuenta.length > 10) {
        if (ban == 2) {
          retu = cuenta.substring(cuenta.length - 10, cuenta.length)
        } else if (ban == 1) {
          retu = cuenta.substring(0, cuenta.length - 10)
        }
      } else {

      }
    } else {
      retu = cuenta;
    }
    if(retu == undefined){
      if(ban == 1){
        retu ="0000";
      }else{
        retu ="0000000000";
      }
    }

    return retu;
  }

  downloadFile(blobContent, tyCont): void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});

    saveAs(blob, 'ReporteValidacion_.xlsx');
  }
  base64toBlob(base64Data, contentType): Blob {
    contentType = contentType || '';
    let sliceSize = 1024;
    let byteCharacters = atob(base64Data);
    let bytesLength = byteCharacters.length;
    let slicesCount = Math.ceil(bytesLength / sliceSize);
    let byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }
}
