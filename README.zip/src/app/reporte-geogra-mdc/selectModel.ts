export class SelectModel {
    id_tipo:number;
    desc_tipo:string;
}
