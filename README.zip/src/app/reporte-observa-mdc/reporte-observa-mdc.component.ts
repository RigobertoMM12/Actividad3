import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ReportesmdcService } from '../services/reportesMdcService';
import { PaginationInstance } from 'ngx-pagination';
import { formatDate } from '@angular/common';
import { ColFolio } from '../reporte-asigna/ColFolio';
import * as XLSX from 'xlsx';
import { MantenimientoUsrService } from '../mantenimiento-usr/mantenimiento-usr.ervice';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService';
import { SelectModel } from '../reporte-geogra-mdc/selectModel';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-reporte-observa-mdc',
  templateUrl: './reporte-observa-mdc.component.html',
  styleUrls: ['../css/mesaDeControl.css']
})
export class ReporteObservaMdcComponent implements OnInit {

  @ViewChild('table', { static: false }) TABLE: ElementRef;
  title = 'Excel';
  loading: boolean = false;
  filtroSelect: number = 1;
  showSelect: boolean = false;
  showtetx: boolean = false;
  filtroPlaceHolder: string = "";
  filtroType: string = "text";
  dtoFiltro: string = "";
  ffechaInicio: { day: number, year: number, month: number };
  ffechaFin: { day: number, year: number, month: number };
  mascarausar: string = "00000000";
  minlength = 0;
  maxlength = 0;
  activaBor: boolean = false;
  captcha:string;
  respCaptch:string;
  isbad:boolean=false;
  tittleBotton:string="";
  constructor(private reportesService: ReportesmdcService, private mantenimiento: MantenimientoUsrService, private userService: UserService) { }
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 8,
    currentPage: 1
  };
  empleadoSelect: number;
  usrActivo: UsuarioModel;
  fInicio: string = "";
  fFinal: string = "";
  fechaActual: Date;
  fechaActualR: Date = new Date();
  config: any;
  dataSuc: SelectModel[] = [];
  dataZona: SelectModel[] = [];
  dataReg: SelectModel[] = [];
  selectSelect: SelectModel[] = [];
  collection = { count: 60, data: [] };
  foliosReport: ColFolio[];

  ngOnInit(): void {
    this.usrActivo = this.userService.getUserLoggedIn();
    this.loadDataReport()
    
    this.cargarDataG()
  }
  loadDataReport(): void {
    console.log("-------------------***");
    this.foliosReport = [];
    this.loading = true;
    this.fechaActual = new Date();
    if (this.ffechaFin == null) {
      this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
    }

    if (this.ffechaInicio == null) {
      this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
    } else {
      this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
    }

    if (this.dtoFiltro.length >= this.minlength && this.dtoFiltro.length <= this.maxlength) {
      this.activaBor = false;
      
    var peticion = {
      "fInicio": this.fInicio, "fFinal": this.fFinal, "ban": this.filtroSelect, "temp": this.dtoFiltro
    }
    console.log(" loadData() ===> ", peticion)
    this.fFinal = this.converir(this.fFinal);
    this.fInicio = this.converir(this.fInicio);

    this.collection.data = [];
    this.config = {
      itemsPerPage: 8,
      currentPage: 1,
      totalItems: this.collection.data.length
    };
    var timpoTotal;

    this.reportesService.getReporteObservados(JSON.stringify(peticion)).subscribe(
      resp => {

        if (resp.codigo == 2) {
          if (resp.dato != null) {
            if (resp.dato.length > 0) {
              resp.dato.forEach(element => {
                this.collection.data.push(element)
              });
            } else {
              this.collection.data = [];
            }

          } else {
            this.collection.data = [];
          }

        }

        this.config = {
          itemsPerPage: 6,
          currentPage: 1,
          totalItems: this.collection.data.length
        };
        this.loading = false




      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      })
    }else{
      this.activaBor = true;
      this.loading = false;
    }


  }
  cargarDataG(): void {
    this.dataSuc = [];
    this.dataZona = [];
    this.dataReg = [];
    var select_T: SelectModel;
    this.reportesService.getListaGeografia().subscribe(
      resp => {

        if (resp.codigo == 2) {
          if (resp.dato != null) {
            if (resp.dato.length > 0) {
              resp.dato.forEach(element => {
                select_T = new SelectModel();
                select_T.id_tipo = element.id;
                select_T.desc_tipo = element.descripcion
                switch (element.ban) {
                  case 1:
                    this.dataSuc.push(select_T)
                    break;
                  case 2:
                    this.dataZona.push(select_T)
                    break;
                  case 3:
                    this.dataReg.push(select_T)
                    break;
                }
              });
            }
          }

        }
      }, err => {
        this.loading = false;
        console.log("loadData()=> ", err)
      })
  }

  converir(fecha): string {
    var nvalo = fecha.split("/");
    return nvalo[2] + "-" + nvalo[1] + "-" + nvalo[0];
  }

  filtrosActivar(): void {
    this.activaBor = false;
    this.dtoFiltro = "0";
    switch (Number.parseInt(this.filtroSelect.toString())) {
      case 1:
        this.showSelect = false;
        this.showtetx = false;
        this.minlength = 0;
        this.maxlength = 0;
        this.dtoFiltro = "";
        break;
      case 4:
        this.showSelect = true;
        this.showtetx = false;
        this.filtroPlaceHolder = "Selecciona Sucursal";
        this.filtroType = "number";
        this.dtoFiltro = "0";
        this.minlength = 3;
        this.maxlength = 6;
        this.selectSelect = this.dataSuc;
        break;
      case 2:
        this.showSelect = true;
        this.showtetx = false;
        this.filtroPlaceHolder = "Selecciona Zona";
        this.filtroType = "number";
        this.dtoFiltro = "0";
        this.minlength = 3;
        this.maxlength = 6;
        this.selectSelect = this.dataZona;
        break;
      case 3:
        this.showSelect = true;
        this.showtetx = false;
        this.filtroPlaceHolder = "Selecciona Región";
        this.filtroType = "number";
        this.dtoFiltro = "0";
        this.minlength = 3;
        this.maxlength = 6;
        this.selectSelect = this.dataReg;
        break;

    }
  }


  ExportTOExcel() {
    if(this.captcha == this.respCaptch){

      this.isbad = false;
      $("#closeModal").click();
      this.loading = true;
      this.fechaActual = new Date();
      if (this.ffechaFin == null) {
        this.fFinal = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
      } else {
        this.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
      }
  
      if (this.ffechaInicio == null) {
        this.fInicio = formatDate(this.fechaActual, 'dd/MM/yyyy', 'es');
      } else {
        this.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
      }
  
     
        
      var peticion = {
        "fInicio": this.fInicio, "fFinal": this.fFinal, "ban": this.filtroSelect, "temp": this.dtoFiltro
      }
      console.log(" loadData() ===> ", peticion)
      this.reportesService.getReporteObservadosExcel(JSON.stringify(peticion)).subscribe(
        resp => {
        try {
          if (resp.codigo == 2) {
            if (resp.dato != null) {
              this.downloadFile(resp.dato, "application/vnd.openxmlformats-officedocument.spreadsheetml")

            }

          }
          this.loading = false
        } catch (error) {
          this.loading = false
        }
          

        }, err => {
          this.loading = false;
          console.log("loadData()=> ", err)
        })
/*
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Reporte');
    XLSX.writeFile(wb, 'ReporteObservacion_.xlsx');*/
  }else{
    this.isbad = true;
    if( this.respCaptch.length == 0){
      this.tittleBotton  = "Captcha es requerido"
    }else if( this.respCaptch.length < 8){
      this.tittleBotton  = "Captcha tiene que ser de 8 posiciones"
    }else{
      this.tittleBotton  = "Captcha diferente "
    }
   
  
  }
  }

  creaCodigo() {
    this.tittleBotton = ""
    this.isbad = false
    this.captcha = this.randomString(8,
      '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ');
    this.respCaptch = "";
  }
  randomString(length, chars): string {
    var result = '';
    for (var i = length; i > 0; --i)
      result += chars[Math.round(Math
        .random()
        * (chars.length - 1))];
    return result;
  }

  downloadFile(blobContent, tyCont): void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});

    saveAs(blob, 'ReporteObservacion_.xlsx');
  }
  base64toBlob(base64Data, contentType): Blob {
    contentType = contentType || '';
    let sliceSize = 1024;
    let byteCharacters = atob(base64Data);
    let bytesLength = byteCharacters.length;
    let slicesCount = Math.ceil(bytesLength / sliceSize);
    let byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }

}
