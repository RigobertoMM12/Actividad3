export class ClienteExp {
pais: string
canal:string
sucursal: string
folio:string
nombre: string
apePaterno:string
apeMaterno:string
fecNacimiento:string
sexo:string
calle: string
numExt: string
numInt: string
cp: string
colonia: string
poblacion: string
estado: string
cuentaCaptacion: string
idEstadoCivil: string
idNacionalidad: string
numExterior: string
numInterior: string
nacionalidad: string
edoCivil: string
apePat: string
apeMat: string
fecNac: string
cuenta: string
sucursalGestora: string
sucGestora: string
  }
  