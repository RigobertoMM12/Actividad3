import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { Observable, throwError, from, of } from 'rxjs';
import swal from 'sweetalert2';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';




@Injectable()
export class ConsultaExpService {
  
  private ulrrecuperaFotoCU : string = environment.apiUrl+  'mesacontrolguatemala/mesavalidacion/recuperaFotoCU_beta';
  private urlrecuperaInfoPorNombre: string = environment.apiUrl+'mesacontrolguatemala/mesavalidacion/recuperaInfoPorNombre_beta';
  private urlrecuperaInfoPorCU: string = environment.apiUrl+'mesacontrolguatemala/mesavalidacion/recuperaInfoPorCU_beta';
  private urlrecuperaInfoPorCuenta: string = environment.apiUrl+'mesacontrolguatemala/mesavalidacion/recuperaInfoPorCuenta_beta';
  private urlsetValidacionExpe: string = environment.apiUrl+'mesacontrolguatemala/mesavalidacion/setValidacionExpe_beta';


  private httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
  constructor(private http: HttpClient, private router: Router) { }
  
  recuperaFotoCU(peticion:string): Observable<any>  {
    return this.http.post(this.ulrrecuperaFotoCU,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }

   
  recuperaInfoPorNombre(peticion:string): Observable<any>  {
    return this.http.post(this.urlrecuperaInfoPorNombre,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }

   
  recuperaInfoPorCU(peticion:string): Observable<any>  {
    return this.http.post(this.urlrecuperaInfoPorCU,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }

   
  recuperaInfoPorCuenta(peticion:string): Observable<any>  {
    return this.http.post(this.urlrecuperaInfoPorCuenta,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }
  setValidacionExpe(peticion:string): Observable<any>  {
    return this.http.post(this.urlsetValidacionExpe,JSON.stringify(peticion), { headers: this.httpHeaders }).pipe(
      map(response => {
        let notSore :any = response;

        return notSore;
      },catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
         
          return throwError(e);
        }

        
        return throwError(e);
      })
      )
    );
  }
}
