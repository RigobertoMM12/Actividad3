import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import Swal from 'sweetalert2';
import { PaginationInstance } from 'ngx-pagination';
import { formatDate } from '@angular/common';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import * as $ from 'jquery'
import { UserService } from '../header/UserService';
import { UsuarioModel } from '../header/model/usuarioModel';
import { ConsultaExpService } from './consulta-exp.service';
import { ClienteExp } from './ClienteExp';



@Component({
  selector: 'app-consulta-epe',
  templateUrl: './consulta-epe.component.html',
  styleUrls: ['./consulta-epe.component.css']
})
export class ConsultaEpeComponent implements OnInit {
  //Inicio declaracion de variables
  @ViewChild('imgRef') img: ElementRef;
  urlDigitalizaFrama: string = "";
  urlSafe: SafeResourceUrl;
  urlSafeExpUnic: SafeResourceUrl;
  statusFinal = [{ id: 100, value: "Selecciona el status del documento" }, { id: 3001, value: "Aprobado" }, { id: 3002, value: "Devolucion" }];
  photoSelect: string = "";
  photoSelectSecury: any = "data:image/png;base64, ";
  valueStatusFinal: number = 100
  filtroSelect: number = 0;
  showtetx: boolean = false;
  comentarios: string = "";
  loading = false;
  messageError: string = "";
  usrActivo: UsuarioModel;
  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 6,
    currentPage: 1
  };
  config: any;
  collection = { count: 60, data: [] };

  // primer campo Nombre Pais
  busquedaPla: string = "";
  busquedaMin: number = 0;
  busquedaMax: number = 0;
  filtBus: string = "";
  filtBusType: string = "";
  maskfiltBus : string="";
  borderBus:boolean=false;
  // segundo campo Primer Apellido, canal
  busquedaPlaC1: string = "";
  busquedaMinC1: number = 0;
  busquedaMaxC1: number = 0;
  filtBusC1: string = "";
  filtBusTypeC1: string = "";
  maskfiltBusC1 : string="";
  borderBusC1:boolean=false;
  // tercer campo Segundo Apellido, sucusal
  busquedaPlaC2: string = "";
  busquedaMinC2: number = 0;
  busquedaMaxC2: number = 0;
  filtBusC2: string = "";
  filtBusTypeC2: string = "";
  maskfiltBusC2 : string="";
  borderBusC2:boolean=false;
  // cuarto campo Fecha nacimiento, folio, cuenta
  busquedaPlaC3: string = "";
  busquedaMinC3: number = 0;
  busquedaMaxC3: number = 0;
  filtBusC3: string = "";
  filtBusTypeC3: string = "";
  maskfiltBusC3 : string="";
  expedienteSelect: ClienteExp = new ClienteExp();
  borderBusC3:boolean=false;
  ffechaFin: {day:number,year: number, month: number};
  today = new Date()
  startDate   = { year: 2000, month: 1, day: 1 };
  maxDate= { year: 2022, month: 1, day: 1 };
  //Termina declaracion de variables
  constructor(public sanitizer: DomSanitizer, private userService: UserService, private consulaExpService: ConsultaExpService) { }


  ngOnInit(): void {
    this.today.setDate(this.today.getDate() + 0);
    this.maxDate = { year: this.today.getFullYear(), month: (this.today.getMonth() + 1), day: this.today.getDate()  };
    this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl("");
    this.photoSelectSecury = this.sanitizer.bypassSecurityTrustResourceUrl(this.photoSelectSecury);
    this.usrActivo = this.userService.getUserLoggedIn();
  }
  filtrosActivarExp(): void {
    this.borderBus=false;
    this.borderBusC1=false;
    this.borderBusC2=false;
    this.borderBusC3=false;

    switch (Number.parseInt(this.filtroSelect.toString())) {
      case 0:
        this.showtetx = false;
        break;
      case 1:
        this.showtetx = true;
        this.busquedaPla = "Nombre(s)";
        this.busquedaMin = 2;
        this.busquedaMax = 40;
        this.filtBus = "";
        this.filtBusType = "text"
        setTimeout(() => {     this.maskfiltBus ="";}, 100);
     
        
        this.busquedaPlaC1 = "Primer Apellido";
        this.busquedaMinC1 = 2;
        this.busquedaMaxC1 = 40;
        this.filtBusC1 = "";
        this.filtBusTypeC1 = "text"
        setTimeout(() => {     this.maskfiltBusC1 ="";}, 100);

        this.busquedaPlaC2 = "Segundo Apellido";
        this.busquedaMinC2 = 2;
        this.busquedaMaxC2 = 40;
        this.filtBusC2 = "";
        this.filtBusTypeC2 = "text"
        setTimeout(() => {     this.maskfiltBusC2 ="";}, 100);


        this.busquedaPlaC3 = "Fecha Nacimiento";
        this.busquedaMinC3 = 8;
        this.busquedaMaxC3 = 10;
        this.filtBusC3 = "";
        this.filtBusTypeC3 = "date";
        this.ffechaFin = null;
        break;
      case 2:
        this.showtetx = true;
        this.busquedaPla = "País";
        this.busquedaMin = 1;
        this.busquedaMax = 2;
        this.filtBus = "";
        this.filtBusType = "text"
        setTimeout(() => {this.maskfiltBus ="00";}, 100);
        

        this.busquedaPlaC1 = "Canal";
        this.busquedaMinC1 = 1;
        this.busquedaMaxC1 = 2;
        this.filtBusC1 = "";
        this.filtBusTypeC1 = "text"
        setTimeout(() => { this.maskfiltBusC1 ="00";}, 100);
        
        this.busquedaPlaC2 = "Sucursal";
        this.busquedaMinC2 = 3;
        this.busquedaMaxC2 = 6;
        this.filtBusC2 = "";
        this.filtBusTypeC2 = "text"
        setTimeout(() => {  this.maskfiltBusC2 ="000000";}, 100);
       

        this.busquedaPlaC3 = "Folio";
        this.busquedaMinC3 = 1;
        this.busquedaMaxC3 = 6;
        this.filtBusC3 = "";
        this.filtBusTypeC3 = "text";
        setTimeout(() => {  this.maskfiltBusC3 ="000000";}, 100);
        
        break;
      case 3:
        this.showtetx = true;
        this.busquedaPla = "";
        this.busquedaMin = 2;
        this.busquedaMax = 50;
        this.filtBus = "";
        this.filtBusType = "number"

        this.busquedaPlaC1 = "";
        this.busquedaMinC1 = 0;
        this.busquedaMaxC1 = 0;
        this.filtBusC1 = "";
        this.filtBusTypeC1 = "number"

        this.busquedaPlaC2 = "Sucursal";
        this.busquedaMinC2 = 3;
        this.busquedaMaxC2 = 6;
        this.filtBusC2 = "";
        this.filtBusTypeC2 = "text"
        
        setTimeout(() => {  this.maskfiltBusC2 ="000000";}, 100);

        this.busquedaPlaC3 = "Cuenta";
        this.busquedaMinC3 = 8;
        this.busquedaMaxC3 = 12;
        this.filtBusC3 = "";
        this.filtBusTypeC3 = "text";
        setTimeout(() => {  this.maskfiltBusC3 ="000000000000";}, 100);
        break;

    }
  }
  loadDataExp(): void {
    //this.loading = true;
    var peticionFilter;
    var banEjecuta=false;
    var banEjecutaC1=false;
    var banEjecutaC2=false;
    var banEjecutaC3=false;
    switch (Number.parseInt(this.filtroSelect.toString())) {
      case 1:
        if(  this.filtBus.length >= this.busquedaMin &&   this.filtBus.length<=this.busquedaMax){
          this.borderBus=false;
           banEjecuta=true;
        }else{
          banEjecuta=false;
          this.borderBus=true;
        }
        if(  this.filtBusC1.length >= this.busquedaMinC1 &&   this.filtBusC1.length<=this.busquedaMaxC1){
          this.borderBusC1=false;
          banEjecutaC1=true;
        }else{
          this.borderBusC1=true;banEjecutaC1=false;
        }
        if(  this.filtBusC2.length >= this.busquedaMinC2 &&   this.filtBusC2.length<=this.busquedaMaxC2){
          this.borderBusC2=false;
          banEjecutaC2=true;
        }else{
          this.borderBusC2=true;banEjecutaC2=false;
        }
        if(this.filtroSelect == 1){
          if (this.ffechaFin == null ) 
          {
            this.borderBusC3=true;
            banEjecutaC3=false;
          }else{
            this.borderBusC3=false;
            banEjecutaC3=true;
          }
        }else{
          if(  this.filtBusC3.length >= this.busquedaMinC3 &&   this.filtBusC3.length<=this.busquedaMaxC3){
            this.borderBusC3=false;
            banEjecutaC3=true;
          }else{
            this.borderBusC3=true;
            banEjecutaC3=false;
          }
        }
        


        if(banEjecuta && banEjecutaC1 && banEjecutaC2 && banEjecutaC3){
          peticionFilter = {
            nombre: this.filtBus,
            aPaterno: this.filtBusC1,
            aMaterno: this.filtBusC2,
            //fNacimiento: formatDate(this.filtBusC3, 'dd-MM-yyyy', 'es'),
            fNacimiento: ((this.ffechaFin.day.toString().length ==1)?"0"+this.ffechaFin.day.toString():this.ffechaFin.day) +"-"+((this.ffechaFin.month.toString().length ==1)?"0"+this.ffechaFin.month.toString():this.ffechaFin.month) +"-"+this.ffechaFin.year,
            sexo: "M"
          }
         
          this.recuperaInfoPorNombre(peticionFilter)
        }
        
        break;
      case 2:
        if(  this.filtBus.length >= this.busquedaMin &&   this.filtBus.length<=this.busquedaMax){
          this.borderBus=false;
           banEjecuta=true;
        }else{
          banEjecuta=false;
          this.borderBus=true;
        }
        if(  this.filtBusC1.length >= this.busquedaMinC1 &&   this.filtBusC1.length<=this.busquedaMaxC1){
          this.borderBusC1=false;
          banEjecutaC1=true;
        }else{
          this.borderBusC1=true;banEjecutaC1=false;
        }
        if(  this.filtBusC2.length >= this.busquedaMinC2 &&   this.filtBusC2.length<=this.busquedaMaxC2){
          this.borderBusC2=false;
          banEjecutaC2=true;
        }else{
          this.borderBusC2=true;banEjecutaC2=false;
        }
        if(  this.filtBusC3.length >= this.busquedaMinC3 &&   this.filtBusC3.length<=this.busquedaMaxC3){
          this.borderBusC3=false;
          banEjecutaC3=true;
        }else{
          this.borderBusC3=true;
          banEjecutaC3=false;
        }

        peticionFilter = {
          pais: this.filtBus,
          canal: this.filtBusC1,
          sucursal: this.filtBusC2,
          folio: this.filtBusC3
        }
        if(banEjecuta && banEjecutaC1 && banEjecutaC2 && banEjecutaC3){
        this.recuperaInfoPorCU(peticionFilter);
        }
        break;
      case 3:
        if(  this.filtBusC2.length >= this.busquedaMinC2 &&   this.filtBusC2.length<=this.busquedaMaxC2){
          this.borderBusC2=false;
          banEjecutaC2=true;
        }else{
          this.borderBusC2=true;banEjecutaC2=false;
        }
        if(  this.filtBusC3.length >= this.busquedaMinC3 &&   this.filtBusC3.length<=this.busquedaMaxC3){
          this.borderBusC3=false;
          banEjecutaC3=true;
        }else{
          this.borderBusC3=true;
          banEjecutaC3=false;
        }
        if(banEjecutaC2 && banEjecutaC3){
        peticionFilter = {
          sucursal: this.filtBusC2,
          cuenta: this.filtBusC3
        }
        this.recuperaInfoPorCuenta(peticionFilter)
      }
       
        break;
    }

    console.log("loadDataExp ==> peticionFilter ==> ", peticionFilter)

  }

  recuperaFotoCU(peticion): void {
    this.loading = true;
    this.consulaExpService.recuperaFotoCU(peticion).subscribe(
      data => {
        this.loading = false;
        if (data.codigo == 1) {
          this.photoSelect = data.dato;
          this.img.nativeElement.src = "data:image/png;base64, " + this.photoSelect;
        } else {
          this.photoSelect = "";
          this.img.nativeElement.src = "assets/img/sin-perfil.jpg"
        }

      }
    )
  }


  recuperaInfoPorNombre(peticion): void {
    this.loading = true;
    this.collection.data = [];
    this.consulaExpService.recuperaInfoPorNombre(peticion).subscribe(
      data => {
        this.loading = false;
        if (data.codigo == 1) {
          data.dato.forEach(notificacion => {
            this.collection.data.push(notificacion);
          });
          this.config = {
            itemsPerPage: 5,
            currentPage: 1,
            totalItems: this.collection.data.length
          };
        }

      }
    )
  }

  recuperaInfoPorCU(peticion): void {
    this.loading = true;
    this.collection.data = [];
    this.consulaExpService.recuperaInfoPorCU(peticion).subscribe(
      data => {
        this.loading = false;
        if (data.codigo == 1) {
          data.dato.forEach(notificacion => {
            this.collection.data.push(notificacion);
          });
          this.config = {
            itemsPerPage: 5,
            currentPage: 1,
            totalItems: this.collection.data.length
          };
        }

      }
    )
  }
  recuperaInfoPorCuenta(peticion): void {
    this.loading = true;
    this.collection.data = [];
    this.consulaExpService.recuperaInfoPorCuenta(peticion).subscribe(
      data => {
        this.loading = false;
        if (data.codigo == 1) {
          data.dato.forEach(notificacion => {
            this.collection.data.push(notificacion);
          });
          this.config = {
            itemsPerPage: 5,
            currentPage: 1,
            totalItems: this.collection.data.length
          };
        }

      }
    )
  }
  evaluarCliente(cliente): void {
    console.log("evaluarCliente ==> cliente ==>", cliente)
    this.expedienteSelect = null;
    this.comentarios = "";
    this.valueStatusFinal = 100
    var peticionFilter = {
      pais: cliente.pais,
      canal: cliente.canal,
      sucursal: cliente.sucursal,
      folio: cliente.folio
    }
    this.expedienteSelect = cliente;
    console.log("filtroSelect" ,this.filtroSelect)
    if(this.filtroSelect == 3){
      this.expedienteSelect.cuentaCaptacion = ((this.filtBusC2.length ==3)?(0+this.filtBusC2):0+this.filtBusC2) + this.filtBusC3;
      console.log("filtroSelect" ,this.filtroSelect)
    }
    var complementURL = "imxwebCapta/jsp/principal4.jsp?idExp=" + this.expedienteSelect.cuentaCaptacion
    this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.usrActivo.tabla[0].descValor+ complementURL);
    this.recuperaFotoCU(peticionFilter)
  }

  evaluFolioExp(): void {
    if (this.valueStatusFinal == 100) {
      this.messageError = "Selecciona el estatus del folios"
    } else
      if (this.valueStatusFinal == 3002 && (this.comentarios == null || this.comentarios == "")) {
        this.messageError = "Los comentarios son necesarios "
      } else {
        console.log("evaluFolioExp() ==> SE ejecutaria servicio")
        var peticion = {
          noEmpleado: this.usrActivo.idEmpleado,
          resultado: this.valueStatusFinal,
          cuenta: (Number.parseInt(this.filtroSelect.toString()) == 3) ? (((this.filtBusC2.length == 3) ? "0" + this.filtBusC2 : this.filtBusC2) + "" + this.filtBusC3) : this.expedienteSelect.cuentaCaptacion,
          observaciones: this.comentarios
        }
        console.log("evaluFolioExp() ==> peticion ==> ", peticion)
        this.setValidacionExpe(peticion);
      }
  }


  setValidacionExpe(peticion): void {
    this.loading = true;
    this.consulaExpService.setValidacionExpe(peticion).subscribe(
      data => {
        this.loading = false;
        if (data.codigo == 1) {
          $("#closeModal").click();
          var nnn = (Number.parseInt(this.filtroSelect.toString()) == 3) ? (((this.filtBusC2.length == 3) ? "0" + this.filtBusC2 : this.filtBusC2) + "" + this.filtBusC3) : this.expedienteSelect.cuentaCaptacion;

          Swal.fire('Status final', `Se  ` + ((peticion.resultado == 3002) ? "Devolución" : "Aprobo") + ` el número de cuenta ` + nnn, 'success');
        } else {
          console.log("setValidacionExpe() ==> Error ==> ")
        }

      }
    )
  }

}
