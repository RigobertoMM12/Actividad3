import { Injectable } from '@angular/core';
//import { DatePipe, formatDate } from '@angular/common';
//import { Cliente } from './cliente';
import { Notificacion }from './notificacion'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { Observable, throwError, from, of } from 'rxjs';
import swal from 'sweetalert2';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';



@Injectable()
export class NotificacionmdvService {
  private urlEndPoint: string = environment.apiUrl+ 'mesacontrolguatemala/mesavalidacion/getNotificaciones';
  private ulrSaveNotification : string = environment.apiUrl+  'mesacontrolguatemala/mesavalidacion/setNotificaciones_beta';
  private ulrGetNotificacionB6 : string = environment.apiUrl+  'mesacontrolguatemala/mesavalidacion/obtenerNotificacion_beta';
  private httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private http: HttpClient, private router: Router) { }

  getNotificaciones(): Observable<Notificacion[]> {
    return this.http.post(this.urlEndPoint,null).pipe(
      map(response => {
        let notSore :any = response;
        let notificaciones = notSore.dato as Notificacion[];
        return notificaciones.map(notificac => {
          return notificac;
        });
      }
      ),catchError(e => {
        console.log("catchError()-->",e)
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.status == 0) {
          swal.fire("Servicio no disponible", e.error.error, 'error');
          return throwError(e);
        }

        
        return throwError(e);
      })
    );
  }


  getNotificationB64(peticion :  String): Observable<any> {
    console.log(peticion)
    return this.http.post(this.ulrGetNotificacionB6, peticion, { headers: this.httpHeaders }).pipe(
      map(response => {
        return response;
      }),
      catchError(e => {

        if (e.status == 400) {
          return throwError(e);
        }

        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }

  create(notificacion :  Notificacion): Observable<Notificacion> {
    console.log(notificacion)
    return this.http.post(this.ulrSaveNotification, JSON.stringify(notificacion), { headers: this.httpHeaders }).pipe(
      map((response: any) => response.cliente as Notificacion),
      catchError(e => {

        if (e.status == 400) {
          return throwError(e);
        }

        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }

  getCliente(id): Observable<Notificacion> {
    return this.http.get<Notificacion>(`${this.urlEndPoint}/${id}`).pipe(
      catchError(e => {
        this.router.navigate(['/notificaciones']);
        console.error(e.error.mensaje);
        swal.fire('Error al editar', e.error.mensaje, 'error');
        return throwError(e);
      })
    );
  }

  update(notificacion: Notificacion): Observable<any> {
    return this.http.post(this.ulrSaveNotification, JSON.stringify(notificacion), { headers: this.httpHeaders }).pipe(
      catchError(e => {

        if (e.status == 400) {
          return throwError(e);
        }

        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }

  deleteNotificacion(notif : Notificacion): Observable<any> {
    console.log("----------",notif)

    return this.http.post(this.ulrSaveNotification, JSON.stringify(notif), { headers: this.httpHeaders }).pipe(
      catchError(e => {
        console.error(e.error.mensaje);
        swal.fire(e.error.mensaje, e.error.error, 'error');
        return throwError(e);
      })
    );
  }

}
