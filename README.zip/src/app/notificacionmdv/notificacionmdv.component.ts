import { Component, OnInit, Output,Input, EventEmitter} from '@angular/core';
import { Notificacion } from './notificacion'
import { NotificacionmdvService } from './notificacionmdv.service';
import Swal from 'sweetalert2';
import { tap } from 'rxjs/operators';
import { PaginationInstance } from 'ngx-pagination';
import { DataService } from '../services/data.service';
import { UsuarioModel } from '../header/model/usuarioModel';
import { UserService } from '../header/UserService';
import { Router } from '@angular/router';



@Component({
  selector: 'app-notificaciones',
  templateUrl: './notificacionmdv.component.html',
  styleUrls: ['./notificacionmdv.component.css']
})
export class NotificacionComponent implements OnInit {
  @Output() public valor = new EventEmitter<any>();
  usrActivo : UsuarioModel;
  notificaciones :Notificacion[];
  loading = false;

  private paginationConfig: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 6,
    currentPage: 1
  };

  applyDates() {
    console.log("------")
    this.valor.emit(2);
  }


  constructor(private notificacionmdvService: NotificacionmdvService,private datSe :DataService,private userService:UserService,private router: Router) { }
  config: any;
  collection = { count: 60, data: [] };
  ngOnInit() {
    this.loadData();
    this.usrActivo = this.userService.getUserLoggedIn();
  }
  loadData(): void{
    this.notificaciones=[];
    console.log("-------------------***")
    this.loading = true;
    this.notificacionmdvService.getNotificaciones().subscribe(
      notificaciones => {
        console.log('ClientesComponent: tap 3');
        this.loading = false
        this.collection.data =[];
        notificaciones.forEach(notificacion => {
          this.collection.data.push(notificacion);
        });
        this.notificaciones =  this.collection.data;
        this.config = {
          itemsPerPage: 5,
          currentPage: 1,
          totalItems: this.collection.data.length
        };
      },err =>{
        this.loading = false;
        console.log("loadData()=> ",err)
      });
  }

  cleanNotification(): void {
    this.datSe.notificacion = new Notificacion();
    this.datSe.crear = true;
    this.datSe.isDetails = undefined;
    this.router.navigate(['notificaciones/form']);
  }
 
  madifica(notificacion: Notificacion,isDetails): void {
    console.log("madifica() ==> ",notificacion.mensaje,isDetails)
    this.datSe.notificacion = notificacion;
    this.datSe.crear = false;
    this.datSe.isDetails = isDetails;
  }
  pageChanged(event){
    this.config.currentPage = event;
  }

  delete(notificacion: Notificacion): void {

    Swal.fire({
      title: 'Está seguro?',
      text: `¿Seguro que desea eliminar la notificacion ${notificacion.idNotificacion}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Si, eliminar!',
      cancelButtonText: 'No, cancelar!'
    }).then((result) => {
      if (result.value) {
        this.loading= true;
        notificacion.ban =3
        notificacion.b64Archivo ="-";
        notificacion.idEmpleado = this.usrActivo.idEmpleado;
        //notificacion.archivo=""
        console.log("----------",notificacion)
        this.notificacionmdvService.deleteNotificacion(notificacion).subscribe(
          () => {
            this.loading= false;
            this.notificaciones=[];
            this.notificaciones = this.notificaciones.filter(cli => cli !== notificacion);
            this.loadData();
            Swal.fire(
              'Notificacion Eliminada!',
              `Notificacion ${notificacion.idNotificacion} eliminada con éxito.`,
              'success'
            )
          }
        )

      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelado',
          '',
          'error'
        )
      }
    })
   /* swal.fire({
      title: 'Está seguro?',
      text: `¿Seguro que desea eliminar la notificacion ${notificacion.idNotificacion}?`,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, eliminar!',
      cancelButtonText: 'No, cancelar!',
      confirmButtonClass: 'btn btn-success',
      cancelButtonClass: 'btn btn-danger',
      buttonsStyling: false,
      reverseButtons: true
    }).then((result) => {
      if (result.value) {

        notificacion.ban =3
        notificacion.b64Archivo ="-";
        notificacion.idEmpleado =180794;
        notificacion.archivo=""
        console.log("----------",notificacion)
        this.notificacionmdvService.deleteNotificacion(notificacion).subscribe(
          () => {
            this.notificaciones = this.notificaciones.filter(cli => cli !== notificacion)
            swal.fire(
              'Notificacion Eliminada!',
              `Notificacion ${notificacion.idNotificacion} eliminada con éxito.`,
              'success'
            )
          }
        )

      }
    });*/
  }

}
