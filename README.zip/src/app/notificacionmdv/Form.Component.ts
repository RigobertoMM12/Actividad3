import { Component, OnInit, Input } from '@angular/core';
import { Notificacion } from './notificacion'
import { NotificacionmdvService } from './notificacionmdv.service';
import { DatePipe, formatDate } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
import { from } from 'rxjs';
import * as _ from 'lodash';
import { DataService } from '../services/data.service';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./notificacionmdv.component.css']

})
export class FormComponent implements OnInit {
  @Input() valor: number = 600;
  loading = false;
   notifiacion: Notificacion = new Notificacion();

  imageError: string;
  isImageSaved: boolean;
  cardImageBase64: string;
  titulo: string = "Crear Notificación";
  archivoTemporal : string;
  archivoTemporalOne : string;
  errores: string[];
  nvalo: string[];
  isDetails : boolean;
  today = new Date()
  minDate = { year: 2010, month: 5, day: 25 };
  constructor(private notificaciService: NotificacionmdvService,
    private router: Router,
    private activatedRoute: ActivatedRoute,private datService:DataService,public dataService:DataService) { }
    public habilitabtn:boolean =true;
     ffechaInicio: { day: number, year: number, month: number };
  ffechaFin: { day: number, year: number, month: number };
  ngOnInit() {
    this.today.setDate(this.today.getDate() - 0);
    this.minDate = { year: this.today.getFullYear(), month: (this.today.getMonth() + 1), day: this.today.getDate()  };
    this.cargarCliente();
  }

  cargarCliente(): void {
    this.habilitabtn = this.datService.crear;
    if(!this.habilitabtn){
      this.titulo="Editar Notificación"
    }
    
    this.isDetails = this.datService.isDetails;
    this.isDetails =(this.isDetails == undefined) ? false:this.isDetails;
    if(this.isDetails){
      this.titulo="Detalles Notificación"
    }
    console.log("cargarCliente()======>",this.isDetails)
 try{
  this.notifiacion  = this.datService.notificacion;
  this.nvalo= this.notifiacion.fInicio.split("/");
  this.ffechaInicio=  { day:  Number(this.nvalo[0]), year: Number(this.nvalo[2]), month: Number(this.nvalo[1] )};

  this.nvalo= this.notifiacion.fFinal.split("/");
  this.ffechaFin=  { day:  Number(this.nvalo[0]), year: Number(this.nvalo[2]), month: Number(this.nvalo[1] )};
 

  
  if( this.notifiacion == null){
    this.notifiacion = new Notificacion();
    
  }else{
    if(this.notifiacion.archivo != "" && this.notifiacion.archivo != null){
      var peticion ={
        archivo:this.notifiacion.archivo,
        idNotificacion:this.notifiacion.idNotificacion,
        instancia:this.notifiacion.instancia
      }
        this.notificaciService.getNotificationB64(JSON.stringify(peticion))
        .subscribe(
          data => {
            this.loading = false;
            if(data.codigo ==1 ){
              this.notifiacion.b64Archivo = data.dato;
            }
            //this.router.navigate(['/notificaciones']);
            //swal.fire('Nuevo notificación', `La notificacion ha sido creado con éxito`, 'success');
          },
          err => {
            swal.fire('Nuevo notificación', `Ocurrio un error al crear la notificación`, 'error');
            this.loading = false;
            this.errores = err.error.errors as string[];
            console.error('Código del error desde el backend: ' + err.status+ err.error);
            console.error(err.error.errors);
          }
        );
      
    }
    
  }

  this.notifiacion.archivoOld = this.notifiacion.archivo;

 }catch(w){
  this.router.navigate(['notificaciones']);
  console.log("catch ==> ",w);
  
 }
  }
  loadFile(value):void{
    if(!value)
    $("#archivo").click();
  }
  delateFile():void{
    this.notifiacion.archivo =""
  }
  showFile():void{
    var split1 = 	this.notifiacion.b64Archivo.split(";")
    var typeFile = split1[0].split(":");
    var b64f = split1[1].split("base64,");
    this.downloadFile(b64f[1],typeFile[1]);
  }

  downloadFile(blobContent,tyCont):void {
    let blob = new Blob([this.base64toBlob(blobContent, tyCont)], {});
    
    saveAs(blob,this.notifiacion.archivo);
}
base64toBlob(base64Data, contentType):Blob{
  contentType = contentType || '';
  let sliceSize = 1024;
  let byteCharacters = atob(base64Data);
  let bytesLength = byteCharacters.length;
  let slicesCount = Math.ceil(bytesLength / sliceSize);
  let byteArrays = new Array(slicesCount);
  for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
          bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
  }
  return new Blob(byteArrays, { type: contentType });
}
  converir(fecha) : string{
    this.nvalo= fecha.split("/");
    return this.nvalo[2]+"-"+this.nvalo[1]+"-"+this.nvalo[0];
  }
  create(): void {
    this.loading = true;
    console.log("notifiacion: ",this.notifiacion)
    this.notifiacion.fFinal = this.ffechaFin.day + "/" + this.ffechaFin.month + "/" + this.ffechaFin.year;
    this.notifiacion.fInicio = this.ffechaInicio.day + "/" + this.ffechaInicio.month + "/" + this.ffechaInicio.year;
    //this.notifiacion.archivo = this.archivoTemporal;
    this.notifiacion.ban=1;
    this.notificaciService.create(this.notifiacion)
      .subscribe(
        cliente => {
          this.loading = false;
          this.router.navigate(['notificaciones']);
          swal.fire('Nuevo notificación', `La notificacion ha sido creado con éxito`, 'success');
        },
        err => {
          swal.fire('Nuevo notificación', `Ocurrio un error al crear la notificación`, 'error');
          this.loading = false;
          this.errores = err.error.errors as string[];
          console.error('Código del error desde el backend: ' + err.status+ err.error);
          console.error(err.error.errors);
        }
      );
  }

  update(): void {
    console.log("-.-.-.-.-.-.- "+this.notifiacion)
    this.loading = true;
    this.notifiacion.fInicio =  formatDate(this.notifiacion.fInicio, 'dd/MM/yyyy', 'es');
    this.notifiacion.fFinal =  formatDate(this.notifiacion.fFinal, 'dd/MM/yyyy', 'es');

    this.notifiacion.ban=2;
    this.notificaciService.update(this.notifiacion)
      .subscribe(
        json => {
          this.router.navigate(['notificaciones']);
          swal.fire('Notificación Actualizada', `${json.descripcion}`, 'success');
        },
        err => {
          this.errores = err.error.errors as string[];
          console.error('Código del error desde el backend: ' + err.status);
          console.error(err.error.errors);
        }
      )
  }

  fileChangeEvent(fileInput: any) {
    console.log("----------*-*-*-")
    this.imageError = null;
    if (fileInput.target.files && fileInput.target.files[0]) {
        // Size Filter Bytes
        const allowed_types = ['application/pdf', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',"application/vnd.openxmlformats-officedocument.presentationml.presentation","application/vnd.openxmlformats-officedocument.wordprocessingml.document"];



        if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
            this.imageError = 'Solo son aceptados los siguientes formatos( pdf | XLSX | PPTX | DOC )';
            return false;
        }
        if(fileInput.target.files[0].size > 10000000){
          this.imageError = 'Solo se permiten archivos menores a 10MG';
            return false;
        }
        const reader = new FileReader();
        reader.onload = (e: any) => {

            this.notifiacion.b64Archivo = e.target.result;

        };

        reader.readAsDataURL(fileInput.target.files[0]);
    }
    this.notifiacion.archivo  = fileInput.target.files[0].name;
    console.log("archivoTemporal: "+this.archivoTemporal)
}
regresar():void{
  this.router.navigate(['notificaciones']);
 }

}
