export class Notificacion {
  idNotificacion: number  ;
  asunto: string="";
  mensaje:string="";

  archivo:string="";
  b64Archivo:string ="-";
  fInicio: string="";
  fFinal: string="";
  idEmpleado :number = 180794;
  ban : number ;
  instancia : string = "mipc";
  statusArchivo : number=1;
  archivoOld: string;
}
