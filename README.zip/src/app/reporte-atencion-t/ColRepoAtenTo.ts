export class ColRepoAtenTo {

    horaLlegada: string;
    recibidas: number;
    atendidas: number;
    canceladas: number;
    aceptadas: number;
    rechazadas: number;
    xCanceladas: number;
    xAceptadas: number;
}