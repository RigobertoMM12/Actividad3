import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';

import 'core-js/features/array/includes'
import '@angular/localize/init';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NotificacionComponent } from './notificacionmdv/notificacionmdv.component';
import { NotificacionmdvService } from './notificacionmdv/notificacionmdv.service';
import { MyHeaderService } from './header/header.service';
import { UserService} from './header/UserService';
import {MantenimientoUsrService} from './mantenimiento-usr/mantenimiento-usr.ervice';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormComponent } from './notificacionmdv/form.component';
import { FormUsrComponent } from './mantenimiento-usr/FormUrs.Component';
import { FormModificaComponent } from './productos/modificar/FormModifica.Component';


import { FormsModule } from '@angular/forms';
import { NgxLoadingModule , ngxLoadingAnimationTypes } from 'ngx-loading';
import { registerLocaleData } from '@angular/common';
import localeES from '@angular/common/locales/es';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxMaskModule } from 'ngx-mask'
import { IniciomdvComponent } from './iniciomdv/iniciomdv.component';
import { IniciomdvService } from './iniciomdv/iniciomdv.service';
import { ConsultaExpService } from './consulta-epe/consulta-exp.service';
import { from } from 'rxjs';
import { ReporteAsignaComponent } from './reporte-asigna/reporte-asigna.component';
import { ReportesmdvService } from './reporte-asigna/reportesmdv.service';
import { ReportesmdcService } from './services/reportesMdcService';
import { ReporteAtencionComponent } from './reporte-atencion/reporte-atencion.component';
import { ReporteAtencionTComponent } from './reporte-atencion-t/reporte-atencion-t.component';
import { ReporteValidacionComponent } from './reporte-validacion/reporte-validacion.component';
import { Page404Component } from './page404/page404.component';
import { SinSeComponent } from './sin-se/sin-se.component';
import { ConsultaEpeComponent } from './consulta-epe/consulta-epe.component';
import { MantenimientoUsrComponent } from './mantenimiento-usr/mantenimiento-usr.component';
import { IniciomdcComponent } from './iniciomdc/iniciomdc.component';

import { IniciomdcService } from './iniciomdc/iniciomdc.service';
import { ReporteSesionMdcComponent } from './reporte-sesion-mdc/reporte-sesion-mdc.component';
import { ReporteTiempoDMdcComponent } from './reporte-tiempo-dmdc/reporte-tiempo-dmdc.component';
import { ReporteTiempoRMdcComponent } from './reporte-tiempo-rmdc/reporte-tiempo-rmdc.component';
import { ReporteHorarioMdcComponent } from './reporte-horario-mdc/reporte-horario-mdc.component';
import { ReporteGeograMdcComponent } from './reporte-geogra-mdc/reporte-geogra-mdc.component';
import { ReporteObservaMdcComponent } from './reporte-observa-mdc/reporte-observa-mdc.component';
import { ReporteReenvioMdcComponent } from './reporte-reenvio-mdc/reporte-reenvio-mdc.component';
import { ReporteResumenMdcComponent } from './reporte-resumen-mdc/reporte-resumen-mdc.component';
import { ReportesolcitudesMdcComponent } from './reportesolcitudes-mdc/reportesolcitudes-mdc.component';
import { ReasignaSolMdcComponent } from './reasigna-sol-mdc/reasigna-sol-mdc.component';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';
import { ParamtrosMdcComponent } from './paramtros-mdc/paramtros-mdc.component';
import { ValidacionBanComponent } from './validacion-ban/validacion-ban.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { LoginComponent } from './login/login.component';
import { ProductosComponent } from './productos/productos.component';
import { RroductoService } from './productos/producto.service';
registerLocaleData(localeES, 'es');

const routes: Routes = [
  //{ path: '', redirectTo: 'sinSe', pathMatch: 'full' },
  //{ path: '', redirectTo: '', pathMatch: 'full' },
  { path: 'reporteAsigna', component: ReporteAsignaComponent },
  { path: 'reporteAtencion', component: ReporteAtencionComponent },
  { path: 'reporteAtenciont', component: ReporteAtencionTComponent },
  { path: 'reporteValidacion', component: ReporteValidacionComponent },
  { path: 'notificaciones', component: NotificacionComponent },
  { path: 'productos/form', component: FormModificaComponent },
  { path: 'notificaciones/form', component: FormComponent },
  { path: 'mantenimientoUsr/form', component: FormUsrComponent },
  { path: 'consultaExpe', component:  ConsultaEpeComponent},
  { path: '', component:  IniciomdvComponent},
  { path: 'solicitudes', component:  IniciomdcComponent},
  { path: 'reporteSesion', component:  ReporteSesionMdcComponent},
  { path: 'reporteTiempoD', component:  ReporteTiempoDMdcComponent},
  { path: 'reporteTiempoR', component:  ReporteTiempoRMdcComponent},
  { path: 'reporteHorario', component:  ReporteHorarioMdcComponent},
  { path: 'reporteGeografia', component:  ReporteGeograMdcComponent},
  { path: 'reporteObservados', component:  ReporteObservaMdcComponent},
  { path: 'reportReenvio', component:  ReporteReenvioMdcComponent},
  { path: 'reporteResumen', component:  ReporteResumenMdcComponent},
  { path: 'reporteSolicitudes', component:  ReportesolcitudesMdcComponent},
  { path: 'reasignaSol', component:  ReasignaSolMdcComponent},
  { path: 'mantenimientoUsr', component:  MantenimientoUsrComponent},
  { path: 'parametros', component:  ParamtrosMdcComponent},
  { path: 'sinSe', component:  SinSeComponent},
  { path: 'login', component:  LoginComponent},
  { path: 'productos', component:  ProductosComponent},
  { path: 'validacionBan', component:  ValidacionBanComponent},
  {
    path: '**',
    component:  Page404Component
  },
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    IniciomdvComponent,
    NotificacionComponent,
    FormComponent,
    FormUsrComponent,
    FormModificaComponent,
    ReporteAsignaComponent,
    ReporteAtencionComponent,
    ReporteAtencionTComponent,
    ReporteValidacionComponent,
    Page404Component,
    SinSeComponent,
    ConsultaEpeComponent,
    MantenimientoUsrComponent,
    IniciomdcComponent,
    ReporteSesionMdcComponent,
    ReporteTiempoDMdcComponent,
    ReporteTiempoRMdcComponent,
    ReporteHorarioMdcComponent,
    ReporteGeograMdcComponent,
    ReporteObservaMdcComponent,
    ReporteReenvioMdcComponent,
    ReporteResumenMdcComponent,
    ReportesolcitudesMdcComponent,
    ReasignaSolMdcComponent,
    ParamtrosMdcComponent,
    ValidacionBanComponent,
    LoginComponent,
    ProductosComponent,
  ],
  imports: [
    BrowserModule,NgbModule,
    NgxPaginationModule,
    HttpClientModule,
    FormsModule,
    PdfViewerModule,
    NgxLoadingModule.forRoot({
      animationType: ngxLoadingAnimationTypes.chasingDots,
      backdropBackgroundColour: 'rgba(0,0,0,0.1)',
      backdropBorderRadius: '4px',
      primaryColour: '#dc3545',
      secondaryColour: '#ffffff',
      tertiaryColour: '#ffffff'
  }),
  LoggerModule.forRoot({
    serverLoggingUrl: `${environment.apiUrll}/MesaDeControlGuatemala/api/logs`,
    level: environment.logLevel,
    serverLogLevel:environment.serverLogLevel,
    disableConsoleLogging: false
}),
  NgxMaskModule.forRoot(),
    RouterModule.forRoot(routes)
  ],
  providers: [IniciomdvService,NotificacionmdvService,MyHeaderService,UserService,  ReportesmdvService,ReportesmdcService,ConsultaExpService,MantenimientoUsrService,IniciomdcService,RroductoService,{ provide: LOCALE_ID, useValue: 'es' }],
  bootstrap: [AppComponent]
})
export class AppModule { }



  function copyToClipboard() {
    // crear un "hidden" input
    var aux = document.createElement("input");
    // Asignarle el valor del elemento especificado
    aux.setAttribute("value", "No puede capturar imagenes.");
    // Anexar al body
    document.body.appendChild(aux);
    // Resalte su contenido
    aux.select();
    // Copiar el texto resaltado
    document.execCommand("copy");
    // Quitarlo del body
    Swal.fire('Aviso', `Por seguridad Print screen esta deshabilitado `, 'success');
    //alert(" prohibido por seguridad Print screen esta deshabilitado.");
    document.body.removeChild(aux);
  }

document.onkeyup  = function(e){
  if (e.keyCode == 44) {
  
    console.log("Imprimiendoo")
    copyToClipboard()
  }
  return false
}
document.oncontextmenu  = function(e){
  return false
}
document.onkeydown = function ( e ) {
  if (e.keyCode === 116) {
    return false;
   }
   if (e.keyCode === 121) {//ponder 123
    return false;
   }
   if (e.keyCode === 122) {
    return false;
   }
   if (e.keyCode == 44) {
    return false;
  }

};
$(document).ready(function(){
  $("#logoBaz").click();
  console.log("Cargadooooooooooooo")
});
