// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

import { NgxLoggerLevel } from 'ngx-logger';

export const environment = {
  production: false,
  apiUrlC: 'http://localhost:8095/canales/api/',
  apiUrl: 'https://10.48.195.135:8443/ws/',//https://10.48.247.227:8443/  https://10.51.105.76:8443/  https://10.51.105.76:8443/
  version:'1.0.18',
  clienteId:'bd56d0f1-9508-4fbb-ba95-469fe9ff15d4',
  clienteSecret:'xVCaREMzhnUnLloXP3RMXAody75aV-GXKqKMh57QCFcMltGtM5reHX0I5n9S8HNAUBkyHBIUAocSDswfHBq19A',
  redirectUri:'https://10.48.247.228:8543/MesaDeControlGuatemala/',
  scope:'MesaControlGuatemala',
  acrValue:'gs/doblefactoridm/uri',
  urillave:"authns.desadsi.gs",
  apiUrll: 'http://10.51.213.8285/', // Reemplazar con API local
  logLevel: NgxLoggerLevel.WARN,
  serverLogLevel: NgxLoggerLevel.OFF,
  activarNDigitalizacion : false
  
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */

// import 'zone.js/dist/zone-error';  // Included with Angular CLI . // http://10.51.213.254:8087/ https://10.48.247.227:8443/  https://10.51.213.254:8443/
