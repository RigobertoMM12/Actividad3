import { NgxLoggerLevel } from 'ngx-logger';

export const environment = {
  production: false,
  apiUrl: 'https://10.48.195.135:8443/ws/',//http://10.48.247.227:8180/  https://10.48.247.227:8443/     'https://10.48.195.135:8443/ws/'  ---https://10.48.247.228:8543/ws/
  version:'1.0.21',
  clienteId:'187470c7-0e0a-4522-aa8a-1c099aa235a9',
  clienteSecret:'M-iHdN8r-3qvxJfZ9YfxyYFlrD3Otva61iShhrSp32zmIhQRa284_9Hg6BlDNZvKpXSqzY4L5ercfTyAiugrWg',
  redirectUri:'https://10.48.195.135:8443/MesaDeControlGuatemala/',
  scope:'MesaControlGuatemala',
  urillave:"auth.socio.gs",
  acrValue:'gs/doblefactoridm/uri',
  apiUrll: 'http://10.51.213.9090', // Reemplazar con API local
  logLevel: NgxLoggerLevel.WARN,
  serverLogLevel: NgxLoggerLevel.INFO,
  activarNDigitalizacion : true
};